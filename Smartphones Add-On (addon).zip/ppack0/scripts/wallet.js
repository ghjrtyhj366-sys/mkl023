import * as utils from "./utils";
import * as gld from "./gld";

export function getBalance(player)
{
    let balance = player.getDynamicProperty("goe_spa_coins");
    if (balance === undefined)
    {
        balance = 0;
        player.setDynamicProperty("goe_spa_coins", balance);
    }
    return balance;
}

export function canAfford(player, amount)
{
    return getBalance(player) >= amount;
}

export function deposit(player, amount) {
    let balance = getBalance(player);
    if (amount <= 0)
    {
        utils.debug("attempt to fice negative coins: "+amount);
        return false;
    }
    balance = balance ? balance + amount : amount;
    player.setDynamicProperty("goe_spa_coins", balance);
    //utils.tellraw(player, "@s", `${amount} §6${gld.coinSymbol}§r were deposited in your wallet.`);
    return true;
    
}

export function charge(player, amount, spawnParticle = true) {
    let balance = getBalance(player);
    if (amount <= 0)
    {
        utils.debug("attempt to charge negative coins: "+amount);
        return false;
    }
    
    if (balance < amount)
    {
        return false;
    }
    balance -= amount;
    player.setDynamicProperty("goe_spa_coins", balance);
    // utils.tellraw(player, "@s", `${amount} §6${gld.coinSymbol}§r were withdrawn from your wallet.`);
    if (spawnParticle) {
        player.dimension.spawnParticle("goe_spa:bought", player.location);
    }
    //utils.tellraw(player, "@s", `§aSmartcoins balance: §6${balance} ${gld.coinSymbol}§r`);
    return true;
}