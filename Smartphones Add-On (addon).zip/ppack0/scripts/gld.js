import { world } from "@minecraft/server";
import * as utils from "./utils";
import * as battery from "./battery";
import * as Vector3 from "./vector3";

export const songs = [
    { name: "Piano", cost: 0, duration: 4860 },
    { name: "Violin", cost: 0, duration: 4880 },
    { name: "Harp", cost: 0, duration: 5240 },
    { name: "Drums", cost: 10, duration: 2300 },
    { name: "Trumpet", cost: 10, duration: 3580 },
    { name: "Creepy", cost: 10, duration: 3540 },
    { name: "Country", cost: 10, duration: 4320 },
    { name: "Arcade", cost: 10, duration: 2780 },
    { name: "Pop", cost: 10, duration: 3800 },
    { name: "Jazz", cost: 10, duration: 2880 },
    { name: "Reggae", cost: 10, duration: 2540 },
    { name: "Rock", cost: 10, duration: 3240 },
    { name: "Rap", cost: 10, duration: 2860 },
    { name: "Techno", cost: 10, duration: 2900 },
    { name: "Dubstep", cost: 10, duration: 2160 },
];

export const deposit_values = {
  dirt: 1,
  sand: 3,
  stone: 5,
  copper: 1,
  iron: 3,
  gold: 6,
  diamond: 24,
  emerald: 30,
  netherite: 40
};

export const coinSymbol = "⎊";// "⌾";
export const chargeSymbol = "⌸";

export const batteryName = "§aBattery";

/*export function coinAndBatteryInfoString(player){
  return `${coinSymbol}: ${player.getDynamicProperty("goe_spa_coins")}  ${batteryName}: ${battery.getChargePercentage(player)}%%\n\n§r`;
} */
export function getScreenTitle(player)
{
  let coins = player.getDynamicProperty("goe_spa_coins");
  let charge = battery.getChargePercentage(player);
  let chargeColor = "§a";
  if (charge <= 20) chargeColor = "§c";
  else if (charge <= 50) chargeColor = "§6";
  else if (charge <= 70) chargeColor = "§e";
  let title = `   §6${coins} ${coinSymbol}`.padEnd(40, " ") + `${chargeColor}${charge}%% ${chargeSymbol}    \n`+ `§b  `.padEnd(24,"▔") + `\n§r`;
  return title;
}

export const mainMenuApp = { id: "main_menu", cost: 0, name: "§l§fSmartphone Menu§r", icon: "" };
export const loginMenu = { id: "login_menu", cost: 0, name: "§l§8Log in§r", icon: "" };
export const welcomeMenu = { id: "welcome_menu", cost: 0, name: "§l§aWelcome§r", icon: "" };
export const backButton = { id: "back", cost: 0, name: "Back", icon: "textures/goe/spa/ui/back" };

export const apps = [
	// { id: "game_settings", cost: 0, name: "§l§3Game Settings§r", icon: "textures/goe/spa/ui/game_settings" },
	{ id: "bank", cost: 0, name: "§l§6Finances§r", icon: "textures/goe/spa/ui/bank_app" },
	{ id: "app_store", cost: 0, name: "§l§dApp Store§r", icon: "textures/goe/spa/ui/app_store" },
	{ id: "msg", cost: 0, name: "§l§1Messages§r", icon: "textures/goe/spa/ui/msg_app" },
	{ id: "gps", cost: 0, name: "§l§aGPS§r", icon: "textures/goe/spa/ui/gps_app" },
	{ id: "flashlight", cost: 0, name: "§l§1Flashlight§r", icon: "textures/goe/spa/ui/flashlight" },
	{ id: "mob_detector", cost: 0, name: "§l§4Mob Detector§r", icon: "textures/goe/spa/ui/mob_detector" },
	// { id: "weather", cost: 0, name: "§l§3Weather§r", icon: "textures/goe/spa/ui/weather_app" },
	// { id: "day_time", cost: 0, name: "§l§dDay Time§r", icon: "textures/goe/spa/ui/day_time_app" },
  { id: "color_customizer", cost: 0, name: "§l§5Color Customizer§r", icon: "textures/goe/spa/ui/color_customizer" },
	{ id: "play_music", cost: 40, name: "§l§dMusic§r", icon: "textures/goe/spa/ui/play_music", particle: "goe_spa:music" },
	{ id: "warp", cost: 80, name: "§l§5TP Warp§r", icon: "textures/goe/spa/ui/warp_app", particle: "goe_spa:tp_warp" },
  { id: "memo", cost: 20, name: "§l§6Memo§r", icon: "textures/goe/spa/ui/notes", particle: "goe_spa:memo" },
  { id: "fitness", cost: 20, name: "§l§aFitness§r", icon: "textures/goe/spa/ui/fitness_app", particle: "goe_spa:fitness" },
  { id: "survival_stats", cost: 20, name: "§l§8Survival Stats§r", icon: "textures/goe/spa/ui/survival_stats", particle: "goe_spa:survival_stats" },
  // { id: "gear_market", cost: 80, name: "§l§tGear Market§r", icon: "textures/goe/spa/ui/gear_market", particle: "goe_spa:gear_market" },
  { id: "food_store", cost: 40, name: "§l§aFood Stop§r", icon: "textures/goe/spa/ui/supplies_shop", particle: "goe_spa:food_stop" },
  // { id: "effect_store", cost: 80, name: "§l§4Effects Pro§r", icon: "textures/goe/spa/ui/effect_shop", particle: "goe_spa:effects_pro" },
  // { id: "enchantment_store", cost: 80, name: "§l§5Enchantment§r", icon: "textures/goe/spa/ui/enchantment_store", particle: "goe_spa:enchantment" },
  { id: "satellite_view", cost: 40, name: "§l§3Satellite View§r", icon: "textures/goe/spa/ui/satellite_view", particle: "goe_spa:satellite_view" },
  // { id: "ore_detector", cost: 80, name: "§l§tOre Detector§r", icon: "textures/goe/spa/ui/ore_detector", particle: "goe_spa:ore_detector" },
  { id: "builder", cost: 40, name: "§l§tInstant Builder§r", icon: "textures/goe/spa/ui/builder_app", particle: "goe_spa:builder" },
  { id: "coin_clicker", cost: 240, name: "§l§6Coin Clicker§r", icon: "textures/goe/spa/ui/coin_clicker", particle: "goe_spa:coin_clicker" },
  { id: "guess_the_number", cost: 20, name: "§l§8Guess the Number§r", icon: "textures/goe/spa/ui/guess_the_number", particle: "goe_spa:guess_the_number" },
  { id: "math_wiz_quiz", cost: 20, name: "§l§tMath Wiz Quiz§r", icon: "textures/goe/spa/ui/math_wiz_quiz", particle: "goe_spa:math_quiz" },
  { id: "realism_settings", cost: 20, name: "§l§5VFX Settings§r", icon: "textures/goe/spa/ui/realism_settings", particle: "goe_spa:vfx_settings" },
  { id: "about_smartphone", cost: 0, name: "§l§3About Smartphone§r", icon: "textures/goe/spa/ui/about_phone" },
];

export const phoneColors = [
  {color: "§fWhite", cost: 1, phone: "goe_spa:white_smartphone_hud", icon: "textures/goe/spa/items/phones/white"},
  {color: "§6Orange", cost: 1, phone: "goe_spa:orange_smartphone_hud", icon: "textures/goe/spa/items/phones/orange"},
  {color: "§dMagenta", cost: 1, phone: "goe_spa:magenta_smartphone_hud", icon: "textures/goe/spa/items/phones/magenta"},
  {color: "§bLight blue", cost: 1, phone: "goe_spa:light_blue_smartphone_hud", icon: "textures/goe/spa/items/phones/light_blue"},
  {color: "§eYellow", cost: 1, phone: "goe_spa:yellow_smartphone_hud", icon: "textures/goe/spa/items/phones/yellow"},
  {color: "§aLime", cost: 1, phone: "goe_spa:lime_smartphone_hud", icon: "textures/goe/spa/items/phones/lime"},
  {color: "§dPink", cost: 1, phone: "goe_spa:pink_smartphone_hud", icon: "textures/goe/spa/items/phones/pink"},
  {color: "§8Gray", dark_background: "§7Gray", cost: 1, phone: "goe_spa:dark_gray_smartphone_hud", icon: "textures/goe/spa/items/phones/dark_gray"},
  {color: "§8Light Gray", dark_background: "§7Light Gray", cost: 1, phone: "goe_spa:light_gray_smartphone_hud", icon: "textures/goe/spa/items/phones/light_gray"},
  {color: "§3Cyan", cost: 1, phone: "goe_spa:cyan_smartphone_hud", icon: "textures/goe/spa/items/phones/cyan"},
  {color: "§5Purple", cost: 1, phone: "goe_spa:purple_smartphone_hud", icon: "textures/goe/spa/items/phones/purple"},
  {color: "§1Blue", cost: 1, phone: "goe_spa:blue_smartphone_hud", icon: "textures/goe/spa/items/phones/blue"},
  {color: "§6Brown", cost: 1, phone: "goe_spa:brown_smartphone_hud", icon: "textures/goe/spa/items/phones/brown"},
  {color: "§2Green", cost: 1, phone: "goe_spa:green_smartphone_hud", icon: "textures/goe/spa/items/phones/green"},
  {color: "§4Red", cost: 1, phone: "goe_spa:red_smartphone_hud", icon: "textures/goe/spa/items/phones/red"},
  {color: "§0Black", dark_background: "§8Black", cost: 1, phone: "goe_spa:black_smartphone_hud", icon: "textures/goe/spa/items/phones/black"},
  {color: "§8Iron", dark_background: "§7Iron", cost: 5, phone: "goe_spa:iron_smartphone_hud", icon: "textures/goe/spa/items/phones/iron"},
  {color: "§6Gold", cost: 5, phone: "goe_spa:gold_smartphone_hud", icon: "textures/goe/spa/items/phones/gold"},
  {color: "§bDiamond", cost: 5, phone: "goe_spa:diamond_smartphone_hud", icon: "textures/goe/spa/items/phones/diamond"},
  {color: "§aEmerald", cost: 5, phone: "goe_spa:emerald_smartphone_hud", icon: "textures/goe/spa/items/phones/emerald"},
  {color: "§5Netherite", cost: 5, phone: "goe_spa:netherite_smartphone_hud", icon: "textures/goe/spa/items/phones/netherite"},
]

export const foods = [
  { id: "goe_spa:bannana", name: "\u00A72Banana", cost: 2, icon: "textures/goe/spa/items/food/bannana", restores: 2 },
  { id: "goe_spa:pineapple", name: "\u00A72Pineapple", cost: 2, icon: "textures/goe/spa/items/food/pineapple", restores: 2 },
  { id: "goe_spa:strawberry", name: "\u00A72Strawberry", cost: 2, icon: "textures/goe/spa/items/food/strawberry", restores: 2 },
  { id: "goe_spa:coffee", name: "\u00A72Coffee", cost: 4, icon: "textures/goe/spa/items/food/coffee", restores: 2.5 },
  { id: "goe_spa:strawberry_shake", name: "\u00A72Strawberry Shake", cost: 4, icon: "textures/goe/spa/items/food/strawberry_shake", restores: 3 },
  { id: "goe_spa:milkshake", name: "\u00A72Milkshake", cost: 4, icon: "textures/goe/spa/items/food/milkshake", restores: 3 },
  { id: "goe_spa:choco_bar", name: "\u00A72Choco Bar", cost: 8, icon: "textures/goe/spa/items/food/choco_bar", restores: 2.5 },
  { id: "goe_spa:ice_cream", name: "\u00A72Ice Cream", cost: 8, icon: "textures/goe/spa/items/food/ice_cream", restores: 3 },
  { id: "goe_spa:hamburger", name: "\u00A72Hamburger", cost: 8, icon: "textures/goe/spa/items/food/hamburger", restores: 4 },
  { id: "goe_spa:pizza", name: "\u00A72Pizza§r", cost: 8, icon: "textures/goe/spa/items/food/pizza", restores: 4 }
];

export const gear = [
  { 
      name: "§8Iron Gear", 
      items: [ 
          { id: "minecraft:iron_sword", name: "\u00A78Iron Sword", cost: 5, icon: "textures/items/iron_sword", nameInPackage: "\u00A77Iron Sword" },
          { id: "minecraft:iron_helmet", name: "\u00A78Iron Helmet", cost: 10, icon: "textures/items/iron_helmet", nameInPackage: "\u00A77Iron Helmet" },
          { id: "minecraft:iron_chestplate", name: "\u00A78Iron Chestplate", cost: 20, icon: "textures/items/iron_chestplate", nameInPackage: "\u00A77Iron Chestplate" },
          { id: "minecraft:iron_leggings", name: "\u00A78Iron Leggings", cost: 15, icon: "textures/items/iron_leggings", nameInPackage: "\u00A77Iron Leggings" },
          { id: "minecraft:iron_boots", name: "\u00A78Iron Boots", cost: 10, icon: "textures/items/iron_boots", nameInPackage: "\u00A77Iron Boots" },
          { id: "minecraft:iron_pickaxe", name: "\u00A78Iron Pickaxe", cost: 5, icon: "textures/items/iron_pickaxe", nameInPackage: "\u00A77Iron Pickaxe" },
          { id: "minecraft:iron_shovel", name: "\u00A78Iron Shovel", cost: 5, icon: "textures/items/iron_shovel", nameInPackage: "\u00A77Iron Shovel" },
          { id: "minecraft:iron_axe", name: "\u00A78Iron Axe", cost: 5, icon: "textures/items/iron_axe", nameInPackage: "\u00A77Iron Axe" },
          { id: "minecraft:iron_hoe", name: "\u00A78Iron Hoe", cost: 5, icon: "textures/items/iron_hoe", nameInPackage: "\u00A77Iron Hoe" },
      ], 
      icon: "textures/items/iron_chestplate"
  },

  { 
      name: "§bDiamond Gear", 
      items: [ 
          { id: "minecraft:diamond_sword", name: "\u00A7bDiamond Sword", cost: 50, icon: "textures/items/diamond_sword" },
          { id: "minecraft:diamond_helmet", name: "\u00A7bDiamond Helmet", cost: 100, icon: "textures/items/diamond_helmet" },
          { id: "minecraft:diamond_chestplate", name: "\u00A7bDiamond Chestplate", cost: 150, icon: "textures/items/diamond_chestplate" },
          { id: "minecraft:diamond_leggings", name: "\u00A7bDiamond Leggings", cost: 100, icon: "textures/items/diamond_leggings" },
          { id: "minecraft:diamond_boots", name: "\u00A7bDiamond Boots", cost: 50, icon: "textures/items/diamond_boots" },
          { id: "minecraft:diamond_pickaxe", name: "\u00A7bDiamond Pickaxe", cost: 50, icon: "textures/items/diamond_pickaxe" },
          { id: "minecraft:diamond_shovel", name: "\u00A7bDiamond Shovel", cost: 50, icon: "textures/items/diamond_shovel" },
          { id: "minecraft:diamond_axe", name: "\u00A7bDiamond Axe", cost: 50, icon: "textures/items/diamond_axe" },
          { id: "minecraft:diamond_hoe", name: "\u00A7bDiamond Hoe", cost: 50, icon: "textures/items/diamond_hoe" },
      ], 
      icon: "textures/items/diamond_chestplate"
  },

  { 
      name: "§5Netherite Gear", 
      items: [ 
          { id: "minecraft:netherite_sword", name: "\u00A75Netherite Sword", cost: 150, icon: "textures/items/netherite_sword" },
          { id: "minecraft:netherite_helmet", name: "\u00A75Netherite Helmet", cost: 150, icon: "textures/items/netherite_helmet" },
          { id: "minecraft:netherite_chestplate", name: "\u00A75Netherite Chestplate", cost: 200, icon: "textures/items/netherite_chestplate" },
          { id: "minecraft:netherite_leggings", name: "\u00A75Netherite Leggings", cost: 150, icon: "textures/items/netherite_leggings" },
          { id: "minecraft:netherite_boots", name: "\u00A75Netherite Boots", cost: 150, icon: "textures/items/netherite_boots" },
          { id: "minecraft:netherite_pickaxe", name: "\u00A75Netherite Pickaxe", cost: 150, icon: "textures/items/netherite_pickaxe" },
          { id: "minecraft:netherite_shovel", name: "\u00A75Netherite Shovel", cost: 150, icon: "textures/items/netherite_shovel" },
          { id: "minecraft:netherite_axe", name: "\u00A75Netherite Axe", cost: 150, icon: "textures/items/netherite_axe" },
          { id: "minecraft:netherite_hoe", name: "\u00A75Netherite Hoe", cost: 150, icon: "textures/items/netherite_hoe" },
      ], 
      icon: "textures/items/netherite_chestplate"
  },

  { 
      name: "§6Advanced Gear", 
      items: [ 
          { id: "minecraft:bow", name: "\u00A76Bow", cost: 5, icon: "textures/items/bow_standby" },
          { id: "minecraft:crossbow", name: "\u00A76Crossbow", cost: 10, icon: "textures/items/crossbow_standby" },
          { id: "minecraft:arrow", name: "\u00A76Arrow x16", cost: 5, icon: "textures/items/arrow" },
          { id: "minecraft:trident", name: "\u00A76Trident", cost: 50, icon: "textures/items/trident" },
          { id: "minecraft:shield", name: "\u00A76Shield", cost: 5, icon: "textures/goe/spa/ui/shield_icon" },
          { id: "minecraft:totem_of_undying", name: "\u00A76Totem Of Undying", cost: 100, icon: "textures/items/totem" },
      ], 
      icon: "textures/items/crossbow_standby"
  },
];

export const effects = [
  { name: "Speed", cost: [ 25, 50, 75 ], duration: [ 120, 120, 120 ], icon: "textures/ui/speed_effect" },
  { name: "Jump Boost", cost: [ 25, 50, 75 ], duration: [ 120, 120, 120 ], icon: "textures/ui/jump_boost_effect" },
  { name: "Haste", cost: [ 25, 50, 75 ], duration: [ 120, 120, 120 ], icon: "textures/ui/haste_effect" },
  { name: "Night Vision", cost: [ 25 ], duration: [ 120, 120, 120 ], icon: "textures/ui/night_vision_effect" },
  { name: "Invisibility", cost: [ 25 ], duration: [ 120, 120, 120 ], icon: "textures/ui/invisibility_effect" },
  { name: "Resistance", cost: [ 35, 70, 1050 ], duration: [ 120, 120, 120 ], icon: "textures/ui/resistance_effect" },
  { name: "Fire Resistance", cost: [ 35, 70, 1050 ], duration: [ 120, 120, 120 ], icon: "textures/ui/fire_resistance_effect" },
  { name: "Regeneration", cost: [ 35, 70, 105 ], duration: [ 120, 120, 120 ], icon: "textures/ui/regeneration_effect" },
  { name: "Strength", cost: [ 35, 70, 105 ], duration: [ 120, 120, 120 ], icon: "textures/ui/strength_effect" },
  { name: "Absorption", cost: [ 35, 70, 105 ], duration: [ 120, 120, 120 ], icon: "textures/ui/absorption_effect" },
  { name: "Clear bad effects", cost: [ 25 ], duration: [ 1 ], icon: "textures/items/bucket_milk" }
];

export const badEffects = [
  "Poison",
  "Wither",
  "Blindness",
  "Slowness",
  "Weakness",
  "Mining Fatigue",
  "Instant Damage",
  "Levitation",
  "Nausea",
  "Bad Luck",
  "Hunger",
  "Darkness"
];

export const enchantments = [
  { type: "efficiency", name: "\u00A75Efficiency", cost: [ 15, 25, 50, 75, 100 ], icon: "textures/goe/spa/ui/enchantment" },
  { type: "fortune", name: "\u00A75Fortune", cost: [ 25, 50, 75 ], icon: "textures/goe/spa/ui/enchantment" },
  { type: "unbreaking", name: "\u00A75Unbreaking", cost: [ 25, 50, 75 ], icon: "textures/goe/spa/ui/enchantment" },
  { type: "silk_touch", name: "\u00A75Silk Touch", cost: [ 75 ], icon: "textures/goe/spa/ui/enchantment" },
  { type: "mending", name: "\u00A75Mending", cost: [ 100 ], icon: "textures/goe/spa/ui/enchantment" },
  { type: "sharpness", name: "\u00A75Sharpness", cost: [ 15, 25, 50, 75, 100 ], icon: "textures/goe/spa/ui/enchantment" },
  { type: "looting", name: "\u00A75Looting", cost: [ 25, 50, 75 ], icon: "textures/goe/spa/ui/enchantment"  },
  { type: "knockback", name: "\u00A75Knockback", cost: [ 25, 50 ], icon: "textures/goe/spa/ui/enchantment"  },
  { type: "fire_aspect", name: "\u00A75Fire Aspect", cost: [ 25, 50 ], icon: "textures/goe/spa/ui/enchantment"  },
  { type: "breach", name: "\u00A75Breach", cost: [ 15, 25, 50, 75 ], icon: "textures/goe/spa/ui/enchantment"  },
  { type: "density", name: "\u00A75Density", cost: [ 15, 25, 50, 75, 100 ], icon: "textures/goe/spa/ui/enchantment" },
  { type: "wind_burst", name: "\u00A75Wind Burst", cost: [ 15, 30, 45 ], icon: "textures/goe/spa/ui/enchantment"  },
  { type: "channeling", name: "\u00A75Channeling", cost: [ 50 ], icon: "textures/goe/spa/ui/enchantment" },
  { type: "flame", name: "\u00A75Flame", cost: [ 50 ], icon: "textures/goe/spa/ui/enchantment" },
  { type: "impaling", name: "\u00A75Impaling", cost: [ 15, 25, 50, 75, 100 ], icon: "textures/goe/spa/ui/enchantment" },
  { type: "infinity", name: "\u00A75Infinity", cost: [ 75 ], icon: "textures/goe/spa/ui/enchantment" },
  { type: "loyalty", name: "\u00A75Loyalty", cost: [ 15, 25, 50 ], icon: "textures/goe/spa/ui/enchantment" },
  { type: "riptide", name: "\u00A75Riptide", cost: [ 15, 25, 50 ], icon: "textures/goe/spa/ui/enchantment" },
  { type: "multishot", name: "\u00A75Multishot", cost: [ 50 ], icon: "textures/goe/spa/ui/enchantment" },
  { type: "piercing", name: "\u00A75Piercing", cost: [ 15, 25, 50, 75 ], icon: "textures/goe/spa/ui/enchantment" },
  { type: "power", name: "\u00A75Power", cost: [ 15, 25, 50, 75, 100 ], icon: "textures/goe/spa/ui/enchantment" },
  { type: "punch", name: "\u00A75Punch", cost: [ 25, 50 ], icon: "textures/goe/spa/ui/enchantment" },
  { type: "quick_charge", name: "\u00A75Quick Charge", cost: [ 15, 25, 50 ], icon: "textures/goe/spa/ui/enchantment" },
  { type: "luck_of_the_sea", name: "\u00A75Luck of the Sea", cost: [ 15, 25, 50 ], icon: "textures/goe/spa/ui/enchantment" },
  { type: "lure", name: "\u00A75Lure", cost: [ 15, 25, 50 ], icon: "textures/goe/spa/ui/enchantment" },
  { type: "protection", name: "\u00A75Protection", cost: [ 25, 50, 75, 100 ], icon: "textures/goe/spa/ui/enchantment" },
  { type: "thorns", name: "\u00A75Thorns", cost: [ 25, 50, 75 ], icon: "textures/goe/spa/ui/enchantment" },
  { type: "feather_falling", name: "\u00A75Feather Falling", cost: [ 15, 25, 50, 75 ], icon: "textures/goe/spa/ui/enchantment" },
  { type: "depth_strider", name: "\u00A75Depth Strider", cost: [ 15, 25, 50 ], icon: "textures/goe/spa/ui/enchantment" },  
  { type: "respiration", name: "\u00A75Respiration", cost: [ 15, 25, 50 ], icon: "textures/goe/spa/ui/enchantment" },
  { type: "frost_walker", name: "\u00A75Frost Walker", cost: [ 25, 50 ], icon: "textures/goe/spa/ui/enchantment" }
];

export const builds = [
  { id: "goe_spa:watchtower", name: "\u00A70Watchtower", cost: 120, yOffset: -1, size: 13, icon: "textures/goe/spa/items/builds/watchtower", nameInPackage: "\u00A77Watchtower" },                                                                            
  { id: "goe_spa:starter_house", name: "\u00A73Farm House", cost: 80, yOffset: -1, size: 21, icon: "textures/goe/spa/items/builds/starter_house" },
  { id: "goe_spa:crop_farm", name: "\u00A7aCrop Farm", cost: 80, yOffset: -1, size: 17, icon: "textures/goe/spa/items/builds/crop_farm", nameInPackage: "\u00A72Crop Farm" },
  { id: "goe_spa:underground_bunker", name: "\u00A78Underground Bunker", cost: 80, yOffset: -17, size: 29, icon: "textures/goe/spa/items/builds/underground_bunker", nameInPackage: "\u00A77Underground Bunker" },
  { id: "goe_spa:tree_house", name: "\u00A7nTree House", cost: 80, yOffset: -1, size: 29, icon: "textures/goe/spa/items/builds/tree_house" },
  { id: "goe_spa:animal_barn", name: "\u00A76Animal Barn", cost: 80, yOffset: -1, size: 23, icon: "textures/goe/spa/items/builds/animal_barn", nameInPackage: "\u00A7eAnimal Barn" },
  { id: "goe_spa:windmill", name: "\u00A76Windmill", cost: 80, yOffset: -1, size: 25, icon: "textures/goe/spa/items/builds/windmill", nameInPackage: "\u00A7eWindmill" },
  { id: "goe_spa:village_well", name: "\u00A71Fountain", cost: 40, yOffset: -1, size: 21, icon: "textures/goe/spa/items/builds/village_well", nameInPackage: "\u00A79Fountain" },
  { id: "goe_spa:villager_statue", name: "\u00A7dVillager Statue", cost: 40, yOffset: -1, size: 13, icon: "textures/goe/spa/items/builds/villager_statue" },
  { id: "goe_spa:townhouse", name: "\u00A73Town House", cost: 120, yOffset: -1, size: 29, icon: "textures/goe/spa/items/builds/townhouse" }
];
export function GetBuildById(buildId)
{
  for(const build of builds)
  {
    if (build.id === buildId)
      return build;
  }
  return undefined;
}

export const buttonLoc = {
  NNW:  { x: -1, y: 0, z: -3},
  NNE: { x: 1, y: 0, z: -3},
  SSW: { x: -1, y: 0, z: 3},
  SSE: { x: 1, y: 0, z: 3},
  WNW: { x: -3, y: 0, z: -1},
  ENE: { x: 3, y: 0, z: -1},
  WSW: { x: -3, y: 0, z: 1},
  ESE: { x: 3, y: 0, z: 1}
}

export const buildLoad = {
  
  "south": { NW: { x: -1, y:0, z:0}, SE: {x: 1, y: 1, z: 3}, degrees: 180,  facing: Vector3.North,
            border: {x: 0, y: 0, z: 4.5}, text: {x: 0, y: 1, z: 3}, confirm: buttonLoc.SSE, cancel: buttonLoc.SSW },

  "north": { NW: { x: -1, y:0, z:-3}, SE: {x: 1, y: 1, z: 0}, degrees: 0, facing: Vector3.South,
            border: {x: 0, y: 0, z: -3.5}, text: {x: 0, y: 1, z: -3}, confirm: buttonLoc.NNW, cancel: buttonLoc.NNE },

  "east": { NW: { x: 0, y:0, z:-1}, SE: {x: 3, y: 1, z: 1}, degrees: 90, facing: Vector3.West,
            border: {x: 4.5, y: 0, z: 0}, text: {x: 3, y: 1, z: 0}, confirm: buttonLoc.ENE, cancel: buttonLoc.ESE },

  "west": { NW: { x: -3, y:0, z:-1}, SE: {x: 0, y: 1, z: 1}, degrees: 270, facing: Vector3.East,
            border: {x: -3.5, y: 0, z: 0}, text: {x: -3, y: 1, z: 0}, confirm: buttonLoc.WSW, cancel: buttonLoc.WNW }

}

export const CoinClicker = {
  generator: [
    { rate: 30, upgrade: 300 }, // 1 coin every 30s, upgrade to next level 300 coins
    { rate: 25, upgrade: 360 },
    { rate: 20, upgrade: 480 },
    { rate: 15, upgrade: 720 },
    { rate: 10, upgrade: undefined },
  ],
  requiredClicks: [ 5, 10, 20, 40, 50 ],
  maxClickCoinsPerDay: 10
}

export const RealismData = {
  effects: [
    { name: "Sun Rays", effect: "sunLight", cost: 0, property: "goe_spa_sun_light", color: "§6", icon: "textures/goe/spa/ui/sun_rays" },
    { name: "Birds", effect: "birds", cost: 40, property: "goe_spa_birds", color: "§9", icon: "textures/goe/spa/ui/birds" },
    { name: "Wind", effect: "wind", cost: 20, property: "goe_spa_wind", color: "§8", icon: "textures/goe/spa/ui/wind" },
    { name: "Rainbow", effect: "rainbow", cost: 60, property: "goe_spa_rainbow", color: "§5", icon: "textures/goe/spa/ui/rainbow" },
    { name: "Fog", effect: "fog", cost: 80, property: "goe_spa_fog", color: "§3", icon: "textures/goe/spa/ui/fog" },
  ],
  birds: {
    spawnInterval: 70, // 7s
    particles: [
      "goe_spa:sky_birds"
    ]
  },
  mist: {
    normalInterval: 1, // 1s
  },
  wind: {
    normalInterval: 2, // 0.03s
    rainInterval: 1,
  },
  sand: {
    normalInterval: 20, // 1s
    rainInterval: 2,
  },
  light: {
    sun: { 23200: -800, 23600: -350, 0: 100, 1000: 1200, 2000: 2300, 3000: 3350, 4000: 4300, 5000: 5200,
          6000: 6000, 7000: 6800, 8000: 7700, 9000: 8600, 10000: 9650, 11000: 10700, 12000: 11900, 12800: 12800 },
    moon: { 12800: -800, 13500: 100, 14000: 700, 15000: 2000, 16000: 3300, 17000: 4700, 18000: 6000,
          9000: 7300, 20000: 8700, 21000: 10000, 22000: 11300, 23000: 12500, 23200: 12800 },
    distance: 55
  }
}

function interpolateTime(input, isDaytime) {
  let values = isDaytime ? RealismData.light.sun : RealismData.light.moon;
  let keys = Object.keys(values).map(key => parseFloat(key));
  
  // Sort keys to ensure correct order
  keys.sort((a, b) => a - b);
  
  let lowerKey = null;
  let upperKey = null;
  
  // Find the lower and upper bounds for the input
  for (let key of keys) {
      if (key <= input) {
          lowerKey = key;
      }
      else{
          upperKey = key;
          break;
      }
  }

  // Handle edge cases where the input is out of bounds
  if (lowerKey === null) {
      // Input is below the first point
      return values[keys[0]];
  }
  if (upperKey === null) {
      // Input is above the last point
      return values[keys[keys.length - 1]];
  }

  // Linear interpolation
  let lowerValue = values[lowerKey];
  let upperValue = values[upperKey];
  let ratio = (input - lowerKey) / (upperKey - lowerKey);
  
  return lowerValue + ratio * (upperValue - lowerValue);
}
function getLightAngle(time, isDaytime) {
  let fixedTime = interpolateTime(time, isDaytime); 
  let lightAngle = utils.mapRange(fixedTime, -800, 12800, 0, 180);
  lightAngle = utils.convertToRadians(lightAngle);
  return lightAngle;
}
export function getLightOffset(time, isDaytime)
{
  let lightAngle = getLightAngle(time, isDaytime);
  const x = RealismData.light.distance * Math.cos(lightAngle);
  const y = RealismData.light.distance * Math.sin(lightAngle);

  return { x: x, y: y, z: 0 };
}

export function ownedApps(player)
{
  return apps.filter(app => (app.cost === 0) || playerOwnsApp(player, app));
}
export function appsForSale(player)
{
  return apps.filter(app => (app.cost > 0) && !playerOwnsApp(player, app));
}

export function playerOwnsApp(player, app)
{
  if (typeof app === "string")
    app = getAppData(app);

  return app.cost === 0 || player.hasTag(getAppTag(app));
}

export function getAppTag(appData)
{
  return `goe_spa_${appData.id}_owned`;
}

export function getAppData(appId)
{
	let appIndex = apps.findIndex((element) => (element.id === appId));
	return apps[appIndex];
}
export function getEnchantData(enchantId)
{
	let enchantIndex = enchants.findIndex((element) => (element.id === enchantId));
	return enchants[enchantIndex];
}