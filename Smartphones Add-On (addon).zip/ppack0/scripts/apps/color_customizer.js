import { ActionFormData } from "@minecraft/server-ui";
import * as utils from "../utils";
import * as inventory_utils from "../inventory_utils";
import * as gld from "../gld";
import * as battery from "../battery";
import * as wallet from "../wallet";
import { showApp as main_menu, checkDepletedBattery } from "./main_menu";
import { showApp as finances } from "./bank";

export async function showApp(player){

    if (await checkDepletedBattery(player))
        return;

    let Customizer = new ActionFormData()
    .title(gld.getAppData("color_customizer").name)
    .body(`${gld.getScreenTitle(player)}\n\n§fUse this app to customize your phone.\n\nChoose color:`);

    let phoneColors = gld.phoneColors;
    for (const phoneColors of gld.phoneColors)
    {
        let costColor = wallet.canAfford(player, phoneColors.cost) ? "§l§a" : "§l§c";
        Customizer = Customizer.button(`§l${phoneColors.color}\n${costColor} Cost: ${phoneColors.cost} ${gld.coinSymbol}`, phoneColors.icon);
    }

    Customizer.button(gld.backButton.name, gld.backButton.icon);

    Customizer.show(player).then((response) => {
        inventory_utils.replacePhoneIfUIClosed(player, response);
        let playerPressed = response.selection;
        if (playerPressed == undefined)
            return;

        if (playerPressed < phoneColors.length) {
            let selectedColor = phoneColors[playerPressed];
            if (wallet.canAfford(player, selectedColor.cost)){
                inventory_utils.changePhoneColor(player, selectedColor.phone, selectedColor.cost);
            } else {
                player.playSound("goe_spa:reject");
                showCantAffordForm(player, selectedColor.color, selectedColor.cost);
            }
        } else {
            switch(playerPressed - phoneColors.length) {
                case 0:
                    player.playSound("goe_spa:button_click");
                    main_menu(player)
                    break;
            }
        }
    });
}

async function showCantAffordForm(player, color, cost) {
    let displayColor = color;
    gld.phoneColors.forEach(c => {
        if (c.color === color && c.dark_background){
            displayColor = c.dark_background
        }
    });
    const CantAffordForm = new ActionFormData();
    CantAffordForm.title(gld.getAppData("color_customizer").name);
    CantAffordForm.body(
        gld.getScreenTitle(player) +
        `\nNot enough Smartcoins (§6${gld.coinSymbol}§r).\n\n` +
        `  §l${displayColor}§r\n\n` + 
        `§cCost:      ${cost} ${gld.coinSymbol}§r\n` + 
        `§4Missing:   ${cost - wallet.getBalance(player)} ${gld.coinSymbol}§r\n\n`
    );
    CantAffordForm.button("§eGet Smartcoins", gld.getAppData("bank").icon);
    CantAffordForm.button(gld.backButton.name, gld.backButton.icon);

    CantAffordForm.show(player).then((response) => {
        player.playSound("goe_spa:button_click");

        if (response.selection == 0) {
            finances(player);
            return;
        }

        showApp(player);
    });
}