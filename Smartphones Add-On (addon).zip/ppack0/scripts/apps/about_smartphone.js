import { ActionFormData } from "@minecraft/server-ui";
import * as inventory_utils from "../inventory_utils";
import * as gld from "../gld";
import { showApp as main_menu } from "./main_menu";

const aboutSmartphoneName = gld.getAppData("about_smartphone");

export async function showApp(player){ 

  const freeAppsCount = gld.apps.filter(app => app.cost === 0).length;
  const paidAppsCount = gld.apps.filter(app => app.cost > 0).length;

  const AboutSmartphoneApp = new ActionFormData()
  .title(aboutSmartphoneName.name)
  .body( 
    `${gld.getScreenTitle(player)}`+
    `The Smartphone is a useful device for various needs. Apps can be installed on it, and it provides lots of utility for your Minecraft experience.\n\n`+

    `§bHere are a few tips:§r\n`+
    `1) The Smartphone is easy to use and super fun. Just press on any of the installed apps to use them, and if you wish to purchase new apps, open the app store.\n\n`+

    `2) The Smartphone comes with a few installed apps and with a few premium apps that you can purchase later on. Premium apps cost smartcoins, which you can get in the Finances app.\n\n`+

    `3) The Smartphone uses battery when it's open. When the battery level drops, you can charge the Smartphone with a Smartphone Battery. Merge a Smartphone with a Smartphone Battery in a crafting table to charge the Smartphone to full power.\n\n`+

    `4) Smartphone Battery recipe:\n`+
    `[ ] [I] [ ]\n`+
    `§6[G]§r §c[R]§r §6[G]§r\n`+
    `[I] [I] [I]\n\n`+

    `§6[G] "Gold Ingot"§r\n`+
    `§c[R] "Block of Redstone"§r\n`+
    `[I] "Iron Ingot"\n\n`+

    `5) Smartphone recipe:\n` +
    `§d[D] [D] [D]\n` +
    `§d[D] §c[R] §d[D]\n` +
    `§d[D] §b[B] §d[D]\n\n` +

    `§d[D] "Any Dye/Raw Iron/Raw Gold/Diamond/Emerald/Netherite Scraps"§r\n` + 
    `§c[R] "Block of Redstone"§r\n` +
    `§b[B] "Smartphone Battery"§r\n\n`+
    "§5Don't forget to give this Add-On a 5-star rating on the Marketplace.\n\n"+
    "§6            ⭐⭐⭐⭐⭐\n\n"
  );

    if(player.hasTag("goe_spa_oppened_first_time")) {
      AboutSmartphoneApp.button("Back", "textures/goe/spa/ui/back");
    } else {
      player.addTag("goe_spa_oppened_first_time");
      AboutSmartphoneApp.button("Main Menu", "textures/goe/spa/ui/about_phone");
    }

  AboutSmartphoneApp.show(player).then((response) => {
    inventory_utils.replacePhoneIfUIClosed(player, response);
      let playerPressed = response.selection;
      switch(playerPressed) {
        case 0:
          player.playSound("goe_spa:button_click");
          main_menu(player);
          break;
      }
  })
}