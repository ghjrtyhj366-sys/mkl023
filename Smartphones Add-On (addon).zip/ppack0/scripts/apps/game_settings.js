import { ModalFormData } from "@minecraft/server-ui";
import { world } from "@minecraft/server";
import * as utils from "../utils";
import * as inventory_utils from "../inventory_utils";
import * as gld from "../gld";
import { showApp as main_menu, checkDepletedBattery } from "./main_menu"; 

const gamemodes = ["Survival", "Creative", "Adventure"];
const gamemodes_index = {"survival": 0, "creative": 1, "adventure": 2};

const gameSettingsName = gld.getAppData("game_settings");

export async function showApp(player){
    if (await checkDepletedBattery(player))
        return;
    let playerCoins = player.getDynamicProperty("goe_spa_coins");

    let enablePvP = world.gameRules.pvp;
    let enableMobGriefing = world.gameRules.mobGriefing;
    let enableMobSpawning = world.gameRules.doMobSpawning;
    let enableLootDrop = world.gameRules.doMobLoot;
    let enableKeepInventory = world.gameRules.keepInventory;
    let showCoordinates = world.gameRules.showCoordinates;

    let currentGameMode = player.getGameMode();
    let gamemodeIndex = gamemodes_index[currentGameMode];

    const GameSettingsApp = new ModalFormData().title(`${gameSettingsName.name}`)
        .dropdown(`${gld.getScreenTitle(player)}§aGame mode:`, gamemodes, gamemodeIndex)
		.toggle("§7Show Coordinates", showCoordinates)
		.toggle("§cFriendly Fire", enablePvP)
		.toggle("§3Mob Griefing", enableMobGriefing)
		.toggle("§dMob Spawning", enableMobSpawning)
		.toggle("§6Entities Loot Drop", enableLootDrop)
		.toggle("§eKeep Inventory", enableKeepInventory);

    GameSettingsApp.show(player).then(formData => {
        inventory_utils.replacePhoneIfUIClosed(player, formData);
        if (formData.formValues)
        {
            let oldGameMode = currentGameMode;
            let oldPvP = enablePvP;
            let oldShowCoordinates = showCoordinates;
            let oldMobGriefing = enableMobGriefing;
            let oldMobSpawning = enableMobSpawning;
            let oldLootDrop = enableLootDrop;
            let oldKeepInventory = enableKeepInventory;

            currentGameMode = gamemodes[formData.formValues[0]];
            showCoordinates = formData.formValues[1];
            enablePvP = formData.formValues[2];
            enableMobGriefing = formData.formValues[3];
            enableMobSpawning = formData.formValues[4];
            enableLootDrop = formData.formValues[5];
            enableKeepInventory = formData.formValues[6];

            player.playSound("goe_spa:submit");
            updateParams(player, currentGameMode, oldGameMode, showCoordinates, oldShowCoordinates, enablePvP, oldPvP, enableMobGriefing, oldMobGriefing, enableMobSpawning, oldMobSpawning, enableLootDrop, oldLootDrop, enableKeepInventory, oldKeepInventory);
        }   
    });
}

function updateParams(player, gamemode, oldGameMode, showCoordinates, oldShowCoordinates, pvp, oldPvP, mobGriefing, oldMobGriefing, doMobSpawning, oldMobSpawning, doMobLoot, oldMobLoot, keepInventory, oldKeepInventory){
    //Gamemode
        player.setGameMode(gamemode.toLowerCase());
        if(gamemode.toLowerCase() !== oldGameMode.toLowerCase())
            world.sendMessage(`§b${player.name}§r changed his game mode to §c${gamemode}`);

    //Show Coordinates
        if(showCoordinates){
            utils.runPlayerCommand(player, "gamerule showCoordinates true");
            if(showCoordinates !== oldShowCoordinates) {
                world.sendMessage(`Show Coordinates is turned on`);
                world.sendMessage(`§f${player.name}§r turned "Show Coordinates" on`);
            }
        } else {
            utils.runPlayerCommand(player, "gamerule showCoordinates false");
            if(pvp !== oldPvP) {
                world.sendMessage(`Show Coordinates is turned off`);
                world.sendMessage(`§f${player.name}§r turned "Show Coordinates" off`);
            }
        }
        
    //PVP
        if(pvp){
            utils.runPlayerCommand(player, "gamerule pvp true");
            if(pvp !== oldPvP) {
                world.sendMessage(`Friendly Fire is turned on`);
                world.sendMessage(`§f${player.name}§r turned "Friendly Fire" on`);
            }
        } else {
            utils.runPlayerCommand(player, "gamerule pvp false");
            if(pvp !== oldPvP) {
                world.sendMessage(`Friendly Fire is turned off`);
                world.sendMessage(`§f${player.name}§r turned "Friendly Fire" off`);
            }
        }
    //MobGriefing
        if(mobGriefing){
            utils.runPlayerCommand(player, "gamerule mobGriefing true");
            if(mobGriefing !== oldMobGriefing) {
                world.sendMessage(`Mob Griefing is turned on`);
                world.sendMessage(`§f${player.name}§r turned "Mob Griefing" on`);
            }
        } else {
            utils.runPlayerCommand(player, "gamerule mobGriefing false");
            if(mobGriefing !== oldMobGriefing) {
                world.sendMessage(`Mob Griefing is turned off`);
                world.sendMessage(`§f${player.name}§r turned "Mob Griefing" off`);
            }
        }
    //MobSpawning
        if(doMobSpawning){
            utils.runPlayerCommand(player, "gamerule doMobSpawning true");
            if(doMobSpawning !== oldMobSpawning){
                world.sendMessage(`Mob Spawning is turned on`);
                world.sendMessage(`§f${player.name}§r turned "Mob Spawning" on`);
            }
        } else {
            utils.runPlayerCommand(player, "gamerule doMobSpawning false");
            if(doMobSpawning !== oldMobSpawning){
                world.sendMessage(`Mob Spawning is turned off`);
                world.sendMessage(`§f${player.name}§r turned "Mob Spawning" off`);
            }
        }
    //LootDrop
        if(doMobLoot){
            utils.runPlayerCommand(player, "gamerule doMobLoot true");
            if(doMobLoot !== oldMobLoot){
                world.sendMessage(`Entities Loot Drop is turned on`);
                world.sendMessage(`§f${player.name}§r turned "Entities Loot Drop" on`);
            }
        } else {
            utils.runPlayerCommand(player, "gamerule doMobLoot false");
            if(doMobLoot !== oldMobLoot){
                world.sendMessage(`Entities Loot Drop is turned off`);
                world.sendMessage(`§f${player.name}§r turned "Entities Loot Drop" off`);
            }
        }
    //KeepInventory
        if(keepInventory){
            utils.runPlayerCommand(player, "gamerule keepInventory true");
            if(keepInventory !== oldKeepInventory) {
                world.sendMessage(`Keep Inventory Drop is turned on`);
                world.sendMessage(`§f${player.name}§r turned "Keep Inventory" on`);
            }
        } else {
            utils.runPlayerCommand(player, "gamerule keepInventory false");
            if(keepInventory !== oldKeepInventory) {
                world.sendMessage(`Keep Inventory Drop is turned off`);
                world.sendMessage(`§f${player.name}§r turned "Keep Inventory" off`);
            }
        }
        main_menu(player);
}