import { world, system, EquipmentSlot } from "@minecraft/server";
import * as utils from "./utils";
import * as main_menu from "./apps/main_menu";
import * as flashlight_app from "./apps/flashlight";
import * as play_music_app from "./apps/play_music";
import * as survival_stats from "./apps/survival_stats";
import * as fitness from "./apps/fitness";
import * as battery from "./battery";
import * as gld from "./gld";
import * as satellite from "./apps/satellite";
import * as inventory_utils from "./inventory_utils";
import * as coin_clicker from "./apps/coin_clicker";
import * as delivery from "./apps/delivery";
import * as load_build from "./load_build";
import * as realism from "./apps/realism";
import * as biome_check from "./biome_check";

export async function onLoadFirstTime() {
}

export async function onLoad() {
  
}

let ticksPassed = 0;
export async function onTick() {
  await flashlight_app.onTick();
  await play_music_app.onTick();
  await fitness.onTick();
  await battery.onTick();
  await satellite.onTick();
  await survival_stats.onTick();
  await realism.onTick();

  if (++ticksPassed % 20 === 0) { // Every 1s
    delivery.onTick();
    biome_check.onTick();
  }
}

export async function onPlayerJoin(event) {
  const allPlayers = world.getAllPlayers();
  allPlayers.forEach(p => {
    if(p.id === event.playerId){
      p.setSpawnPoint({dimension : p.dimension, x : p.location.x, y : p.location.y, z : p.location.z});
      p.setDynamicProperty("goe_spa_coins", 0);
      p.setDynamicProperty("goe_spa_music", "");
    }
  });
}

export async function onPlayerSpawn(event) {
}

export async function onEntitySpawn(event) {
}

export async function onEntityHealthChanged(event) {
}

export async function onEntityHurt(event) {
  await satellite.onEntityHurt(event);
}

export async function onProjectileHitEntity(event) {
}

export async function onEntityDie(event) {
	const entity = event.deadEntity;
  await survival_stats.onEntityDie(event);  
  if (entity.typeId === "minecraft:player") 
		await main_menu.onEntityDie(event);
}

export async function onItemStartUse(event) {
}

export async function onItemUse(event) {
  let player = event.source
  let itemId = event.itemStack.typeId;

  if (player.hasTag("goe_spa_satellite_mode") || player.hasTag("goe_spa_ore_searching") || player.hasTag("goe_spa_app_purchased"))
    return;

  if (itemId.endsWith("_smartphone") || itemId.endsWith("_smartphone_hud")){
    utils.runPlayerCommand(player, "camera @s set minecraft:first_person");
    await main_menu.onItemUse(event);
  }

  if (itemId === "goe_spa:delivery_package") {
    await delivery.onItemUse(event);
  }

  await load_build.onItemUse(event);
}

export async function onItemUseBefore(event) {
}

export async function onItemStopUse(event) {
}

export async function onItemReleaseUse(event) {
}


export async function onEntityHitBlock(event) {
}

export async function onItemUseOn(event) {
}

export async function onPlayerBreakBlock(event) {
  await fitness.onPlayerBreakBlock(event);
}

export async function onScriptEventReceive(event) {
  if (event.id === "goe_spa:delivery_package")
    await delivery.onScriptEventReceive(event);

  if (event.id === "goe_spa:build")
    await load_build.onScriptEventReceive(event);
}

export async function onWeatherChange(event) {
  // await weather_app.onWeatherChange(event);
  // await realism.onWeatherChange(event);
}