import { world, system} from "@minecraft/server";

// Give new players an explainer book

function getPlayer() {
  const allPlayers = world.getAllPlayers();
  if (allPlayers.length === 0) {
    return undefined;
  }

  return allPlayers[0];
}

function getPlayerDimension() {
  const player = getPlayer();
  if (player === undefined) {
    return undefined;
  }
  return player.dimension;
}

function getPlayerLocation() {
  const player = getPlayer();
  if (player === undefined) {
    return undefined;
  }
  return player.location;
}

world.afterEvents.playerSpawn.subscribe((event) => {
    const player = event.player; // Player 
    const mbl_m_scoreboard = world.scoreboard.getObjective("mbl_road_player_new"); // scoreboard
    mbl_m_scoreboard?.addScore(player, 0);
    if(mbl_m_scoreboard?.getScore(player) === 0){ return  };
    if(mbl_m_scoreboard?.getScore(player) === 1){ return  };
    world.scoreboard.addObjective("mbl_road_player_new", "dummy");
  });

world.afterEvents.playerSpawn.subscribe((event) => {

	const player = event.player; // Player 
    const mbl_m_scoreboard = world.scoreboard.getObjective("mbl_road_player_new");
    const playerDimension = getPlayerDimension();
    const playerLocation = getPlayerLocation();
    mbl_m_scoreboard?.addScore(player, 0);
    if(mbl_m_scoreboard?.getScore(player) === 1){ return  };
    if(mbl_m_scoreboard?.getScore(player) === 0){playerDimension.spawnEntity("mbl_road:explainer_book", playerLocation); 
  };
    mbl_m_scoreboard?.addScore(player, 1);
});
