//อ่านพ่อมึงตายไอสัสเยสแม่
//แต่ขี้เกียจ Encode -^-
import * as mc from '@minecraft/server'
import * as ui from '@minecraft/server-ui'
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
mc.world.afterEvents.itemUse.subscribe(data => {
    const pl = data.source
    const item = data.itemStack
    if (item.typeId === `a:phone1`) {
        seamuww(pl)
    }
    if (item.typeId === `a:phone2`) {
        seamuww(pl)
    }
    if (item.typeId === `a:phone3`) {
        seamuww(pl)
    }
    if (item.typeId === `a:phone4`) {
        seamuww(pl)
    }
    if (item.typeId === `a:phone5`) {
        seamuww(pl)
    }
    if (item.typeId === `a:phone6`) {
        seamuww(pl)
    }
})
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function phone(pl) {
        const f = new ui.ActionFormData();
        f.title(`§l§cPhone`)
        f.body(`§l§f       •❅──────✧❅✦❅✧──────❅•\n§l§a    §e✦ §fเลือกโทรศัพท์ที่ต้องการได้เลยคับ §e✦\n `)
        f.button(`§lว่างเปล่า`, `textures/sea/phone4`)
        f.button(`§l§cนักดาบสีแดง`, `textures/sea/phone2`)
        f.button(`§l§bน้องนุ่มนิ่ม`, `textures/sea/phone3`)
        f.button(`§l§eน้องไข่ดาว`, `textures/sea/phone1`)
        f.button(`§lดาว`, `textures/sea/phone5`)
        f.button(`§lน้องคุโรมิ`, `textures/sea/phone6`)
        f.show(pl).then(res => {
            if (res.selection === 0) {
                pl.runCommandAsync(`replaceitem entity @s slot.weapon.mainhand 0 a:phone4`)
            }
            if (res.selection === 1) {
                pl.runCommandAsync(`replaceitem entity @s slot.weapon.mainhand 0 a:phone2`)
            }
            if (res.selection === 2) {
                pl.runCommandAsync(`replaceitem entity @s slot.weapon.mainhand 0 a:phone3`)
            }
            if (res.selection === 3) {
                pl.runCommandAsync(`replaceitem entity @s slot.weapon.mainhand 0 a:phone1`)
            }
            if (res.selection === 4) {
                pl.runCommandAsync(`replaceitem entity @s slot.weapon.mainhand 0 a:phone5`)
            }
            if (res.selection === 5) {
                pl.runCommandAsync(`replaceitem entity @s slot.weapon.mainhand 0 a:phone6`)
            }
        })
}
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function info(pl) {
        const f = new ui.ActionFormData();
        f.title(`§l§f• §cSea muww Emote §f•`)
                f.body(`§l§f       •❅──────✧❅✦❅✧──────❅•\n§l§cEmoteนี้ เป็นEmote แจกฟรีสำหรับ Bedrock  \nโปรดให้เครดิต เฟส : §fSea muww §c\nห้ามนำไปขายดัดแปลง จับได้ปรับ 1,000บาท \nมีปัญหาใดๆทักมาทางเฟส Sea muww\n§l§eสกิน512จากร้าน §fSea muww §eใช้ได้ในเวอร์ชั่น P4SK นะคับ ทักมาแก้ได้\n§l§f       •❅──────✧❅✦❅✧──────❅•\n`)
        f.button(`§lBack`, `textures/sea/info`)
        f.show(pl).then(res => {
            if (res.selection === 0) {
                seamuww(pl)
            }
        })
}
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function s1(pl) {
        const f = new ui.ActionFormData();
        f.title(`§l§cขนาดตัว`)
        f.body(`§l§f       •❅──────✧❅✦❅✧──────❅•\n§l§a    §e✦ §fเลือกขนาดตัวที่ต้องการได้เลยคับ §e✦\n `)
        f.button(`§lSize : 1.1`,`textures/sea/size`)
        f.button(`§lSize : 1.2`,`textures/sea/size`)
        f.button(`§lSize : 1.3`,`textures/sea/size`)
        f.button(`§lSize : 1.4`,`textures/sea/size`)
        f.button(`§lSize : 1.5`,`textures/sea/size`)
        f.show(pl).then(res => {
            if (res.selection === 0) {
                pl.runCommandAsync(`event entity @s Muww2`)
            }
            if (res.selection === 1) {
                pl.runCommandAsync(`event entity @s Muww3`)
            }
            if (res.selection === 2) {
                pl.runCommandAsync(`event entity @s Muww4`)
            }
            if (res.selection === 3) {
                pl.runCommandAsync(`event entity @s Muww5`)
            }
            if (res.selection === 4) {
                pl.runCommandAsync(`event entity @s Muww6`)
            }
        })
}
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function s2(pl) {
        const f = new ui.ActionFormData();
        f.title(`§l§cขนาดตัว`)
        f.body(`§l§f       •❅──────✧❅✦❅✧──────❅•\n§l§a    §e✦ §fเลือกขนาดตัวที่ต้องการได้เลยคับ §e✦\n `)
        f.button(`§lSize : 0.4`,`textures/sea/size`)
        f.button(`§lSize : 0.5`,`textures/sea/size`)
        f.button(`§lSize : 0.6`,`textures/sea/size`)
        f.button(`§lSize : 0.7`,`textures/sea/size`)
        f.button(`§lSize : 0.8`,`textures/sea/size`)
        f.show(pl).then(res => {
            if (res.selection === 0) {
                pl.runCommandAsync(`event entity @s Muwwx1`)
            }
            if (res.selection === 1) {
                pl.runCommandAsync(`event entity @s Muwwx2`)
            }
            if (res.selection === 2) {
                pl.runCommandAsync(`event entity @s Muwwx3`)
            }
            if (res.selection === 3) {
                pl.runCommandAsync(`event entity @s Muwwx4`)
            }
            if (res.selection === 4) {
                pl.runCommandAsync(`event entity @s Muwwx5`)
            }
        })
}
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function size(pl) {
        const f = new ui.ActionFormData();
        f.title(`§l§cขนาดตัว`)
        f.body(`§l§f       •❅──────✧❅✦❅✧──────❅•\n§l§a    §e✦ §fเลือกขนาดตัวที่ต้องการได้เลยคับ §e✦\n `)
        f.button(`§lตัวเล็ก`, `textures/sea/size`)
        f.button(`§lตัวใหญ่`, `textures/sea/size`)
        f.button(`§lตัวปกติ`, `textures/sea/size`)

        f.show(pl).then(res => {
            if (res.selection === 0) {
                s2(pl)
            }
            if (res.selection === 1) {
                s1(pl)
            }
            if (res.selection === 2) {
                pl.runCommandAsync(`event entity @s Muww1`)
            }
        })
}
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function camera(pl) {
        const f = new ui.ActionFormData();
        f.title(`§l§cกล้อง`)
        f.body(`§l§f       •❅──────✧❅✦❅✧──────❅•\n§l§a    §e✦ §fเลือกมุมกล้องที่ต้องการได้เลยคับ §e✦\n `)
        f.button(`§lมุมกล้องปกติ`,`textures/sea/camera`)
        f.button(`§lมุมกล้องบุคคลที่1`,`textures/sea/camera`)
        f.button(`§lมุมกล้องบุคคลที่3`,`textures/sea/camera`)
        f.button(`§lมุมกล้องบุคคลที่3ด้านหน้า`,`textures/sea/camera`)
        f.button(`§lเปิด/ปิด มุมกล้องตาม`,`textures/sea/camera`)
        f.button(`§lตั้งกล้อง`,`textures/sea/camera`)
        f.show(pl).then(res => {
            if (res.selection === 0) {
                pl.runCommandAsync(`Scoreboard players add @s[scores={seacam=1}] seacam 1`)
                pl.runCommandAsync(`camera @s clear`)
            }
            if (res.selection === 1) {
                pl.runCommandAsync(`Scoreboard players add @s[scores={seacam=1}] seacam 1`)
                pl.runCommandAsync(`camera @s set minecraft:first_person`)
            }
            if (res.selection === 2) {
                pl.runCommandAsync(`Scoreboard players add @s[scores={seacam=1}] seacam 1`)
                pl.runCommandAsync(`camera @s set minecraft:third_person`)
            }
            if (res.selection === 3) {
                pl.runCommandAsync(`Scoreboard players add @s[scores={seacam=1}] seacam 1`)
                pl.runCommandAsync(`camera @s set minecraft:third_person_front`)
            }
            if (res.selection === 4) {
                pl.runCommandAsync(`function camera`)
            }
            if (res.selection === 5) {
                pl.runCommandAsync(`camera @s set minecraft:free pos ^^1.8^-0.2 rot ~~`)
            }
        })
}
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function dontknow(pl) {
        const f = new ui.ActionFormData();
        f.title(`§l§cท่าแปลกๆ`)
        f.body(`§l§f       •❅──────✧❅✦❅✧──────❅•\n§l§a    §e✦ §fเลือกท่าทึ่ต้องการได้เลยคับ §e✦\n `)
        f.button(`§lยืดด`, `textures/sea/big`)
        f.button(`§lตัวไรหว่า`, `textures/sea/mini`)
        f.button(`§lตัวเล็ก3ครับ`, `textures/sea/jibi`)
        f.button(`§l5x30`, `textures/sea/b2`)
        f.button(`§l5x30`, `textures/sea/b3`)
        f.button(`§l5x30`, `textures/sea/b4`)
        f.show(pl).then(res => {
            if (res.selection === 0) {
                pl.runCommandAsync(`playanimation @s animation.big a 999999`)
                pl.runCommandAsync(`tag @s remove dance`)
            }
            if (res.selection === 1) {
                pl.runCommandAsync(`playanimation @s animation.mini a 999999`)
                pl.runCommandAsync(`tag @s remove dance`)
            }
            if (res.selection === 2) {
                pl.runCommandAsync(`playanimation @s animation.jibi a 999999`)
                pl.runCommandAsync(`tag @s remove dance`)
            }
            if (res.selection === 3) {
                pl.runCommandAsync(`playanimation @s animation.b2 a 999999`)
                pl.runCommandAsync(`tag @s remove dance`)
            }
            if (res.selection === 4) {
                pl.runCommandAsync(`playanimation @s animation.b3 a 999999`)
                pl.runCommandAsync(`tag @s remove dance`)
            }
            if (res.selection === 5) {
                pl.runCommandAsync(`playanimation @s animation.b4 a 999999`)
                pl.runCommandAsync(`tag @s remove dance`)
            }
        })
}
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function stand(pl) {
        const f = new ui.ActionFormData();
        f.title(`§l§cท่ายืน`)
        f.body(`§l§f       •❅──────✧❅✦❅✧──────❅•\n§l§a    §e✦ §fเลือกท่าทึ่ต้องการได้เลยคับ §e✦\n `)
        f.button(`§lนิ่งไว้!!`, `textures/sea/stop`)
        f.button(`§lสูบบุหรี่`, `textures/sea/buri`)
        f.button(`§lยืนแอค`, `textures/sea/stand`)
        f.button(`§lนกกระเรียน`, `textures/sea/ka`)
        f.button(`§lยืนพิงรอ`, `textures/sea/a2`)
        f.button(`§lยืนพิงด้านหน้า`, `textures/sea/a7`)
        f.button(`§lยืนกอดอก`, `textures/sea/a8`)
        f.button(`§lท่าโพส1`, `textures/sea/a13`)
        f.button(`§lท่าโพส2`, `textures/sea/a14`)

        f.show(pl).then(res => {
            if (res.selection === 0) {
                pl.runCommandAsync(`playanimation @s animation.stop a 999999`)
                pl.runCommandAsync(`tag @s remove dance`)
            }
            if (res.selection === 1) {
                pl.runCommandAsync(`playanimation @s animation.buri a 999999`)
                pl.runCommandAsync(`tag @s remove dance`)
            }
            if (res.selection === 2) {
                pl.runCommandAsync(`playanimation @s animation.stand a 999999`)
                pl.runCommandAsync(`tag @s remove dance`)
            }
            if (res.selection === 3) {
                pl.runCommandAsync(`playanimation @s animation.ka a 999999`)
                pl.runCommandAsync(`tag @s remove dance`)
            }
            if (res.selection === 4) {
                pl.runCommandAsync(`playanimation @s animation.a2 a 999999`)
                pl.runCommandAsync(`tag @s remove dance`)
            }
            if (res.selection === 5) {
                pl.runCommandAsync(`playanimation @s animation.a7 a 999999`)
                pl.runCommandAsync(`tag @s remove dance`)
            }
            if (res.selection === 6) {
                pl.runCommandAsync(`playanimation @s animation.a8 a 999999`)
                pl.runCommandAsync(`tag @s remove dance`)
            }
            if (res.selection === 7) {
                pl.runCommandAsync(`playanimation @s animation.a13 a 999999`)
                pl.runCommandAsync(`tag @s remove dance`)
            }
            if (res.selection === 8) {
                pl.runCommandAsync(`playanimation @s animation.a14 a 999999`)
                pl.runCommandAsync(`tag @s remove dance`)
            }
        })
}
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function action(pl) {
        const f = new ui.ActionFormData();
        f.title(`§l§cท่าทาง`)
        f.body(`§l§f       •❅──────✧❅✦❅✧──────❅•\n§l§a    §e✦ §fเลือกท่าทึ่ต้องการได้เลยคับ §e✦\n `)
        f.button(`§lมอบให้`, `textures/sea/down`)
        f.button(`§lตบหน้าอีกะเทย!`, `textures/sea/tap`)
        f.button(`§lก้มหัว`, `textures/sea/a4`)
        f.button(`§lยืนไม่ไหว`, `textures/sea/a9`)
        f.button(`§lตายย×~×`, `textures/sea/a10`)
        f.button(`§lกูไม่อยู่ละ`, `textures/sea/a12`)
        f.button(`§lลอยยย~`, `textures/sea/a15`)
        f.button(`§lลูบหัวๆ`, `textures/sea/b11`)
        
        f.show(pl).then(res => {
            if (res.selection === 0) {
                pl.runCommandAsync(`playanimation @s animation.down a 999999`)
                pl.runCommandAsync(`tag @s remove dance`)
            }
            if (res.selection === 1) {
                pl.runCommandAsync(`playanimation @s animation.tap a 999999`)
                pl.runCommandAsync(`tag @s remove dance`)
            }
            if (res.selection === 2) {
                pl.runCommandAsync(`playanimation @s animation.a4 a 999999`)
                pl.runCommandAsync(`tag @s remove dance`)
            }
            if (res.selection === 3) {
                pl.runCommandAsync(`playanimation @s animation.a9 a 999999`)
                pl.runCommandAsync(`tag @s remove dance`)
            }
            if (res.selection === 4) {
                pl.runCommandAsync(`playanimation @s animation.a10 a 999999`)
                pl.runCommandAsync(`tag @s remove dance`)
            }
            if (res.selection === 5) {
                pl.runCommandAsync(`playanimation @s animation.a12 a 999999`)
                pl.runCommandAsync(`tag @s remove dance`)
            }
            if (res.selection === 6) {
                pl.runCommandAsync(`playanimation @s animation.a15 a 999999`)
                pl.runCommandAsync(`tag @s remove dance`)
            }
            if (res.selection === 7) {
                pl.runCommandAsync(`playanimation @s animation.b11 a 999999`)
                pl.runCommandAsync(`tag @s remove dance`)
            }
        })
}
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function sit(pl) {
        const f = new ui.ActionFormData();
        f.title(`§l§cท่านั่ง`)
        f.body(`§l§f       •❅──────✧❅✦❅✧──────❅•\n§l§a    §e✦ §fเลือกท่าที่ต้องการได้เลยคับ §e✦\n `)
        f.button(`§lนั่งเล่น`, `textures/sea/sit`)
        f.button(`§lนั่งงอน`, `textures/sea/sit2`)
        f.button(`§lนั่งแกว่ง`, `textures/sea/sit3`)
        f.button(`§lนั่งพับเพียบ`, `textures/sea/pap`)
        f.button(`§lนั่งดูเวลา`, `textures/sea/a1`)
        f.button(`§lนั่งแอ็ค`, `textures/sea/a3`)
        f.button(`§lนั่งพาดขา`, `textures/sea/a5`)
        f.button(`§lนั่งชิล`, `textures/sea/a6`)
        f.show(pl).then(res => {
            if (res.selection === 0) {
                pl.runCommandAsync(`playanimation @s animation.sit a 999999`)
                pl.runCommandAsync(`tag @s remove dance`)
            }
            if (res.selection === 1) {
                pl.runCommandAsync(`playanimation @s animation.sit2 a 999999`)
                pl.runCommandAsync(`tag @s remove dance`)
            }
            if (res.selection === 2) {
                pl.runCommandAsync(`playanimation @s animation.sit3 a 999999`)
                pl.runCommandAsync(`tag @s remove dance`)
            }
            if (res.selection === 3) {
                pl.runCommandAsync(`playanimation @s animation.pap a 999999`)
                pl.runCommandAsync(`tag @s remove dance`)
            }
            if (res.selection === 4) {
                pl.runCommandAsync(`playanimation @s animation.a1 a 999999`)
                pl.runCommandAsync(`tag @s remove dance`)
            }
            if (res.selection === 5) {
                pl.runCommandAsync(`playanimation @s animation.a3 a 999999`)
                pl.runCommandAsync(`tag @s remove dance`)
            }
            if (res.selection === 6) {
                pl.runCommandAsync(`playanimation @s animation.a5 a 999999`)
                pl.runCommandAsync(`tag @s remove dance`)
            }
            if (res.selection === 7) {
                pl.runCommandAsync(`playanimation @s animation.a6 a 999999`)
                pl.runCommandAsync(`tag @s remove dance`)
            }
        })
}
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function dance(pl) {
        const f = new ui.ActionFormData();
        f.title(`§l§cท่าเต้น`)
        f.body(`§l§f       •❅──────✧❅✦❅✧──────❅•\n§l§a    §e✦ §fเลือกท่าทึ่ต้องการได้เลยคับ §e✦\n `)
        f.button(`§lรูดเสาา`, `textures/sea/dance`)
        f.button(`§lหมูเด้ง`, `textures/sea/mu`)
        f.button(`§lโยกย้าย`, `textures/sea/a11`)
        f.button(`§lหนูเต้น`, `textures/sea/b1`)
        f.button(`§lร็อค!`, `textures/sea/b5`)
        f.button(`§lซ้อนท้ายพี่ป่าว`, `textures/sea/b6`)
        f.button(`§lโยกน่ารักๆ`, `textures/sea/b7`)
        f.button(`§lโยกตูดด`, `textures/sea/b8`)
        f.button(`§lขัดขี้ไคล`, `textures/sea/b9`)
        f.button(`§lวิ่งๆๆๆ`, `textures/sea/b10`)
        f.show(pl).then(res => {
            if (res.selection === 0) {
                pl.runCommandAsync(`scoreboard players set @s dance 1`)
                pl.runCommandAsync(`tag @s add dance`)
            }
            if (res.selection === 1) {
                pl.runCommandAsync(`playanimation @s animation.mu a 999999`)
                pl.runCommandAsync(`tag @s remove dance`)
            }
            if (res.selection === 2) {
                pl.runCommandAsync(`playanimation @s animation.a11 a 999999`)
                pl.runCommandAsync(`tag @s remove dance`)
            }
            if (res.selection === 3) {
                pl.runCommandAsync(`playanimation @s animation.b1 a 999999`)
                pl.runCommandAsync(`tag @s remove dance`)
            }
            if (res.selection === 4) {
                pl.runCommandAsync(`playanimation @s animation.b5 a 999999`)
                pl.runCommandAsync(`tag @s remove dance`)
            }
            if (res.selection === 5) {
                pl.runCommandAsync(`playanimation @s animation.b6 a 999999`)
                pl.runCommandAsync(`tag @s remove dance`)
            }
            if (res.selection === 6) {
                pl.runCommandAsync(`playanimation @s animation.b7 a 999999`)
                pl.runCommandAsync(`tag @s remove dance`)
            }
            if (res.selection === 7) {
                pl.runCommandAsync(`playanimation @s animation.b8 a 999999`)
                pl.runCommandAsync(`tag @s remove dance`)
            }
            if (res.selection === 8) {
                pl.runCommandAsync(`playanimation @s animation.b9 a 999999`)
                pl.runCommandAsync(`tag @s remove dance`)
            }
            if (res.selection === 9) {
                pl.runCommandAsync(`playanimation @s animation.b10 a 999999`)
                pl.runCommandAsync(`tag @s remove dance`)
            }
        })
}
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function two(pl) {
        const f = new ui.ActionFormData();
        f.title(`§l§cท่าคู่`)
        f.body(`§l§f       •❅──────✧❅✦❅✧──────❅•\n§l§a    §e✦ §fเลือกท่าทึ่ต้องการได้เลยคับ §e✦\n `)
        f.button(`§lด้านขวา`, `textures/sea/b13`)
        f.button(`§lด้านซ้าย`, `textures/sea/b13`)
        f.show(pl).then(res => {
            if (res.selection === 0) {
                pl.runCommandAsync(`playanimation @s animation.b12 a 999999`)
                pl.runCommandAsync(`tag @s remove dance`)
            }
            if (res.selection === 1) {
                pl.runCommandAsync(`playanimation @s animation.b13 a 999999`)
                pl.runCommandAsync(`tag @s remove dance`)
            }
        })
}
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function seamuww(pl) {
        const f = new ui.ActionFormData();
        f.title(`§l§f•§c Sea muww Emote §f•`)
        f.body(`§l§f       •❅──────✧❅✦❅✧──────❅•\n§l§a    §e✦ §fเลือก Emote ที่ต้องการได้เลยคับ §e✦\n `)
        f.button(`§l§cInfo`, `textures/sea/info`)
        f.button(`§l§eกล้อง`, `textures/sea/camera`)
        f.button(`§lท่าทาง`, `textures/sea/down`)
        f.button(`§lท่านั่ง`, `textures/sea/sit2`)
        f.button(`§lท่ายืน`, `textures/sea/stop`)
        f.button(`§lท่าเต้น`, `textures/sea/mu`)
        f.button(`§lท่าแปลกๆ`, `textures/sea/big`)
        f.button(`§lท่าคู่`, `textures/sea/b13`)
        f.button(`§l§cเคสโทรศัพท์`, `textures/sea/phone1`)
        f.button(`§l§cขนาดตัว`, `textures/sea/size`)
        f.show(pl).then(res => {
            if (res.selection === 0) {
                info(pl)
            }
            if (res.selection === 1) {
                camera(pl)
            }
            if (res.selection === 2) {
                action(pl)
            }
            if (res.selection === 3) {
                sit(pl)
            }
            if (res.selection === 4) {
                stand(pl)
            }
            if (res.selection === 5) {
                dance(pl)
            }
            if (res.selection === 6) {
                dontknow(pl)
            }
            if (res.selection === 7) {
                two(pl)
            }
            if (res.selection === 8) {
                phone(pl)
            }
            if (res.selection === 9) {
                size(pl)
            }
        })
}
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
mc.system.runInterval(() => {
    mc.world.getAllPlayers().forEach(plr => {
        
    if (plr.isFlying) plr.runCommandAsync(`playanimation @s animation.clear a 1`)
    if (plr.isInWater) plr.runCommandAsync(`playanimation @s animation.clear a 1`)
    if (plr.isSneaking) plr.runCommandAsync(`playanimation @s animation.clear a 1`)
    if (plr.isSprinting) plr.runCommandAsync(`playanimation @s animation.clear a 1`)

    if (plr.isFlying) plr.runCommandAsync(`tag @s remove dance`)
    if (plr.isInWater) plr.runCommandAsync(`tag @s remove dance`)
    if (plr.isSneaking) plr.runCommandAsync(`tag @s remove dance`)
    if (plr.isSprinting) plr.runCommandAsync(`tag @s remove dance`)
    
    })
})

