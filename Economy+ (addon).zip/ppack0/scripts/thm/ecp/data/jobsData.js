import { JobTriggersEnum } from "../enums/JobTriggersEnum";
import { JobData, JobItemsData } from "../objects/JobData";

export const JOBS_DATA = [
    new JobData(
        "woodcutter",
        "thm_ecp.jobs.woodcutter",
        "thm_ecp.jobs.woodcutter.description",
        [
            new JobItemsData("minecraft:acacia_log", JobTriggersEnum.BREAK, 1, 1),
            new JobItemsData("minecraft:birch_log", JobTriggersEnum.BREAK, 1, 1),
            new JobItemsData("minecraft:cherry_log", JobTriggersEnum.BREAK, 1, 1),
            new JobItemsData("minecraft:dark_oak_log", JobTriggersEnum.BREAK, 1, 1),
            new JobItemsData("minecraft:jungle_log", JobTriggersEnum.BREAK, 1, 1),
            new JobItemsData("minecraft:mangrove_log", JobTriggersEnum.BREAK, 1, 1),
            new JobItemsData("minecraft:oak_log", JobTriggersEnum.BREAK, 1, 1),
            new JobItemsData("minecraft:spruce_log", JobTriggersEnum.BREAK, 1, 1),
            new JobItemsData("minecraft:crimson_stem", JobTriggersEnum.BREAK, 1, 1),
            new JobItemsData("minecraft:warped_stem", JobTriggersEnum.BREAK, 1, 1)
        ]
    )
]

export const JOB_BREAKS = [];
export const JOB_BUILDS = [];
export const JOB_USE = [];
export const JOB_USE_ON = [];

function initJobData(){
    for (const data of JOBS_DATA) {
        for (const item of data.items) {
            switch (item.trigger) {
                case JobTriggersEnum.BREAK:
                    JOB_BREAKS.push({jobID: data.jobID, item: item.typeId})
                    break;

                case JobTriggersEnum.BUILD:
                    JOB_BUILDS.push({jobID: data.jobID, item: item.typeId})
                    break;

                case JobTriggersEnum.USE:
                    JOB_USE.push({jobID: data.jobID, item: item.typeId})
                break;

                case JobTriggersEnum.USE_ON:
                    JOB_USE_ON.push({jobID: data.jobID, item: item.typeId})
                    break;
            }
        }
    }
}