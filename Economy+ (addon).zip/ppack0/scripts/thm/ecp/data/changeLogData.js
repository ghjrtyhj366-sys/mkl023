export const changeLogData = [
    {
        date: "30th July 2024",
        version: "V1.0.0",
        changeLog: `Initial Submission`
    },
    {
        date: "20th September 2024",
        version: "V1.1.0",
        changeLog: `Update prior to release:
        Added changeable settings to the guide form
        Added item component details to market item info
        Added Wandering Buyer`
    },
    {
        date: "29th September 2024",
        version: "V1.2.0",
        changeLog: `Update prior to release:
        Pre-release bug fixes
        Added balance to transfer and withdraw forms`
    }
]