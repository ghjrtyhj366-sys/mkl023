export const CASH_ITEMS = [
    {typeId:"thm_ecp:cash_single", value:1},
    {typeId:"thm_ecp:cash_double", value:5},
    {typeId:"thm_ecp:cash_halfclip", value:10},
    {typeId:"thm_ecp:cash_clip", value:50},
    {typeId:"thm_ecp:cash_stack", value:100},
    {typeId:"thm_ecp:cash_twinstack", value:500},
    {typeId:"thm_ecp:cash_doublestack", value:1000},
    {typeId:"thm_ecp:cash_pile", value:5000},
    {typeId:"thm_ecp:cash_case", value:10000},
    {typeId:"thm_ecp:cash_doublecase", value:50000},
    {typeId:"thm_ecp:cash_crate", value:100000},
    {typeId:"thm_ecp:cash_chest", value:500000},
    {typeId:"thm_ecp:cash_pallet", value:1000000}
]

