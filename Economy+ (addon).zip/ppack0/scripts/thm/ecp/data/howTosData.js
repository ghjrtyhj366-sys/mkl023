export const HOW_TOS_DATA = [
    {
        button: "thm_ecp.howtos.button.bank",
        formBody:{rawtext: [
            { translate: `thm_ecp.form.howtos.bank.info.1`},
            { text: '\n\n' },
            { translate: `thm_ecp.form.howtos.bank.info.2`},
            { text: '\n\n' },
            { translate: `thm_ecp.form.howtos.bank.sendMoney`},
            { text: '\n' },
            { translate: `thm_ecp.form.howtos.bank.info.sendMoney`},
            { text: '\n\n' },
            { translate: `thm_ecp.form.howtos.bank.manageFriends`},
            { text: '\n' },
            { translate: `thm_ecp.form.howtos.bank.info.manageFriends`},
            { text: '\n\n' },
            { translate: `thm_ecp.form.howtos.bank.withdaw`},
            { text: '\n' },
            { translate: `thm_ecp.form.howtos.bank.info.withdaw`},
            { text: '\n\n' },
            { translate: `thm_ecp.form.howtos.bank.deposit`},
            { text: '\n' },
            { translate: `thm_ecp.form.howtos.bank.info.deposit`}
        ]}
    },
    {
        button: "thm_ecp.howtos.button.market",
        formBody:{rawtext: [
            { translate: `thm_ecp.form.howtos.market.info.1`},
            { text: '\n\n' },
            { translate: `thm_ecp.form.howtos.market.info.2`},
            { text: '\n\n' },
            { translate: `thm_ecp.form.howtos.market.info.3`},
            { text: '\n\n' },
            { translate: `thm_ecp.form.howtos.market.buyItem`},
            { text: '\n' },
            { translate: `thm_ecp.form.howtos.market.info.buyItem`},
            { text: '\n\n' },
            { translate: `thm_ecp.form.howtos.market.info.manageItem.1`},
            { text: '\n\n' },
            { translate: `thm_ecp.form.howtos.market.info.manageItem.2`},
            { text: '\n\n' },
            { translate: `thm_ecp.form.howtos.market.editItem`},
            { text: '\n\n' },
            { translate: `thm_ecp.form.howtos.market.addItem`},
            { text: '\n\n' },
            { translate: `thm_ecp.form.howtos.market.replaceItem`},
            { text: '\n\n' },
            { translate: `thm_ecp.form.howtos.market.removeItem`},
            { text: '\n\n' },
            { translate: `thm_ecp.form.howtos.market.updateStock`},
            { text: '\n\n' },
            { translate: `thm_ecp.form.howtos.market.updatePrice`},
            { text: '\n\n' },
            { translate: `thm_ecp.form.howtos.market.withdrawSales`},
            { text: '\n\n' },
            { translate: `thm_ecp.form.howtos.market.crateTexture`},
            
        ]}
    },
    {
        button: "thm_ecp.howtos.button.auction",
        formBody:{rawtext: [
            { translate: `thm_ecp.form.howtos.auction.info.1`},
            { text: '\n\n' },
            { translate: `thm_ecp.form.howtos.auction.info.2`},
            { text: '\n\n' },
            { translate: `thm_ecp.form.howtos.auction.info.3`},
            { text: '\n\n' },
            { translate: `thm_ecp.form.howtos.auction.listings`},
            { text: '\n\n' },
            { translate: `thm_ecp.form.howtos.auction.collections`},
            { text: '\n\n' },
            { translate: `thm_ecp.form.howtos.auction.list`},
            { text: '\n\n' },
            { translate: `thm_ecp.form.howtos.auction.remove`},
        ]}
    },
    {
        button: "thm_ecp.howtos.button.technical",
        formBody:{rawtext: [
            { text: `To gain money in vanilla survival, there are Wandering Buyers that spawn in villages, this can be turned off in the settings.
                

If you would like to integrate Economy+ into your systems or commands you can use the following:

To add or remove money from players - add/remove from the a score for a player to the scoreboard thm_ecp:money_update

Once you have done this, you need to run /scriptevent thm_ecp:update, this will then transfer the positive or negative score to the player.

If you would like to test for a players money such as target selectors, you can use the scoreboard thm_ecp:money_display. This scoreboard can also be displayed in any display area, it will update when players change their balance, and if they leave or join.

` }
        ]}
    },
]