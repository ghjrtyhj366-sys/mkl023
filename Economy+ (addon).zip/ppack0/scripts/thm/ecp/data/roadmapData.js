export const roadmapData = `These are features we are either working on, or on our list to add in the future.

If you want to discuss our updates, or offer suggestions, please join us on discord: https://discord.gg/cyB95CqCWF

§bJobs§r
We are currently working on a jobs system that you'll be able to browse from the phone, this will give you money for completing tasks.

§bPotions§r
Currently potions in markets and auctions is not supported, once the Scripting API releases the potions component, we'll be able to turn off the prevention.

§bSavings§r
A feature we have been planning is savings, the plan is to allow you to transfer money into a savings account, and you'll receive interest every Minecraft day.

§bItems§r
We are planning on adding placable cash as blocks, cash registers, and other items to make the economy more immersive. We are also looking to create a way to change the theme of the economy to be able to have different cash items such as gold/gold pouches.`