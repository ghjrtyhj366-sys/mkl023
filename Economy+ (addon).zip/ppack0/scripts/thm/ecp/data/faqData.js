export const faqData = [
    {
        question: "tomhmagic_realight.faq.question.1",
        answer: "tomhmagic_realight.faq.answer.1"
    },
    {
        question: "tomhmagic_realight.faq.question.2",
        answer: "tomhmagic_realight.faq.answer.2"
    },
    {
        question: "tomhmagic_realight.faq.question.3",
        answer: "tomhmagic_realight.faq.answer.3"
    },
    {
        question: "tomhmagic_realight.faq.question.4",
        answer: "tomhmagic_realight.faq.answer.4"
    },
    {
        question: "tomhmagic_realight.faq.question.5",
        answer: "tomhmagic_realight.faq.answer.5"
    },
    {
        question: "tomhmagic_realight.faq.question.6",
        answer: "tomhmagic_realight.faq.answer.6"
    }
]