export const RECIPIES_DATA = [
        {
            button: "thm_ecp.recipies.button",
            formBody:{rawtext: [
                { translate: `thm_ecp.form.recipies.info.1`},
                { text: '\n\n' },
                { translate: `thm_ecp.recipies.guideBook`},
                { text: '\n\n' },
                { translate: `thm_ecp.recipies.atm_card`},
                { text: '\n\n' },
                { translate: `thm_ecp.recipies.cash`},
                { text: '\n\n' },
                { text: `Market
        §7⬛⬛⬛       §7⬛§r Any Wool
        §b⬛  §b⬛       §b⬛§r Any Wooden Fence
        §e⬛§e⬛§e⬛§r       §e⬛§r Any Planks` },
                    { text: '\n\n' },
                    { text: `Auction
        §7⬛§e⬛§7⬛       §7⬛§r Any Planks
        §7⬛§e⬛§7⬛       §e⬛§r Gold Ingot
          §b⬛   §r      §b⬛§r Stick` },
                    { text: '\n\n' },
    
        
                { text: `Wall ATM
        §7⬛⬛⬛       §7⬛§r Iron Ingot
        §7⬛§b⬛§7⬛       §b⬛§r Glass Block
        §7⬛§e⬛§7⬛§r       §e⬛§r Gold Ingot` },
                { text: '\n\n' },
                { text: `Floor ATM
        §7⬛§e⬛§7⬛       §7⬛§r Iron Ingot
        §7⬛§b⬛§7⬛       §b⬛§r Glass Block
        §7⬛§e⬛§7⬛§r       §e⬛§r Gold Ingot` },
                { text: '\n\n' },
                { text: `Floor ATM Bottom
        §7⬛§e⬛§7⬛       §7⬛§r Iron Ingot
        §7⬛  §7⬛       §e⬛§r Gold Ingot
        §7⬛§e⬛§7⬛§r` },
        { text: '\n\n' },
        { text: `Phone
      §d⬛         §d⬛§r Lighting Rod
    §7⬛§b⬛§7⬛       §b⬛§r Glass Block
    §7⬛§b⬛§7⬛§r       §7⬛§r Iron Ingot` },
            ]}
        }
    ]