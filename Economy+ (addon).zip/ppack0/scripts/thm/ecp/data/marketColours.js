export const MARKET_COLOURS = [
    "black",
    "blue",
    "brown",
    "green",
    "grey",
    "orange",
    "purple",
    "red",
    "white",
    "yellow"
]
