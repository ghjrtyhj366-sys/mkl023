import { ScriptEventSource, system } from "@minecraft/server";
import { CommandUtils } from "../utils/CommandUtils";
import { ScriptEventEnum } from "../enums/ScriptEventEnum";

system.afterEvents.scriptEventReceive.subscribe((event) => {
    const {
        id,           
        initiator,
      message,
      sourceBlock,
      sourceEntity,
      sourceType,
    } = event;
  
  
    let sender = sourceType == ScriptEventSource.Entity ? sourceEntity : null;
  
    switch (id) {
        case ScriptEventEnum.UPDATE:
            CommandUtils.update(sender)
            break;
        }

  });