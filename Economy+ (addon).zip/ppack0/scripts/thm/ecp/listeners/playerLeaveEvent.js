import { world } from "@minecraft/server";
import { ScoreboardUtils } from "../utils/ScoreboardUtils";

world.afterEvents.playerLeave.subscribe(event => {
    ScoreboardUtils.initMoneyDisplay();
})