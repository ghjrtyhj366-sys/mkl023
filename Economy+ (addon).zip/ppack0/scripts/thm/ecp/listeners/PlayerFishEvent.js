import { world, system } from "@minecraft/server";

world.afterEvents.itemUse.subscribe(async (event) => {
    const itemStack = event.itemStack;
    const player = event.source;

    if (itemStack.typeId === "minecraft:fishing_rod") {
        const caughtItem = await handleFishingEvent(player);
        if (caughtItem) {
            player.sendMessage(`You caught a ${caughtItem.id}!`);
        } else {
            player.sendMessage("You didn't catch anything.");
        }
    }
});

async function handleFishingEvent(player) {
    const initialInventory = getInventorySnapshot(player);

    const caughtItem = await waitForSecondUse(player, initialInventory);

    return caughtItem;
}

function getInventorySnapshot(player) {
    const inventory = player.getComponent("minecraft:inventory").container;
    let snapshot = [];
    for (let i = 0; i < inventory.size; i++) {
        const item = inventory.getItem(i);
        snapshot.push(item ? { id: item.typeId, count: item.amount } : null);
    }
    return snapshot;
}

async function waitForSecondUse(player, initialInventory) {
    return new Promise((resolve) => {
        let secondUseHandled = false;

        const unsubscribe = world.afterEvents.itemUse.subscribe(event => {
            const itemStack = event.itemStack;
            const eventPlayer = event.source;

            if (eventPlayer === player && itemStack.typeId === "minecraft:fishing_rod") {
                secondUseHandled = true;
                unsubscribe(); // Unsubscribe from further itemUse events
                checkInventoryChange(player, initialInventory).then(caughtItem => {
                    resolve(caughtItem);
                });
            }
        });

        system.runTimeout(() => {
            if (!secondUseHandled) {
                unsubscribe(); // Clean up if no second use occurs
                resolve(null);
            }
        }, 10000); // Wait for up to 10 seconds for the second use
    });
}

async function checkInventoryChange(player, initialInventory) {
    return new Promise((resolve) => {
        system.runTimeout(() => {
            const newInventory = getInventorySnapshot(player);
            const caughtItem = detectNewItem(initialInventory, newInventory);
            resolve(caughtItem);
        }, 5000); // Check the inventory change after 5 seconds
    });
}

function detectNewItem(oldInventory, newInventory) {
    for (let i = 0; i < newInventory.length; i++) {
        const oldItem = oldInventory[i];
        const newItem = newInventory[i];

        if (newItem && (!oldItem || newItem.count > oldItem.count)) {
            return newItem;
        }
    }
    return null;
}
