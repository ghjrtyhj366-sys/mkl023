import { world } from "@minecraft/server";
import { Settings } from "../managers/Settings";
import { EntityEnum } from "../enums/EntityEnum";
import { MarketManager } from "../managers/MarketManager";

world.afterEvents.entitySpawn.subscribe(event => {
    const entity = event.entity;
    if(entity.typeId === "minecraft:villager_v2") handleWanderingBuyer(entity)

    const spawnBuyer = Settings.getSpawnBuyer();
    if(!spawnBuyer && entity.isValid() && entity.typeId === "thm_ecp:wandering_buyer") entity.remove();
});


function handleWanderingBuyer(entity){
    const spawnBuyer = Settings.getSpawnBuyer();
    if(!spawnBuyer) return;
    const otherBuyers = entity.dimension.getEntities({type:"thm_ecp:wandering_buyer", location:entity.location, maxDistance:128});
    if(otherBuyers.length !== 0) return;

    entity.dimension.spawnEntity("thm_ecp:wandering_buyer", entity.location);
}

world.afterEvents.entityLoad.subscribe(event => {
    const entity = event.entity;
    checkMoneySettingsUpdate(entity);
});

function checkMoneySettingsUpdate(entity){
    if(entity.typeId !== EntityEnum.MARKET) return;

    MarketManager.updateNameTag(entity);
}