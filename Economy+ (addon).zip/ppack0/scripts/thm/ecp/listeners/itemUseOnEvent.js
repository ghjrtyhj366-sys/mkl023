import { world } from "@minecraft/server";

import { MarketUtils } from "../utils/MarketUtils";
import { AuctionUtils } from "../utils/AuctionUtils";

world.afterEvents.itemUseOn.subscribe(event => {
    const itemStack = event.itemStack;
    const player = event.source;
    const block = event.block;
    const blockFace = event.blockFace

    if(itemStack.typeId === "thm_ecp:item_market") MarketUtils.spawnMarket(player, block, blockFace, itemStack);

    if(itemStack.typeId === "thm_ecp:item_auction") AuctionUtils.placeAuction(player, block, blockFace, itemStack);
    
    
});