import { world } from "@minecraft/server";
import { MoneyUtils } from "../utils/MoneyUtils";
import { MessageUtils } from "../utils/MessageUtils";
import { ScoreboardUtils } from "../utils/ScoreboardUtils";
import { PlayerUtils } from "../utils/PlayerUtils";
import { Settings } from "../managers/Settings";
import { DynamicPropertyEnum } from "../enums/DynamicPropertyEnum";

world.afterEvents.playerSpawn.subscribe(event => {
    const player = event.player;
        
    //on first join
    if (event.initialSpawn){
        initPlayer(player);
        handleOfflineMoney(player);
        ScoreboardUtils.updateMoneyDisplay(player);
        giveGuideBook(player);
        sendVersionUpdate(player);
    }
});


function initPlayer(player){
    if(PlayerUtils.getUUID(player) === undefined) PlayerUtils.setUUID(player, player.id);
    
}

function handleOfflineMoney(player){
    const UUID = PlayerUtils.getUUID(player);
    const offlineMoney = MoneyUtils.getOfflineMoney(UUID);
    if(offlineMoney == 0) return;
        
    MoneyUtils.addMoney(player, offlineMoney);
    MoneyUtils.resetOfflineMoney(UUID);
    const balance = MoneyUtils.getMoney(player);
    MessageUtils.sendOfflineMoneyMsg(player, offlineMoney, balance);
}

function sendVersionUpdate(player){
    const currentVersion = Settings.getCurrentVersion()
    const playerLastVersion = player.getDynamicProperty(DynamicPropertyEnum.VERSION);

    if(playerLastVersion !== currentVersion && currentVersion != "1.2.0"){

        MessageUtils.sendPlainMsg(player, { translate: "thm_ecp.newUpdate" });
        player.setDynamicProperty(DynamicPropertyEnum.VERSION, currentVersion);
    }

}

function giveGuideBook(player){
    if (player.getDynamicProperty(DynamicPropertyEnum.GIVENBOOK)) return;
    
    player.runCommand(`give @s thm_ecp:info_book`);
    player.runCommand("recipe give @s thm_ecp:info_book");
    player.setDynamicProperty(DynamicPropertyEnum.GIVENBOOK, true);
}