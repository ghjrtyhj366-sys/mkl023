import { Player, world } from "@minecraft/server";

import { showMainMarketForm } from "../forms/market/mainMarket";
import { showMainAuctionForm } from "../forms/auction/mainAuction";

world.afterEvents.entityHitEntity.subscribe(event => {
    const target = event.hitEntity;
    const entity = event.damagingEntity;
 
    if(entity instanceof Player && target.typeId === "thm_ecp:market") showMainMarketForm(entity, target);

    if(entity instanceof Player && target.typeId === "thm_ecp:auction") showMainAuctionForm(entity, target);
});