import { world } from "@minecraft/server";

import { Settings } from "../managers/Settings";
import { ScoreboardUtils } from "../utils/ScoreboardUtils";

world.afterEvents.worldInitialize.subscribe(event => {
    scoreboardsInit();
    Settings.init();
});


function scoreboardsInit(){
    ScoreboardUtils.initOfflineCache();
    ScoreboardUtils.initMoneyDisplay();
}