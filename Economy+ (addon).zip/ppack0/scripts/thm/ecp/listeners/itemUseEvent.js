import { world } from "@minecraft/server";
import { SoundEnum } from "../enums/SoundEnum";

import { showBankForm } from "../forms/mainBank";
import { TagEnum } from "../enums/TagEnum";
import { showMainGuideForm } from "../forms/guide/mainGuideForm";

world.afterEvents.itemUse.subscribe(event => {
    const itemStack = event.itemStack;
    const player = event.source;

    if(itemStack.hasTag(TagEnum.ATM_CARD)) ATMInteraction(player, itemStack);
    
    if(itemStack.hasTag(TagEnum.PHONE)) showBankForm(player, false);

    if(itemStack.typeId === "thm_ecp:info_book") showMainGuideForm(player);
});

function ATMInteraction(player){
    const raycast = player.getBlockFromViewDirection({includeLiquidBlocks: true, includePassableBlocks:true, maxDistance:3});

    if(raycast == undefined) return;
    if(!raycast.block.hasTag(TagEnum.ATM)) return;
    player.playSound(SoundEnum.ATM);
    showBankForm(player, true);
}