//Enum for entities
export class EntityEnum {
    static MARKET = 'thm_ecp:market';
    static STORAGE = `thm_ecp:storage`;
    static DUMMY = `thm_ecp:dummy`;
    static AUCTION = `thm_ecp:auction`;
    static STORAGE = `thm_ecp:storage`;
}

// Freeze the entire class
Object.freeze(EntityEnum);