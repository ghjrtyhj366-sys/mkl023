
const teamName = "thm"; 
const addonName = "ecp"; 
const namespace = `${teamName}_${addonName}`

export class ActorPropertiesEnum {
    static ROT = `${namespace}:rot`;
    static ITEM_0 = `${namespace}:item0`;
    static ITEM_1 = `${namespace}:item1`;
    static ITEM_2 = `${namespace}:item2`;
    static COLOUR_1 = `${namespace}:colour1`;
    static COLOUR_2 = `${namespace}:colour2`;

    static getItemFromSlot(slot){
        switch (slot) {
            case 0:
                return this.ITEM_0
            case 1:
                return this.ITEM_1
            case 2:
                return this.ITEM_2
        }
    }

    
}

// Freeze the entire class
Object.freeze(ActorPropertiesEnum);
