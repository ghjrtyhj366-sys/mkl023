
const teamName = "thm"; 
const addonName = "ecp"; 
const namespace = `${teamName}_${addonName}:`

export class ScriptEventEnum {
    static UPDATE = namespace + "update";
}

// Freeze the entire class
Object.freeze(ScriptEventEnum);