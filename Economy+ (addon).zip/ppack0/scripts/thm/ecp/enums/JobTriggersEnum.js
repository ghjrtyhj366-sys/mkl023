//Enum for Job Triggers
export class JobTriggersEnum {
    static BUILD = 'build';
    static BREAK = `break`;
    static USE = `use`;
    static USE_ON = `use_on`;
}

// Freeze the entire class
Object.freeze(JobTriggersEnum);