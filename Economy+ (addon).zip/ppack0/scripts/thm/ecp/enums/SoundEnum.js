//Enum for sound strings
export class SoundEnum {
    static NOTIFICATION = 'thm.ecp.notification';
    static ATM = 'thm.ecp.atm';
    static POP = 'thm.ecp.pop';
    static MARKET_PLACE = `mob.horse.leather`;
    static AUCTION_PLACE = `mob.horse.leather`;
}

// Freeze the entire class
Object.freeze(SoundEnum);