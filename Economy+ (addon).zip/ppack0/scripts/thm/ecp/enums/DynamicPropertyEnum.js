
const teamName = "thm"; 
const addonName = "ecp"; 
const namespace = `${teamName}_${addonName}:`

export class DynamicPropertyEnum {
    static GIVENBOOK = namespace + "givenBook";
    static VERSION = namespace + "version";
    static UUID = namespace + "uuid";
    static CURRENCY_SYMBOL = namespace + "CurrencySymbol";
    static CURRENCY_PLACEMENT = namespace + "CurrencyPlacement";
    static MONEY = namespace + "money";
    static MARKET_OWNER_ID = namespace + "market_owner_id";
    static MARKET_OWNER_NAME = namespace + "market_owner_name";
    static MARKET_NAME = namespace + "market_name";
    static MARKET_ITEM_PRICE_1 = namespace + "market_item1_price";
    static MARKET_ITEM_PRICE_2 = namespace + "market_item2_price";
    static MARKET_ITEM_PRICE_3 = namespace + "market_item3_price";
    static MARKET_ITEM_STOCK_1 = namespace + "market_item1_stock";
    static MARKET_ITEM_STOCK_2 = namespace + "market_item2_stock";
    static MARKET_ITEM_STOCK_3 = namespace + "market_item3_stock";
    static MARKET_ITEM_SALES_1 = namespace + "market_item1_sales";
    static MARKET_ITEM_SALES_2 = namespace + "market_item2_sales";
    static MARKET_ITEM_SALES_3 = namespace + "market_item3_sales";

    static AUCTION_OWNER_ID = namespace + "auction_owner_id";
    static AUCTION_OWNER_NAME = namespace + "auction_owner_name";
    static AUCTION_NAME = namespace + "auction_name";
    static AUCTION_STORAGE = namespace + "auctionStorage_";
    static AUCTION_LISTING = namespace + "auctionListing_";
    static AUCTION_COLLECTION = namespace + "collection_";
    static AUCTION_TIME = namespace + "auctionTime";
    static COLLECTION_TOTAL = namespace + "collectionTotal";

    static JOB_XP = namespace + "jobXP_";
    static JOB_LEVEL = namespace + "jobLevel_";
    static CURRENT_JOB = namespace + "currentJob";
    static JOB_EXPLOIT = namespace + "jobExploit_";

    static SCORE_SIDE = namespace + "scoreSide";
    static SCORE_LIST = namespace + "scoreList";
    static SCORE_HEAD = namespace + "scoreHead";
    static SPAWN_BUYER = namespace + "spawnBuyer";

}

// Freeze the entire class
Object.freeze(DynamicPropertyEnum);
