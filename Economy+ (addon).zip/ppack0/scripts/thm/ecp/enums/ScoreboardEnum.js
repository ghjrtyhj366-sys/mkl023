
const teamName = "thm"; 
const addonName = "ecp"; 
const namespace = `${teamName}_${addonName}`

export class ScoreboardEnum {
    static OFFLINE_PLAYER_CACHE = "z_DO_NOT_DELETE_Offline_Cache_" + namespace;
    static MONEY_DISPLAY = namespace + ":money_display";
    static MONEY_DISPLAY_NAME = "Money";
    static MONEY_UPDATE = namespace + ":money_update";
    static CACHE = namespace + ":d19097d8-f135";
}

// Freeze the entire class
Object.freeze(ScoreboardEnum);