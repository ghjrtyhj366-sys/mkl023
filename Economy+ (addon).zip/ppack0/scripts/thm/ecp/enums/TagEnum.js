//Enum for entities
export class TagEnum {
    static ATM = 'thm_ecp:atm';
    static AUCTION = 'thm_ecp:auction';
    static ATM_CARD = 'thm_ecp:atm_card';
    static AUCTION = 'thm_ecp:auction';
    static PHONE = 'thm_ecp:phone';
}

// Freeze the entire class
Object.freeze(TagEnum);