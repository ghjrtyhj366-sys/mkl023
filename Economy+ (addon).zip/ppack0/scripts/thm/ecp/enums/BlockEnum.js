//Enum for blocks
export class BlockEnum {
    static AUCTION_BOTTOM = 'thm_ecp:auction_bottom';
    static AUCTION_SIDE = `thm_ecp:auction_side`;
    static AUCTION_TOP = `thm_ecp:auction_top`;
}

// Freeze the entire class
Object.freeze(BlockEnum);