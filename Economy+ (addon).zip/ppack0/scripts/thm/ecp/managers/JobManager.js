import { DynamicPropertyEnum } from "../enums/DynamicPropertyEnum";
import { JobsUtils } from "../utils/JobsUtils";


export class JobManager {

    static addXP(player, XP){
        const newTotal = this.getXP(player) += XP;
        player.setDynamicProperty(DynamicPropertyEnum.JOB_XP + this.getCurrentJobID(player), newTotal);
        return newTotal;
    }

    static getXP(player){
        const current = player.getDynamicProperty(DynamicPropertyEnum.JOB_XP + this.getCurrentJobID(player)) ?? 0;
        return current;
    }

    static getLevel(player){
        const current = player.getDynamicProperty(DynamicPropertyEnum.JOB_LEVEL) ?? 1;
        return current;
    }

    static checkForLevelUp(player) {
        let XP = this.getXP(player);
        let currentLevel = this.getLevel(player);
        
        let xpRequired = JobsUtils.calcXPNeeded(currentLevel);
        
        while (XP >= xpRequired) {
            currentLevel++;
            XP -= xpRequired;
            xpRequired = JobsUtils.calcXPNeeded(currentLevel);
        }
        
        this.setLevel(player, currentLevel);
    }

    static setLevel(player, level){
        player.setDynamicProperty(DynamicPropertyEnum.JOB_LEVEL, level);
    }

    static setXP(player, xp){
        player.setDynamicProperty(DynamicPropertyEnum.JOB_XP + this.getCurrentJobID(player), xp);
    }

    static getCurrentJobID(player){
        return player.getDynamicProperty(DynamicPropertyEnum.CURRENT_JOB);
    }

    static switchJobs(player, newJobID){
        const currentJobID = this.getCurrentJobID(player);

        if(currentJobID !== undefined){
            const currentXP = this.getXP(player);
            const reducedXP = currentXP * 0.7; //30% reduction
            this.setXP(player, reducedXP);
        }
        this.setJob(player, newJobID);
    }

    static setJob(player, jobID){
        player.setDynamicProperty(DynamicPropertyEnum.CURRENT_JOB, jobID);
    }

}