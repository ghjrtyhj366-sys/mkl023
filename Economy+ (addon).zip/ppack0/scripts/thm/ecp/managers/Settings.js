import { DisplaySlotId, world } from "@minecraft/server";
import { DynamicPropertyEnum } from "../enums/DynamicPropertyEnum";
import { ScoreboardEnum } from "../enums/ScoreboardEnum";
import { ScoreboardUtils } from "../utils/ScoreboardUtils";
import { EntityEnum } from "../enums/EntityEnum";
import { MarketManager } from "./MarketManager";

const currentVersion = "1.2.0";

const DEFAULT_SETTINGS = {
    CurrencySymbol: "Cash",
    CurrencyPlacementFront: false,
    MoneyScoreboardName: "Money",
    AuctionTime: 24,
    SpawnTrader: true,
    ScoreSideBar: false,
    ScoreList: false,
    ScoreHead: false
};

const SETTINGS = {
    CurrencySymbol: DEFAULT_SETTINGS.CurrencySymbol,
    CurrencyPlacementFront: DEFAULT_SETTINGS.CurrencyPlacementFront,
    MoneyScoreboardName: DEFAULT_SETTINGS.MoneyScoreboardName,
    AuctionTime: DEFAULT_SETTINGS.AuctionTime,
    SpawnTrader: DEFAULT_SETTINGS.SpawnTrader,
    ScoreSideBar: DEFAULT_SETTINGS.ScoreSideBar,
    ScoreList: DEFAULT_SETTINGS.ScoreList,
    ScoreHead: DEFAULT_SETTINGS.ScoreHead,
};

const settingsNumbers = {
    AuctionTime: {min: 1, max:48, step:1}
}

export class Settings {
    static init() {
        this.setCurrencySymbol(world.getDynamicProperty(DynamicPropertyEnum.CURRENCY_SYMBOL) ?? DEFAULT_SETTINGS.CurrencySymbol);
        this.setCurrencyPlacementFront(world.getDynamicProperty(DynamicPropertyEnum.CURRENCY_PLACEMENT) ?? DEFAULT_SETTINGS.CurrencyPlacementFront);
        this.setMoneyScoreName(world.getDynamicProperty(ScoreboardEnum.MONEY_DISPLAY_NAME) ?? DEFAULT_SETTINGS.MoneyScoreboardName);
        this.setAuctionTime(world.getDynamicProperty(DynamicPropertyEnum.AUCTION_TIME) ?? DEFAULT_SETTINGS.AuctionTime);
        this.setSpawnBuyer(world.getDynamicProperty(DynamicPropertyEnum.SPAWN_BUYER) ?? DEFAULT_SETTINGS.SpawnTrader);
        this.setScoreSideBar(world.getDynamicProperty(DynamicPropertyEnum.SCORE_SIDE) ?? DEFAULT_SETTINGS.ScoreSideBar);
        this.setScoreList(world.getDynamicProperty(DynamicPropertyEnum.SCORE_LIST) ?? DEFAULT_SETTINGS.ScoreList);
        this.setScoreHead(world.getDynamicProperty(DynamicPropertyEnum.SCORE_HEAD) ?? DEFAULT_SETTINGS.ScoreHead);
    }

    static update(newSettings){
        const newScoreName = newSettings.MoneyScoreboardName !== SETTINGS.MoneyScoreboardName;

        this.setCurrencySymbol(newSettings.CurrencySymbol ?? SETTINGS.CurrencySymbol);
        this.setCurrencyPlacementFront(newSettings.CurrencyPlacementFront ?? SETTINGS.CurrencyPlacementFront);
        this.setMoneyScoreName(newSettings.MoneyScoreboardName ?? SETTINGS.MoneyScoreboardName);
        this.setAuctionTime(newSettings.AuctionTime ?? SETTINGS.AuctionTime);
        this.setSpawnBuyer(newSettings.SpawnTrader ?? SETTINGS.SpawnTrader);
        this.setScoreSideBar(newSettings.ScoreSideBar ?? SETTINGS.ScoreSideBar);
        this.setScoreList(newSettings.ScoreList ?? SETTINGS.ScoreList);
        this.setScoreHead(newSettings.ScoreHead ?? SETTINGS.ScoreHead);


        const scoreboard = world.scoreboard;
        const objective = scoreboard.getObjective(ScoreboardEnum.MONEY_DISPLAY);
        
        if(newScoreName){
            ScoreboardUtils.setNewDisplayName(objective, SETTINGS.MoneyScoreboardName);
        }


        if(SETTINGS.ScoreSideBar){
            
            scoreboard.setObjectiveAtDisplaySlot(DisplaySlotId.Sidebar, {objective:objective});
        } else {
            scoreboard.clearObjectiveAtDisplaySlot(DisplaySlotId.Sidebar);
        }

        if(SETTINGS.ScoreList){
            scoreboard.setObjectiveAtDisplaySlot(DisplaySlotId.List, {objective:objective});
        } else {
            scoreboard.clearObjectiveAtDisplaySlot(DisplaySlotId.List);
        }

        if(SETTINGS.ScoreHead){
            scoreboard.setObjectiveAtDisplaySlot(DisplaySlotId.BelowName, {objective:objective});
        } else {
            scoreboard.clearObjectiveAtDisplaySlot(DisplaySlotId.BelowName);
        }
    }

    static getCurrentVersion(){
        return currentVersion;
    }

    static getSettingsNumbers(){
        return settingsNumbers;
    }

    static getSettings(){
        return SETTINGS;
    }
    
    static setCurrencySymbol(symbol) {
        SETTINGS.CurrencySymbol = symbol;
        world.setDynamicProperty(DynamicPropertyEnum.CURRENCY_SYMBOL, symbol);
        updateMarkets();
    }
    
    static getCurrencySymbol() {
        return SETTINGS.CurrencySymbol;
    }
    
    static setCurrencyPlacementFront(frontBool) {
        SETTINGS.CurrencyPlacementFront = frontBool;
        world.setDynamicProperty(DynamicPropertyEnum.CURRENCY_PLACEMENT, frontBool);
        updateMarkets();
    }
    
    static getCurrencyPlacementFront() {
        return SETTINGS.CurrencyPlacementFront;
    }

    static setMoneyScoreName(name){
        SETTINGS.MoneyScoreboardName = name;
        world.setDynamicProperty(ScoreboardEnum.MONEY_DISPLAY_NAME, name);
    }

    static getMoneyScoreName(){
        return SETTINGS.MoneyScoreboardName;
    }

    static setAuctionTime(hours){
        SETTINGS.AuctionTime = hours;
        world.setDynamicProperty(DynamicPropertyEnum.AUCTION_TIME, hours);
    }

    static getAuctionTime(){
        return SETTINGS.AuctionTime;
    }

    static setSpawnBuyer(bool){
        SETTINGS.SpawnTrader = bool;
        world.setDynamicProperty(DynamicPropertyEnum.SPAWN_BUYER, bool);
    }

    static getSpawnBuyer(){
        return SETTINGS.SpawnTrader;
    }

    static setScoreSideBar(bool){
        SETTINGS.ScoreSideBar = bool;
        world.setDynamicProperty(DynamicPropertyEnum.SCORE_SIDE, bool)
    }

    static getScoreSide(){
        return SETTINGS.ScoreSideBar;
    }

    static setScoreList(bool){
        SETTINGS.ScoreList = bool;
        world.setDynamicProperty(DynamicPropertyEnum.SCORE_LIST, bool)
    }

    static getScoreList(){
        return SETTINGS.ScoreList;
    }

    static setScoreHead(bool){
        SETTINGS.ScoreHead = bool;
        world.setDynamicProperty(DynamicPropertyEnum.SCORE_HEAD, bool)
    }

    static getScoreHead(){
        return SETTINGS.ScoreHead;
    }
    
}


function updateMarkets() {
    const players = world.getAllPlayers();
    const markets = new Set(); // Use a Set to store unique entity IDs

    for (const player of players) {
        const nearbyMarkets = player.dimension.getEntities({ type: EntityEnum.MARKET });

        for (const market of nearbyMarkets) {
            markets.add(market.id); // Add each market ID to the Set
        }
    }
    // Convert the Set back to an array if needed
    const uniqueMarketIDs = Array.from(markets);

    for (const marketId of uniqueMarketIDs) {
        const market = world.getEntity(marketId);
        
        if (market) {
            MarketManager.updateNameTag(market)
        }
        
    }

}