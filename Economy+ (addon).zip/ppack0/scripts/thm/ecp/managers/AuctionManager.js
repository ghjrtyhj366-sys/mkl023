import { world, EntityComponentTypes, Entity, ItemStack, Player } from "@minecraft/server";

import { DynamicPropertyEnum } from "../enums/DynamicPropertyEnum";
import { CommonUtils } from "../utils/CommonUtils";
import { Settings } from "./Settings";
import { DateTimeUtils } from "../utils/DateTimeUtils";
import { PlayerUtils } from "../utils/PlayerUtils";
import { AuctionUtils } from "../utils/AuctionUtils";
import { Collection } from "../objects/Collection";
import { ItemUtils } from "../utils/ItemUtils";
import { Listing } from "../objects/Listing";
import { MoneyUtils } from "../utils/MoneyUtils";
import { MessageUtils } from "../utils/MessageUtils";



export class AuctionManager {

    /**
     * Sets the owner details of the auction
     * @param {Entity} auctionEntity 
     * @param {Player} player the player to be the owner
     */
    static setOwner(auctionEntity, player){
        auctionEntity.setDynamicProperty(DynamicPropertyEnum.AUCTION_OWNER_ID, PlayerUtils.getUUID(player));
        auctionEntity.setDynamicProperty(DynamicPropertyEnum.AUCTION_OWNER_NAME, player.name);
    }

    /**
     * Get's the owner of the market details
     * @param {Entity} auctionEntity 
     * @returns {{id:number, name:string}} player the player to be the owner
     */
    static getOwner(auctionEntity){
        return{
            id: auctionEntity.getDynamicProperty(DynamicPropertyEnum.AUCTION_OWNER_ID),
            name: auctionEntity.getDynamicProperty(DynamicPropertyEnum.AUCTION_OWNER_NAME)
        }
    }

    /**
     * Checks if a player is the owner of the shop
     * @param {Entity} auctionEntity 
     * @param {Player} player the player to check
     * @returns {boolean} if the player is the owner
     */
    static isOwner(auctionEntity, player){
        return PlayerUtils.getUUID(player) == auctionEntity.getDynamicProperty(DynamicPropertyEnum.AUCTION_OWNER_ID)
    }

    /**
     * Sets the name of the auction
     * @param {Entity} auctionEntity 
     * @param {string} name name of the auction
     */
    static setName(auctionEntity, name){
        auctionEntity.setDynamicProperty(DynamicPropertyEnum.AUCTION_NAME, name);
        auctionEntity.nameTag = name;
    }

    /**
     * Returns all saved listing
     * @param {Enitity} auctionEntity Auction entity
     * @returns {Listing[]} 
     */
    static getListings(auctionEntity){
        const LISTINGS = [];
        const DPs = auctionEntity.getDynamicPropertyIds().filter(str => str.startsWith(DynamicPropertyEnum.AUCTION_LISTING));
        for (const dp of DPs) {
            const listingString = auctionEntity.getDynamicProperty(dp);
            const listingObject = CommonUtils.stringToObject(listingString);
            LISTINGS.push(listingObject);
        }

        return LISTINGS;
    }

    /**
     * 
     * @param {Entity} auctionEntity Auction entity
     * @param {Number} id ID of the listing
     * @returns {Listing | null} Listing object or Null
     */
    static getListing(auctionEntity, id){
        const listingString = auctionEntity.getDynamicProperty(DynamicPropertyEnum.AUCTION_LISTING + `${id}`);

        if(!listingString) return null;
        return CommonUtils.stringToObject(listingString);
    }

    /**
     * 
     * @param {Entity} auctionEntity Auction entity
     * @param {Number} slot Slot index
     * @returns {ItemStack | false} Item stack in slot or false if the entity/container isn't valid
     */
    static getListingItem(auctionEntity, slot){
        const container = auctionEntity.getComponent(EntityComponentTypes.Inventory).container;

        if(!container.isValid()) return false;

        return container.getItem(slot);
    }

    /**
     * 
     * @param {Entity} auctionEntity Auction Entity
     * @param {Number} id ID for the listing to save
     * @param {Listing} listing Listing object to save
     */
    static saveListing(auctionEntity, id, listing){
        const listingString = CommonUtils.objectToString(listing);
        auctionEntity.setDynamicProperty(DynamicPropertyEnum.AUCTION_LISTING + `${id}`, listingString);
    }

    /**
     * 
     * @param {Entity} auctionEntity Auction entity
     * @param {Number} slot slot index to save item into
     * @param {ItemStack} itemStack Item stack to save
     * @returns {boolean} Returns true of false if saved correctly
     */
    static setListingItem(auctionEntity, slot, itemStack){
        const container = auctionEntity.getComponent(EntityComponentTypes.Inventory).container;
        if(!container.isValid()) return false;

        const itemtoAdd = itemStack.clone();
        
        container.setItem(slot, itemtoAdd);
        return true;
    }

    /**
     * Get the first free listing slot
     * @param {Entity} auctionEntity auction entity
     * @returns {number} slot index
     */
    static getFreeListingSlot(auctionEntity){
        const container = auctionEntity.getComponent(EntityComponentTypes.Inventory).container;
        if (!container.isValid()) return;
        if (container.emptySlotsCount === 0) return;
        
        let slot;
        for (let i = 0; i < container.size; i++) {
            if (container.getSlot(i).hasItem()) continue;
            slot = i;
            break;
        }

        return slot
    }

    /**
     * 
     * @param {Entity} auctionEntity Auction entity
     * @param {Number} slot slot index to remove listing and item
     * @returns {boolean} true if removed, false if container is not valid
     */
    static removeListing(auctionEntity, slot){
        const container = auctionEntity.getComponent(EntityComponentTypes.Inventory).container;
        if(!container.isValid()) return false;
        
        container.setItem(slot, undefined);
        auctionEntity.setDynamicProperty(DynamicPropertyEnum.AUCTION_LISTING + `${slot}`, undefined);
        return true;
    }

    /**
     * Returns bid money to old bidder
     * @param {Listing} listing Listing Object
     * @param {Object} reason Translation Object
     */
    static returnBid(listing, reason){
        const oldBidder = PlayerUtils.isPlayerOnlineFromUUID(listing.bid.ID);
        
        if(oldBidder){
            const oldBidderPlayer = world.getEntity(`${listing.bid.ID}`)
            const oldBidderNewBal = MoneyUtils.addMoney(oldBidderPlayer, listing.bid.value);
            MessageUtils.sendIncreaseMsg(oldBidderPlayer, listing.bid.value, oldBidderNewBal);
            MessageUtils.sendErrorMsg(oldBidderPlayer, reason)
        } else {
            MoneyUtils.sendOfflineMoney(listing.bid.ID, listing.bid.value);
        }
    }

    /**
     * Check if any listings have ended, then move them to collections
     * @param {Entity} auctionEntity auction entity
     */
    static checkForEnded(auctionEntity){
        const listings = this.getListings(auctionEntity);
        const ownerId = this.getOwner(auctionEntity).id

        for (const listing of listings) {
            
            if(!this.hasEnded(listing)) continue;
            
            const item = this.getListingItem(auctionEntity, listing.slot);
            const ID = listing.bid.total > 0 ? listing.bid.ID : ownerId;
            const slotInfo = this.getFreeCollectionSlot(auctionEntity);
            const storageId = slotInfo.storage;
            const slot = slotInfo.slot;
            
            const addedToCollection = this.addCollection(auctionEntity, storageId, slot, item);
            if(!addedToCollection) continue;

            const collection = new Collection(ID, ItemUtils.getItemName(item), item.amount, storageId, slot);
            this.saveCollection(auctionEntity, collection);
            this.removeListing(auctionEntity, listing.slot);

            

            const ownerOnline = PlayerUtils.isPlayerOnlineFromUUID(ownerId);
        
            if(ownerOnline){
                const owner = world.getEntity(`${ownerId}`);
                const ownerNewBal = MoneyUtils.addMoney(owner, listing.bid.value);
                MessageUtils.sendIncreaseMsg(owner, listing.bid.value, ownerNewBal);
                //MessageUtils.sendSuccessMsg(owner, {translate: "thm_ecp.auction.sale", with:[`${ItemUtils.getItemName(item)}`]})
            } else {
                MoneyUtils.sendOfflineMoney(ownerId, listing.bid.value);
            }


        }
    }

    /**
     * 
     * @param {Listing} listing listing object
     * @returns {boolean} true or false if the listing has ended
     */
    static hasEnded(listing){
        const startTime = listing.time;
        const auctionTime = Settings.getAuctionTime();
        
        const endTime = DateTimeUtils.getCurrentUnixTimestamp() + DateTimeUtils.timeToSeconds(auctionTime);

        return DateTimeUtils.hasTimePassed(startTime, endTime);
    }

    /**
     * 
     * @param {Entity} auctionEntity auction entity
     * @returns {Collection[]} array of any collections, can be empty if no collections
     */
    static getCollections(auctionEntity){
        const COLLECTIONS = [];
        const DPs = auctionEntity.getDynamicPropertyIds().filter(str => str.startsWith(DynamicPropertyEnum.AUCTION_COLLECTION));
        for (const dp of DPs) {
            const collectionString = auctionEntity.getDynamicProperty(dp);
            const collectionObject = CommonUtils.stringToObject(collectionString);
            COLLECTIONS.push(collectionObject);
        }
        return COLLECTIONS;
    }

    /**
     * Get collections owned by a player
     * @param {Entity} auctionEntity auction entity
     * @param {Player} player player to check
     * @returns {Collection []} returns array of collection, can be empty if player doesn't own any collections
     */
    static getPlayersCollections(auctionEntity, player){
        const collections = this.getCollections(auctionEntity);
        const PLAYER_COLLECTIONS = [];
        const playerID = PlayerUtils.getUUID(player);

        for (const collection of collections) {
            if(playerID != collection.ownerID) continue;

            PLAYER_COLLECTIONS.push(collection);
        }

        return PLAYER_COLLECTIONS;
    }

    /**
     * Saves collection data
     * @param {Entity} auctionEntity auction entity
     * @param {Collection} collection collection object to save
     */
    static saveCollection(auctionEntity, collection){
        const collectionString = CommonUtils.objectToString(collection);
        auctionEntity.setDynamicProperty(DynamicPropertyEnum.AUCTION_COLLECTION + `${collection.storage.id}_${collection.storage.slot}`, collectionString);
    }

    /**
     * Gets a collection
     * @param {Entity} auctionEntity auction entity
     * @param {number} storageId Storage ID
     * @param {number} slot Slot to get collection
     * @returns {Collection}
     */
    static getCollection(auctionEntity, storageId, slot){
        const collectionString = auctionEntity.getDynamicProperty(DynamicPropertyEnum.AUCTION_COLLECTION + `${storageId}_${slot}`);
        return CommonUtils.stringToObject(collectionString);
    }

    /**
     * 
     * @param {number} storageId Id of the storage entity to get the collection item
     * @param {number} slot Slot index
     * @returns {ItemStack | false} Item stack in slot or false if the entity/container isn't valid
     */
    static getCollectionItem(auctionEntity, storageId, slot){
        const storage = world.getEntity(this.getStorageIDfromSavedID(auctionEntity, storageId));
        if(!storage) return false;

        const container = storage.getComponent(EntityComponentTypes.Inventory).container;
        if(!container.isValid()) return false;

        return container.getItem(slot);
    }

    /**
     * Adds a collection item to collection storage
     * @param {number} storageId Storage id to add
     * @param {number} slot Slot index to add item
     * @param {ItemStack} itemStack Item to add
     * @returns {boolean} True if saved, false if entity or container is not valid
     */
    static addCollection(auctionEntity, storageId, slot, itemStack){
        const storageEntity = world.getEntity(this.getStorageIDfromSavedID(auctionEntity, storageId));
        if(!storageEntity) return false;


        const container = storageEntity.getComponent(EntityComponentTypes.Inventory).container;

        if(!container.isValid()) return false;

        container.setItem(slot, itemStack);
        return true;
    }

    /**
     * 
     * @param {Entity} auctionEntity 
     * @param {number} id 
     * @returns {string}
     */
    static getStorageIDfromSavedID(auctionEntity, id){
        return `${auctionEntity.getDynamicProperty(DynamicPropertyEnum.AUCTION_STORAGE + `${id + 1}`)}`;
    }

    /**
     * Removes a collection from data and storage
     * @param {Entity} auctionEntity auction entity
     * @param {Collection} collection collection object
     * @returns {boolean} true if removed, false if the storage entity or container is not valid
     */
    static removeCollection(auctionEntity, collection){
        const storageEntity = world.getEntity(this.getStorageIDfromSavedID(auctionEntity, collection.storage.id));
        if(!storageEntity) return false;

        const container = storageEntity.getComponent(EntityComponentTypes.Inventory).container;
        if(!container.isValid()) return false;

        container.setItem(collection.storage.slot, undefined);
        auctionEntity.setDynamicProperty(DynamicPropertyEnum.AUCTION_COLLECTION + `${collection.storage.id}_${collection.storage.slot}`, undefined);
        return true;
    }

    /**
     * Find the first free collection storage slot
     * @param {Entity} auctionEntity auction entity
     * @returns {Number} slot index of a free slot
     */
    static getFreeCollectionSlot(auctionEntity){
        const storageEntities = AuctionUtils.getAuctionStorageEntities(auctionEntity);
        
        let slot = null;
    
        for (let index = 0; index < storageEntities.length; index++) {
            const container = storageEntities[index].getComponent(EntityComponentTypes.Inventory).container;
            if (!container.isValid()) continue;
            if (container.emptySlotsCount === 0) continue;
    
            for (let i = 0; index < container.size; i++) {
                if (container.getSlot(i).hasItem()) continue;
                slot = {storage: index, slot:i};
                break;
            }
            if (slot !== null) break; 
        }
        return slot;
    }
}