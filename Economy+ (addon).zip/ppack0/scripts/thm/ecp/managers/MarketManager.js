import { world, EntityComponentTypes } from "@minecraft/server";

import { DynamicPropertyEnum } from "../enums/DynamicPropertyEnum"
import { MoneyUtils } from "../utils/MoneyUtils";
import { ItemUtils } from "../utils/ItemUtils";
import { MessageUtils } from "../utils/MessageUtils";
import { PlayerUtils } from "../utils/PlayerUtils";

export class MarketManager {
    /**
     * Sets the owner details of the market
     * @param {Entity} marketEntity 
     * @param {Player} player the player to be the owner
     */
    static setOwner(marketEntity, player){
        marketEntity.setDynamicProperty(DynamicPropertyEnum.MARKET_OWNER_ID, PlayerUtils.getUUID(player));
        marketEntity.setDynamicProperty(DynamicPropertyEnum.MARKET_OWNER_NAME, player.name);
    }

    /**
     * Get's the owner of the market details
     * @param {Entity} marketEntity 
     * @returns {{id:number, name:string}} player the player to be the owner
     */
    static getOwner(marketEntity){
        return{
            id: marketEntity.getDynamicProperty(DynamicPropertyEnum.MARKET_OWNER_ID),
            name: marketEntity.getDynamicProperty(DynamicPropertyEnum.MARKET_OWNER_NAME)
        }
    }

    /**
     * Checks if a player is the owner of the shop
     * @param {Entity} marketEntity 
     * @param {Player} player the player to check
     * @returns {boolean} if the player is the owner
     */
    static isOwner(marketEntity, player){
        return PlayerUtils.getUUID(player) == marketEntity.getDynamicProperty(DynamicPropertyEnum.MARKET_OWNER_ID)
    }

    /**
     * Gets the name of the market
     * @param {Entity} marketEntity 
     * @returns {string} the name of the market
     */
    static getName(marketEntity){
        return marketEntity.getDynamicProperty(DynamicPropertyEnum.MARKET_NAME);
    }

    /**
     * Sets the name of the market
     * @param {Entity} marketEntity 
     * @param {string} name name of the market
     */
    static setName(marketEntity, name){
        marketEntity.setDynamicProperty(DynamicPropertyEnum.MARKET_NAME, name);
        this.updateNameTag(marketEntity);
    }

    /**
     * Sets the name of the market
     * @param {Entity} marketEntity 
     * @returns {string} name name of the market
     */
    static getName(marketEntity){
        return marketEntity.getDynamicProperty(DynamicPropertyEnum.MARKET_NAME);
    }

    /**
     * Updates the nameTag of the market entity
     * @param {Entity} marketEntity 
     * @param {string} name name of market
     */
    static updateNameTag(marketEntity){
        const name = this.getName(marketEntity);
        let lines = [];

        lines.push(name);

        this.getItems(marketEntity).forEach(marketItem => {
            if(marketItem.item){
                const line = `§c${ItemUtils.getItemName(marketItem.item)}§r | §6${MoneyUtils.getMoneyFormat(marketItem.price)}§r | §bQ:§r${marketItem.stock}`
                lines.push(line);
            }
        });

        let nameTag = "";
        if(lines.length === 0) return;

        lines.forEach(line => {
            nameTag += line + '\n';
        });

        marketEntity.nameTag = nameTag;
    }

     /**
     * Sets an item for sale in a given market slot.
     * @param {Entity} marketEntity 
     * @param {ItemStack} itemStack - The item to set for sale.
     * @param {number} slot - The slot to place the item in (0-2).
     * @param {number} stock - The amount of stock for the item.
     * @param {number} price - The price of the item.
     */
     static setItem(marketEntity, itemStack, slot, stock, price){
        if(!marketEntity)return;
        
        const container = marketEntity.getComponent(EntityComponentTypes.Inventory).container

        const itemtoAdd = itemStack.clone();
        container.setItem(slot, itemtoAdd);
        this.setStock(marketEntity, slot, stock);
        this.setPrice(marketEntity, slot, price);
        this.setSales(marketEntity, slot, 0);
        this.updateNameTag(marketEntity);
        
    }

    /**
     * Removes item from market an updates stock and sales. Handle refund before this method.
     * @param {Entity} marketEntity 
     * @param {number} slot - The slot of item to remove
     */
    static removeItem(marketEntity, slot){
        const container = marketEntity.getComponent(EntityComponentTypes.Inventory).container;
        container.setItem(slot, undefined);
        this.setStock(marketEntity, slot, 0);
        this.setSales(marketEntity, slot, 0);
        this.setPrice(marketEntity, slot, 0);
        this.updateNameTag(marketEntity);
    }

    /**
     * Returns given amount of stock
     * @param {Entity} marketEntity 
     * @param {number} slot - The slot of item to remove
     * @param {Player} player - player to return to
     */
    static returnItems(marketEntity, slot, amount, player){
        const currentStock = this.getStock(marketEntity, slot);
        const currentItem = this.getItem(marketEntity, slot);

        if(currentItem.item !== null && currentItem.item !== undefined){
            if(amount >= 1){
                ItemUtils.spawnItems(currentItem.item, amount, player.location, player.dimension);
            }
        }

        this.setStock(marketEntity, slot, currentStock - amount);
    }

    /**
     * Withdraws sales
     * @param {Entity} marketEntity 
     * @param {number} slot - The slot of item withdraw sales from
     * @param {Player} player - player to give money to
     */
    static withdrawSales(marketEntity, slot, player){
        const currentSales = this.getSales(marketEntity, slot);
        const currentItem = this.getItem(marketEntity, slot);

        if(currentItem.item !== null && currentItem.item !== undefined){
            if(currentSales >= 1){
                MoneyUtils.addMoney(player, currentSales);
                const newBal = MoneyUtils.getMoney(player);
                MessageUtils.sendIncreaseMsg(player, currentSales, newBal, this.getName(marketEntity));
            }
        }

        this.setSales(marketEntity, slot, 0);
    }

    /**
     * Withdraws all sales
     * @param {Entity} marketEntity 
     * @param {Player} player - player to give money to
     */
    static withdrawAllSales(marketEntity, player){
        const currentTotal = this.getTotalSales(marketEntity);
        MoneyUtils.addMoney(player, currentTotal);
        const newBal = MoneyUtils.getMoney(player);
        MessageUtils.sendIncreaseMsg(player, currentTotal, newBal, this.getName(marketEntity));
        this.setSales(marketEntity, 0, 0);
        this.setSales(marketEntity, 1, 0);
        this.setSales(marketEntity, 2, 0);

    }

     /**
     * Retrieves the item details for a specific slot.
     * @param {Entity} marketEntity 
     * @param {number} slot - The slot to retrieve the item from (0-2).
     * @returns {{item: ItemStack, price: number, stock: number, sales:number}} The item details including item, price, stock and sales.
     */
     static getItem(marketEntity, slot){
        return this.getItems(marketEntity)[slot];
    }

    /**
     * Retrieves all item details for the market.
     * @param {Entity} marketEntity 
     * @returns {[{item: ItemStack, price: number, stock: number, sales:number}]} 
     */
    static getItems(marketEntity){
        const container = marketEntity.getComponent(EntityComponentTypes.Inventory).container
        const items = [
            {
                item: container.getItem(0),
                price: marketEntity.getDynamicProperty(DynamicPropertyEnum.MARKET_ITEM_PRICE_1) ?? 0,
                stock: marketEntity.getDynamicProperty(DynamicPropertyEnum.MARKET_ITEM_STOCK_1),
                sales: marketEntity.getDynamicProperty(DynamicPropertyEnum.MARKET_ITEM_SALES_1) ?? 0,
            },
            {
                item: container.getItem(1),
                price: marketEntity.getDynamicProperty(DynamicPropertyEnum.MARKET_ITEM_PRICE_2) ?? 0,
                stock: marketEntity.getDynamicProperty(DynamicPropertyEnum.MARKET_ITEM_STOCK_2) ?? 0,
                sales: marketEntity.getDynamicProperty(DynamicPropertyEnum.MARKET_ITEM_SALES_2) ?? 0,
            },
            {
                item: container.getItem(2),
                price: marketEntity.getDynamicProperty(DynamicPropertyEnum.MARKET_ITEM_PRICE_3) ?? 0,
                stock: marketEntity.getDynamicProperty(DynamicPropertyEnum.MARKET_ITEM_STOCK_3) ?? 0,
                sales: marketEntity.getDynamicProperty(DynamicPropertyEnum.MARKET_ITEM_SALES_3) ?? 0,
            }
        ];
        return items;
    }

    /**
     * Sets the stock quantity for an item in a specific slot.
     * @param {Entity} marketEntity 
     * @param {number} slot - The slot to set the stock for (0-2).
     * @param {number} stock - The new stock quantity.
     */
    static setStock(marketEntity, slot, stock){
        switch (slot) {
            case 0:
                marketEntity.setDynamicProperty(DynamicPropertyEnum.MARKET_ITEM_STOCK_1, stock);
                break;
            case 1:
                marketEntity.setDynamicProperty(DynamicPropertyEnum.MARKET_ITEM_STOCK_2, stock);
                break;
            case 2:
                marketEntity.setDynamicProperty(DynamicPropertyEnum.MARKET_ITEM_STOCK_3, stock);
                break;
        }
        this.updateNameTag(marketEntity);
        
    }   

    /**
     * Retrieves the stock quantity for an item in a specific slot.
     * @param {Entity} marketEntity 
     * @param {number} slot - The slot to retrieve the stock from (0-2).
     * @returns {number} The stock quantity.
     */
    static getStock(marketEntity, slot){
        return this.getItem(marketEntity, slot).stock;
    }

    /**
     * Sets the price for an item in a specific slot.
     * @param {Entity} marketEntity 
     * @param {number} slot - The slot to set the price for (0-2).
     * @param {number} price - The new price.
     */
    static setPrice(marketEntity, slot, price){
        switch (slot) {
            case 0:
                marketEntity.setDynamicProperty(DynamicPropertyEnum.MARKET_ITEM_PRICE_1, price);
                break;
            case 1:
                marketEntity.setDynamicProperty(DynamicPropertyEnum.MARKET_ITEM_PRICE_2, price);
                break;
            case 2:
                marketEntity.setDynamicProperty(DynamicPropertyEnum.MARKET_ITEM_PRICE_3, price);
                break;
        }
        this.updateNameTag(marketEntity);
    }

    /**
     * Retrieves the price for an item in a specific slot.
     * @param {Entity} marketEntity 
     * @param {number} slot - The slot to retrieve the price from (0-2).
     * @returns {number} The price of the item.
     */
    static getPrice(marketEntity, slot){
        return this.getItem(marketEntity, slot).price;
    }

    /**
     * Updates data (stock and sales) once an item is brought
     * @param {Entity} marketEntity 
     * @param {number} slot - The slot for the item/s brought
     * @param {number} amount - The amount of items brought
     */
    static buyItem(marketEntity, slot, amount){
        const marketItem = this.getItem(marketEntity, slot);

        const newStock = marketItem.stock - amount;
        const newSales = marketItem.sales + (marketItem.price * amount)

        this.setStock(marketEntity, slot, newStock);
        this.setSales(marketEntity, slot, newSales);
        this.updateNameTag(marketEntity);

    }

    /**
     * Sets the sales for an item in a specific slot.
     * @param {Entity} marketEntity 
     * @param {number} slot - The slot to set the price for (0-2).
     * @param {number} total - The total amount to set.
     */
    static setSales(marketEntity, slot, total){
        switch (slot) {
            case 0:
                marketEntity.setDynamicProperty(DynamicPropertyEnum.MARKET_ITEM_SALES_1, total);
                break;
            case 1:
                marketEntity.setDynamicProperty(DynamicPropertyEnum.MARKET_ITEM_SALES_2, total);
                break;
            case 2:
                marketEntity.setDynamicProperty(DynamicPropertyEnum.MARKET_ITEM_SALES_3, total);
                break;
        }
    }

    /**
     * Gets the total sales of all items.
     * @param {Entity} marketEntity 
     * @returns {number} - Total sales.
     */
    static getTotalSales(marketEntity){
        return this.getSales(marketEntity, 0) + this.getSales(marketEntity, 1) + this.getSales(marketEntity, 2);
    }

    /**
     * Gets the sales for an item in a specific slot.
     * @param {Entity} marketEntity 
     * @param {number} slot - The slot to set the price for (0-2).
     * @returns {number} - Sales for that item
     */
    static getSales(marketEntity, slot){
        switch (slot) {
            case 0:
               return marketEntity.getDynamicProperty(DynamicPropertyEnum.MARKET_ITEM_SALES_1) ?? 0;
            case 1:
                return marketEntity.getDynamicProperty(DynamicPropertyEnum.MARKET_ITEM_SALES_2) ?? 0;
            case 2:
                return marketEntity.getDynamicProperty(DynamicPropertyEnum.MARKET_ITEM_SALES_3) ?? 0;
        }
    }
}