import { world } from "@minecraft/server";
import { MoneyUtils } from "./MoneyUtils";
import { MessageUtils } from "./MessageUtils";
import { DynamicPropertyEnum } from "../enums/DynamicPropertyEnum";

export class PlayerUtils {

    /**
     * Stores players UUID
     * @param {Player} player - Player to set;
     * @param {number} UUID - UUID to set
     */
    static setUUID(player, UUID){
        player.setDynamicProperty(DynamicPropertyEnum.UUID, UUID);
    }

     /**
     * Get's a players stored UUID
     * @returns {number} - Player UUID
     */
    static getUUID(player){
        return player.getDynamicProperty(DynamicPropertyEnum.UUID);
    }

    /**
     * Get's an online player from UUID
     *
     * @param {number} UUID - The player to check
     * @returns {boolean} - If the player is online
     */
    static isPlayerOnlineFromUUID(UUID) {
        try {
            const player = world.getEntity(`${UUID}`);
            return !!player;
        } catch (error) {
            return false; 
        }
    }

    /**
     * Send money to an online player from a player
     *
     * @param {Player} senderPlayer - The player to take money from (sender)
     * @param {Player} recieverPlayer - The player to give money to (reciever)
     * @param {number} amount - The player to send/recieve
     */
    static sendOnlinePlayerMoney(senderPlayer, recieverPlayer, amount){
        const senderNewBalance = MoneyUtils.removeMoney(senderPlayer, amount);
        const recieverNewBalance = MoneyUtils.addMoney(recieverPlayer, amount);

        MessageUtils.sendDecreaseMsg(senderPlayer, amount, senderNewBalance, recieverPlayer.name);
        MessageUtils.sendIncreaseMsg(recieverPlayer, amount, recieverNewBalance, senderPlayer.name);
    }

    /**
     * Send money to an online player from a player
     *
     * @param {Player} senderPlayer - The player to take money from (sender)
     * @param {string} recieverUUID - The offline player uuid to give money to (reciever)
     * @param {number} amount - The player to send/recieve
     * @param {string} recieverUUID - Optional offline player (reciever) name
     */
    static sendOfflinePlayerMoney(senderPlayer, recieverUUID, amount, recieverName = ""){
        const senderNewBalance = MoneyUtils.removeMoney(senderPlayer, amount);
        MoneyUtils.sendOfflineMoney(recieverUUID, amount);
        MessageUtils.sendDecreaseMsg(senderPlayer, amount, senderNewBalance, recieverName);
    }
}

