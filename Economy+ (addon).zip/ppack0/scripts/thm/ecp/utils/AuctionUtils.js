import { world, Direction, ItemStack, GameMode } from "@minecraft/server";
import { BlockUtils } from "./BlockUtils";
import { MessageUtils } from "./MessageUtils";
import { EntityUtils } from "./EntityUtils";
import { VectorUtils } from "./VectorUtils";
import { SoundEnum } from "../enums/SoundEnum";
import { ActorPropertiesEnum } from "../enums/ActorPropertiesEnum";
import { EntityEnum } from "../enums/EntityEnum";
import { DynamicPropertyEnum } from "../enums/DynamicPropertyEnum";
import { AuctionManager } from "../managers/AuctionManager";


export class AuctionUtils {

    /**
     * Places the auction blocks
     * @param {Player} player - The player placing the auction.
     * @param {Block} block - The block where the auction is being placed.
     * @param {BlockFace} blockFace - The face of the block where the auction is being placed.
     * @param {ItemStack} itemStack - The item being used to place the auction
     */
    static placeAuction(player, block, blockFace, itemStack){
        const spawnLocation = BlockUtils.getPlacedBlockLocation(block, blockFace);
        const dimension = player.dimension;

        if (!isSafeToPlaceAuction(spawnLocation, dimension)) {
            MessageUtils.sendErrorMsg(player, { translate: "thm_ecp.error.auction.place" });
            if(player.getGameMode() != GameMode.creative) dimension.spawnItem(itemStack.clone(), spawnLocation);
            return;
        }

        const playerFacing = EntityUtils.getFacingDirection(player);
        let rotation = 0;
        let offset = {x:1, y:0};
        switch (playerFacing) {
            case Direction.East:
                rotation = 90;
                offset = {z:-1, y:0};
                break;
            case Direction.South:
                rotation = 180;
                offset = {x:-1, y:0};
                break;
            case Direction.West:
                rotation = -90;
                offset = {z:1, y:0};
                break;
        }

        const adjustedSpawnLocation = VectorUtils.add(spawnLocation, {x:0.5, z:0.5});

        const auction = dimension.spawnEntity(EntityEnum.AUCTION, adjustedSpawnLocation);
        auction.setProperty(ActorPropertiesEnum.ROT, rotation);
        AuctionManager.setOwner(auction, player);
        AuctionManager.setName(auction, `${player.name}'s §cAuction`);

        const auctionStorage1 = dimension.spawnEntity(EntityEnum.STORAGE, VectorUtils.add(adjustedSpawnLocation, {y:0.5}));
        const auctionStorage2 = dimension.spawnEntity(EntityEnum.STORAGE, VectorUtils.add(adjustedSpawnLocation, {y:0.5}));
        const auctionStorage3 = dimension.spawnEntity(EntityEnum.STORAGE, VectorUtils.add(adjustedSpawnLocation, {y:0.5}));
        const auctionStorage4 = dimension.spawnEntity(EntityEnum.STORAGE, VectorUtils.add(adjustedSpawnLocation, {y:0.5}));

        auction.setDynamicProperty(DynamicPropertyEnum.AUCTION_STORAGE + "1", auctionStorage1.id);
        auction.setDynamicProperty(DynamicPropertyEnum.AUCTION_STORAGE + "2", auctionStorage2.id);
        auction.setDynamicProperty(DynamicPropertyEnum.AUCTION_STORAGE + "3", auctionStorage3.id);
        auction.setDynamicProperty(DynamicPropertyEnum.AUCTION_STORAGE + "4", auctionStorage4.id);

        player.playSound(SoundEnum.AUCTION_PLACE);
        dimension.spawnParticle("thm_ecp:dust", auction.location);
    }

    /**
     * Removes the auction
     * @param {Player} player 
     * @param {Entity} auctionEntity - Auction entity
     */
    static removeAuction(auctionEntity){
        if(!auctionEntity) return;

        const dimension = auctionEntity.dimension;
        
        const storageEntities = this.getAuctionStorageEntities(auctionEntity);
        
        const auctionSpawnItem = new ItemStack("thm_ecp:item_auction", 1);
        dimension.spawnItem(auctionSpawnItem, auctionEntity.location);

        for (const storageEntity of storageEntities) {
            
            storageEntity.remove()
        }

        auctionEntity.remove();

    }

    static getAuctionStorageEntities(auctionEntity){
        if(!auctionEntity) return;
        const auctionStorage1 = world.getEntity(auctionEntity.getDynamicProperty(DynamicPropertyEnum.AUCTION_STORAGE + "1"));
        const auctionStorage2 = world.getEntity(auctionEntity.getDynamicProperty(DynamicPropertyEnum.AUCTION_STORAGE + "2"));
        const auctionStorage3 = world.getEntity(auctionEntity.getDynamicProperty(DynamicPropertyEnum.AUCTION_STORAGE + "3"));
        const auctionStorage4 = world.getEntity(auctionEntity.getDynamicProperty(DynamicPropertyEnum.AUCTION_STORAGE + "4"));

        return [auctionStorage1, auctionStorage2, auctionStorage3, auctionStorage4];
    }
}

function isSafeToPlaceAuction(location, dimension) {
    const volume = {x:3, y:3, z:3};
    if (!BlockUtils.isVolumeAir(location, volume, dimension)) {
        return false;
    }

    if (EntityUtils.isEntityTypeWithinVolume(location, volume, EntityEnum.AUCTION, dimension)) {
        return false;
    }
    
    return true;
}