/**
 * Utility class for vector operations on 3D vectors.
 */
export class VectorUtils {

    /**
     * Adds two 3D vectors.
     * 
     * @param {Object} firstVector3 - The first vector with x, y, and z components.
     * @param {Object} [secondVector3={ x: 0, y: 0, z: 0 }] - The second vector with x, y, and z components.
     * @returns {Object} A new vector which is the sum of the two input vectors.
     */
    static add(firstVector3, secondVector3 = { x: 0, y: 0, z: 0 }) {
        secondVector3.x = secondVector3.x ? secondVector3.x : 0;
        secondVector3.y = secondVector3.y ? secondVector3.x : 0;
        secondVector3.z = secondVector3.z ? secondVector3.x : 0;
        return {
            x: firstVector3.x + secondVector3.x,
            y: firstVector3.y + secondVector3.y,
            z: firstVector3.z + secondVector3.z
        };
    }

    /**
     * Subtracts the second 3D vector from the first 3D vector.
     * 
     * @param {Object} firstVector3 - The vector to be subtracted from, with x, y, and z components.
     * @param {Object} [secondVector3={ x: 0, y: 0, z: 0 }] - The vector to subtract, with x, y, and z components.
     * @returns {Object} A new vector which is the difference of the two input vectors.
     */
    static subtract(firstVector3, secondVector3 = { x: 0, y: 0, z: 0 }) {
        secondVector3.x = secondVector3.x ? secondVector3.x : 0;
        secondVector3.y = secondVector3.y ? secondVector3.x : 0;
        secondVector3.z = secondVector3.z ? secondVector3.x : 0;
        return {
            x: firstVector3.x - secondVector3.x,
            y: firstVector3.y - secondVector3.y,
            z: firstVector3.z - secondVector3.z
        };
    }

    /**
     * Floors the components of a 3D vector.
     * 
     * @param {Object} vector3 - The vector with x, y, and z components.
     * @returns {Object} A new vector with each component floored to the nearest integer.
     */
    static floor(vector3) {
        return {
            x: Math.floor(vector3.x),
            y: Math.floor(vector3.y),
            z: Math.floor(vector3.z)
        };
    }

    /**
     * Rounds the components of a 3D vector.
     * 
     * @param {Object} vector3 - The vector with x, y, and z components.
     * @returns {Object} A new vector with each component rounded to the nearest integer.
     */
    static round(vector3) {
        return {
            x: Math.round(vector3.x),
            y: Math.round(vector3.y),
            z: Math.round(vector3.z)
        };
    }

    /**
     * Clamps the components of a 3D vector within the given bounds.
     * 
     * @param {Object} vector3 - The vector to clamp, with x, y, and z components.
     * @param {Object} [min={ x: 0, y: 0, z: 0 }] - The minimum bounds with x, y, and z components.
     * @param {Object} [max={ x: 1, y: 1, z: 1 }] - The maximum bounds with x, y, and z components.
     * @returns {Object} A new vector with each component clamped within the specified bounds.
     */
    static clamp(vector3, min = { x: 0, y: 0, z: 0 }, max = { x: 1, y: 1, z: 1 }) {
        min.x = min.x ? min.x : 0;
        min.y = min.y ? min.x : 0;
        min.z = min.z ? min.x : 0;

        max.x = max.x ? max.x : 0;
        max.y = max.y ? max.x : 0;
        max.z = max.z ? max.x : 0;

        return {
            x: Math.max(min.x, Math.min(max.x, vector3.x)), 
            y: Math.max(min.y, Math.min(max.y, vector3.y)),
            z: Math.max(min.z, Math.min(max.z, vector3.z))
        };
    }

    /**
     * Computes the absolute difference between two 3D vectors.
     * 
     * @param {Object} firstVector3 - The first vector with x, y, and z components.
     * @param {Object} secondVector3 - The second vector with x, y, and z components.
     * @returns {Object} A new vector representing the absolute difference between the two input vectors.
     */
    static difference(firstVector3, secondVector3) {
        return {
            x: Math.abs(firstVector3.x - secondVector3.x),
            y: Math.abs(firstVector3.y - secondVector3.y),
            z: Math.abs(firstVector3.z - secondVector3.z)
        };
    }
}
