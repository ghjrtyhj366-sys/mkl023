import { Player, world } from "@minecraft/server";
import { ScoreboardEnum } from "../enums/ScoreboardEnum";
import { MoneyUtils } from "./MoneyUtils";
import { MessageUtils } from "./MessageUtils";

export class CommandUtils{
    /**
     * Updates players money from the update scoreboard
     * @param {Player} string - Player who ran the command
     */
    static update(sender){
        const scoreboard = world.scoreboard.getObjective(ScoreboardEnum.MONEY_UPDATE);
        if(!scoreboard) return;

        const scores = scoreboard.getScores();
        if(scores.length > 0) {
            for (const scoreInfo of scores) {
                const player = scoreInfo.participant.getEntity();
                const value = scoreInfo.score;
                if(player === undefined || player === null) continue;
    
                const newBal = MoneyUtils.addMoney(player, value);
    
                scoreboard.removeParticipant(player);
    
                if(value < 0){
                    MessageUtils.sendDecreaseMsg(player, Math.abs(value), newBal);
                } else {
                    MessageUtils.sendIncreaseMsg(player, value, newBal);
                }
            }
        };
        
        if(sender != null){
            MessageUtils.sendSuccessMsg(sender, {translate:"thm_ecp.command.update"});
        }
    }

    
}
