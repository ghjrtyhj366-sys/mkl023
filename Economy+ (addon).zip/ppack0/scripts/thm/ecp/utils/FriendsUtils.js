import { Player } from "@minecraft/server";
import { DynamicPropertyEnum } from "../enums/DynamicPropertyEnum";


export class FriendsUtils {
    /**
     * Get's the players list of friends or null
     *
     * @param {Player} player - The player to check
     * @returns {[{DPname:string,  name:string, UUID:string }] | []} - Returns the friend array or null
     */
    static getFriendsList(player){
        const friends = [];
        if(!this.hasFriends(player)) return friends;
        const prefix = `${DynamicPropertyEnum.FRIENDS}`
        const DPs = player.getDynamicPropertyIds();

        DPs.forEach(dp => {
            if (dp.startsWith(prefix)) {
                const friendInfo = player.getDynamicProperty(dp).split(':');
                if (friendInfo.length === 2) { 
                    friends.push({DPname:dp, name: friendInfo[0], UUID: friendInfo[1] });
                }
            }
        });
        return friends;
    }

    /**
     * Save a friend to DPs
     *
     * @param {Player} player - The player to save to
     * @param {string} friendName - The friends name to save
     * @param {string} friendUUID - The friends uuid to save
     */
    static saveFriend(player, friendName, friendUUID){
        const friendsList = this.getFriendsList(player);
        const friendCount = (friendsList?.length ?? 0) + 1;    
        player.setDynamicProperty(DynamicPropertyEnum.FRIENDS + `${friendCount}`, `${friendName}:${friendUUID}`);
    }

    /**
     * Remove friend from DPs
     *
     * @param {Player} player - The player to remove from
     * @param {string} friendUUID - The friends UUID to remove
     */
    static removeFriend(player, friendUUID){
        const friendDP = getFriendDP(player, friendUUID);
        try {
            player.setDynamicProperty(friendDP, undefined);
            refreshFriendsList();
        } catch (error) {
            
        }
    }

    /**
     * Check if a player is a friend based on UUID.
     *
     * @param {Player} player - The player to check
     * @param {string} friendUUID - The UUID of the friend to check
     * @returns {boolean} - True if the UUID belongs to a friend, otherwise false
     */
    static isFriend(player, friendUUID) {
        if (!this.hasFriends(player)) return false;
        const friendsList = this.getFriendsList(player);
        return friendsList.some(friend => friend.UUID === friendUUID);
    }

    /**
     * Get a friend's information based on UUID.
     *
     * @param {Player} player - The player whose friends list is being checked.
     * @param {string} friendUUID - The UUID of the friend to retrieve.
     * @returns {Object | null} - The friend's details or null if the UUID does not exist.
     */
    static getFriend(player, friendUUID) {
        if (!this.hasFriends(player)) return null;
        const friendsList = this.getFriendsList(player);
        const friend = friendsList.find(friend => friend.UUID === friendUUID);
        return friend || null;
    }

    /**
     * Checks if a player has any friends saved
     *
     * @param {Player} player - The player to check
     * @returns {boolean} - If the player has any saved friends
     */
    static hasFriends(player) { 
        const DPs = player.getDynamicPropertyIds();
        return DPs ? DPs.some(str => str.startsWith(DynamicPropertyEnum.FRIENDS)) : false;
    }

    /**
     * Get's the UUID of a saved friend
     *
     * @param {Player} player - The player to check
     * @param {string} friendName - The friends name to get the UUID for
     * @returns {string | null} - The friends UUID or null if friend name doesn't exsist
     */
    static getFriendUUID(player, friendName){
        if(!this.hasFriends(player)) return null;
        const friendsList = this.getFriendsList(player);
        const friend = friendsList.find(friend => friend.name === friendName);

        return friend.UUID;
    }
}


function getFriendDP(player, friendUUID){
    const friendsList = FriendsUtils.getFriendsList(player);
    const friend = friendsList.find(friend => friend.UUID === friendUUID);

    return friend.DPname;
}

function refreshFriendsList(player){
    if(!this.hasFriends(player)) return;
    const friendsList = FriendsUtils.getFriendsList(player);
    clearFriends(player);

    friendsList.forEach(friend => {
        saveFriend(player, friend.name, friend.UUID);
    });
}

function clearFriends(player){
    if(!this.hasFriends(player)) return;
    const DPs = player.getDynamicPropertyIds();
    const prefix = `${DynamicPropertyEnum.FRIENDS}`
    DPs.forEach(dp => {
        if (dp.startsWith(prefix)) {
            player.setDynamicProperty(dp, undefined);
        }
    });
}


