export class JobsUtils{

    static calcPay(basePay, jobLevel){
        return basePay + (basePay * (jobLevel - 1) * 0.01);
    }

    static calcXPNeeded(jobLevel){
        return 10 * (jobLevel) + (jobLevel * jobLevel * 4)
    }

    static generateProgressBar(currentValue, maxValue) {

        const notch = "▏";
        // Ensure that currentValue is not greater than maxValue
        currentValue = Math.min(currentValue, maxValue);
        
        // Calculate the percentage
        const percentage = (currentValue / maxValue) * 100;
        
        // Total length of the progress bar (50 notches)
        const totalNotches = 50;
        
        // Calculate the number of filled notches (▏)
        const filledNotches = Math.floor((percentage / 2));
        
        // Construct the progress bar string
        const progressBar = 
            `§a` + 
            notch.repeat(filledNotches) + 
            `§f` + 
            notch.repeat(totalNotches - filledNotches) +
            "§r";
        
        return progressBar;
    }

    static isJobTrigger(jobTrigger, ){
        
    }
}
