import { world, Direction, ItemStack, GameMode } from "@minecraft/server";

import { MessageForms } from "../forms/MessageForms";

import { BlockUtils } from "./BlockUtils";
import { EntityUtils } from "./EntityUtils";
import { EntityEnum } from "../enums/EntityEnum";
import { MessageUtils } from "./MessageUtils";
import { MoneyUtils } from "./MoneyUtils";
import { showMarketItemForm } from "../forms/market/marketItemForm";
import { ItemUtils } from "./ItemUtils";
import { MarketManager } from "../managers/MarketManager";
import { ActorPropertiesEnum } from "../enums/ActorPropertiesEnum";
import { SoundEnum } from "../enums/SoundEnum";
import { VectorUtils } from "./VectorUtils";


export class MarketUtils {

    /**
     * Spawns a market entity at a specified location based on player's facing direction.
     * @param {Player} player - The player spawning the market.
     * @param {Block} block - The block where the market is being spawned.
     * @param {BlockFace} blockFace - The face of the block where the market is being spawned.
     * @param {ItemStack} itemStack - The item being used to spawn the market
     */
    static spawnMarket(player, block, blockFace, itemStack) {
        const spawnLocation = BlockUtils.getPlacedBlockLocation(block, blockFace);
        const dimension = player.dimension;
        if (!isSafeToSpawnMarket(spawnLocation, dimension)) {
            MessageUtils.sendErrorMsg(player, { translate: "thm_ecp.error.market.spawn" });
            if(player.getGameMode() != GameMode.creative) dimension.spawnItem(itemStack.clone(), spawnLocation);
            return;
        }
        
        const playerFacing = EntityUtils.getFacingDirection(player);
        let rotation = 0;
        switch (playerFacing) {
            case Direction.East:
                rotation = 90;
                break;
            case Direction.South:
                rotation = 180;
                break;
            case Direction.West:
                rotation = -90;
                break;
        }

        const adjustedSpawnLocation = VectorUtils.add(spawnLocation, {x:0.5, z:0.5});

        const market = dimension.spawnEntity(EntityEnum.MARKET, adjustedSpawnLocation);
        market.setProperty(ActorPropertiesEnum.ROT, rotation);

        MarketManager.setOwner(market, player);
        MarketManager.setName(market, `${player.name}'s §6Market`);
        player.playSound(SoundEnum.MARKET_PLACE);
        dimension.spawnParticle("thm_ecp:dust", market.location);

    }

    /**
     * Removes market entity and returns items and sales to player
     * @param {Player} player - The player/owner remove the market
     * @param {Entity} marketEntity - The market 
     */
    static removeMarket(player, marketEntity){
        if(!marketEntity) return;

        const marketItem1 = MarketManager.getItem(marketEntity, 0);
        const marketItem2 = MarketManager.getItem(marketEntity, 1);
        const marketItem3 = MarketManager.getItem(marketEntity, 2);

        if(marketItem1.item !== null && marketItem1.item !== undefined){
            ItemUtils.spawnItems(marketItem1.item, marketItem1.stock, player.location, player.dimension);
        }

        if(marketItem2.item !== null && marketItem2.item !== undefined){
            ItemUtils.spawnItems(marketItem2.item, marketItem2.stock, player.location, player.dimension);
        }

        if(marketItem3.item !== null && marketItem3.item !== undefined){
            ItemUtils.spawnItems(marketItem3.item, marketItem3.stock, player.location, player.dimension);
        }

        const total = MarketManager.getTotalSales(marketEntity);

        if(total > 0){
            MarketManager.withdrawAllSales(marketEntity, player);
            
        }
        
        const marketSpawnItem = new ItemStack("thm_ecp:item_market", 1);
        const entityLocation = marketEntity.location
        world.getDimension(player.dimension.id).spawnItem(marketSpawnItem, entityLocation);
        marketEntity.remove();
        
    }

    /**
     * Initiates sale of item to player
     * @param {Player} player - The player buying item
     * @param {Entity} marketEntity - The market entity the player is buying from
     * @param {number} slot - The item slot they are buyng the item from
     * @param {number} amount - The amount of items the player is buying
     */
    static async buyItem(player, marketEntity, slot, amount){
        if(!marketEntity) return;

        const marketItem = MarketManager.getItem(marketEntity, slot);
        const price = marketItem.price;
        const total = price * amount;
       
        const balance = MoneyUtils.getMoney(player);

        if(total > balance){
            if(await errorForm(player, { translate: "thm_ecp.form.market_item.no_money", with:[MoneyUtils.getMoneyFormat(total), MoneyUtils.getMoneyFormat(balance)]})){
                showMarketItemForm(player, marketEntity, slot);
                return;
            }
            return;
        }

        if(amount > marketItem.stock){
            if(await errorForm(player, { translate: "thm_ecp.form.market_item.no_stock", with:[`${marketItem.stock}`, `${amount}`]})){
                showMarketItemForm(player, marketEntity, slot);
                return;
            }
            return;
        }
        
        MarketManager.buyItem(marketEntity, slot, amount);
        MoneyUtils.removeMoney(player, total);
        ItemUtils.spawnItems(marketItem.item, amount, player.location, player.dimension);

        const newBal = MoneyUtils.getMoney(player);
        MessageUtils.sendDecreaseMsg(player, total, newBal);
    }
}


function isSafeToSpawnMarket(location, dimension) {
    const volume = {x:3, y:3, z:3};
    if (!BlockUtils.isVolumeAir(location, volume, dimension)) {
        return false;
    }

    if (EntityUtils.isEntityTypeWithinVolume(location, volume, EntityEnum.MARKET, dimension)) {
        return false;
    }

    return true;
}


async function errorForm(player, error){
    const result = await MessageForms.sendError(
        player, 
        error,
        { translate: "thm_ecp.form.button.exit" },
        { translate: "thm_ecp.form.button.go_back" }
    )
    return result.selection === 1;
}