
import { Player } from "@minecraft/server";
import { MoneyUtils } from "./MoneyUtils";

import { SoundEnum } from "../enums/SoundEnum";

const MSG_PREFIX = "§f[§6Economy§e+§f]:§r"

export class MessageUtils {

    /**
     * Send increased money message to player
     *
     * @param {Player} player - The player to send message to
     * @param {number} amount - The amount of money
     * @param {number} balance - The new balance
     * @param {string} sender - Optional sender name
     */
    static sendIncreaseMsg(player, amount, balance, sender=""){
        const formattedAmount = MoneyUtils.getMoneyFormat(amount);
        const formmatedBalance = MoneyUtils.getMoneyFormat(balance);

        if(sender.length === 0){
            player.sendMessage({ translate: "thm_ecp.msg.increase", with:[MSG_PREFIX, `${formattedAmount}`, `${formmatedBalance}`] })
        } else {
            player.sendMessage({ translate: "thm_ecp.msg.increase.fromsender", with:[MSG_PREFIX, `${formattedAmount}`, sender, `${formmatedBalance}`] })
        }
        player.playSound(SoundEnum.NOTIFICATION);
    }

    /**
     * Send removed money message to player
     *
     * @param {Player} player - The player to send message to
     * @param {number} amount - The amount of money
     * @param {number} balance - The new balance
     * @param {string} reciever - Optional reciever name
     */
    static sendDecreaseMsg(player, amount, balance, reciever=""){
        const formattedAmount = MoneyUtils.getMoneyFormat(amount);
        const formmatedBalance = MoneyUtils.getMoneyFormat(balance);

        if(reciever.length === 0){
            player.sendMessage({ translate: "thm_ecp.msg.decrease", with:[MSG_PREFIX, `${formattedAmount}`, `${balance}`] })
        } else {
            player.sendMessage({ translate: "thm_ecp.msg.decrease.toreciever", with:[MSG_PREFIX, `${formattedAmount}`, reciever, `${formmatedBalance}`] })
        }
        player.playSound(SoundEnum.NOTIFICATION);
    }

    /**
     * Send withdraw money message to player
     *
     * @param {Player} player - The player to send message to
     * @param {number} amount - The amount of money
     * @param {number} balance - The new balance
     */
    static sendWithdrawMsg(player, amount, balance){
        const formattedAmount = MoneyUtils.getMoneyFormat(amount);
        const formmatedBalance = MoneyUtils.getMoneyFormat(balance);
        player.sendMessage({ translate: "thm_ecp.msg.withdraw", with:[MSG_PREFIX, formattedAmount, formmatedBalance] })
        player.playSound(SoundEnum.NOTIFICATION);
    }

    /**
     * Send offline money recieved message to player
     *
     * @param {Player} player - The player to send message to
     * @param {number} amount - The amount of money
     * @param {number} balance - The new balance
     */
    static sendOfflineMoneyMsg(player, amount, balance){
        const formattedAmount = MoneyUtils.getMoneyFormat(amount);
        const formmatedBalance = MoneyUtils.getMoneyFormat(balance);
        player.sendMessage({ translate: "thm_ecp.msg.offlinemoney", with:[MSG_PREFIX, formattedAmount, formmatedBalance] })
        player.playSound(SoundEnum.NOTIFICATION);
    }

    /**
     * Send deposit money message to player
     *
     * @param {Player} player - The player to send message to
     * @param {number} amount - The amount of money
     * @param {number} balance - The new balance
     */
    static sendDepositMsg(player, amount, balance){
        const formattedAmount = MoneyUtils.getMoneyFormat(amount);
        const formmatedBalance = MoneyUtils.getMoneyFormat(balance);
        player.sendMessage({ translate: "thm_ecp.msg.deposit", with:[MSG_PREFIX, formattedAmount, formmatedBalance] })
        player.playSound(SoundEnum.NOTIFICATION);
    }

    /**
     * Send success message to player
     *
     * @param {Player} player - The player to send message to
     * @param {string} msg - The messsage to send
     */
    static sendSuccessMsg(player, msg){
        let text = {
            rawtext: [
            { text: `${MSG_PREFIX}` },
            { text: `§a` },
            msg
            ]
        }
        player.sendMessage(text)
        player.playSound(SoundEnum.POP);
    }

    /**
     * Send plain message to player
     *
     * @param {Player} player - The player to send message to
     * @param {string} msg - The messsage to send
     */
    static sendPlainMsg(player, msg){
        let text = {
            rawtext: [
            { text: `${MSG_PREFIX}` },
            msg
            ]
        }
        player.sendMessage(text)
        player.playSound(SoundEnum.POP);
    }

    /**
     * Send error message to player
     *
     * @param {Player} player - The player to send message to
     * @param {string} msg - The messsage to send
     */
    static sendErrorMsg(player, msg){
        let text = {
            rawtext: [
            { text: `${MSG_PREFIX}` },
            { text: `§c` },
            msg
            ]
        }
        player.sendMessage(text)
        player.playSound(SoundEnum.POP);
    }
}
