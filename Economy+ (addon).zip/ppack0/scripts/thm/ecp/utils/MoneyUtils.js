import { Player, world } from "@minecraft/server";

import { ScoreboardUtils } from "./ScoreboardUtils";

import { DynamicPropertyEnum } from "../enums/DynamicPropertyEnum"
import { ScoreboardEnum } from "../enums/ScoreboardEnum";
import { Settings } from "../managers/Settings";

export class MoneyUtils{
    /**
     * Adds money to an online player
     *
     * @param {Player} player The player to add money to
     * @param {number} amount The amount of money to add to the player's balance
     * @returns {number} Returns the new balance
     */
    static addMoney(player, amount){
        const current = this.getMoney(player);
        const newAmount = current + amount
        player.setDynamicProperty(DynamicPropertyEnum.MONEY, newAmount);
        ScoreboardUtils.updateMoneyDisplay(player);
        return newAmount;
    }

    /**
     * Removes money from an online player
     *
     * @param {Player} player - The player to remove money from
     * @param {number} amount - The amount of money to remove from the player's balance
     * @returns {number} - Returns the new balance
     */
    static removeMoney(player, amount){
        const current = this.getMoney(player);
        const newAmount = current - amount
        if(newAmount < 0){
            player.setDynamicProperty(DynamicPropertyEnum.MONEY, 0);
            return 0;
        }
        player.setDynamicProperty(DynamicPropertyEnum.MONEY, newAmount);
        ScoreboardUtils.updateMoneyDisplay(player);
        return newAmount;
    }
    /**
     * Get money amount from online player
     *
     * @param {Player} player - The player to check
     * @returns {number} - Returns the balance
     */
    static getMoney(player) {
        const current = player.getDynamicProperty(DynamicPropertyEnum.MONEY) ?? 0;
        return current;
    }
    /**
     * Send money to offline player
     *
     * @param {string} UUID - UUID of offline player
     * @param {number} amount - The amount to add to the offline player
     */
    static sendOfflineMoney(UUID, amount){
        const scoreboard = world.scoreboard.getObjective(ScoreboardEnum.OFFLINE_PLAYER_CACHE);
        scoreboard.addScore(UUID,amount);
    }

    /**
     * Get offline player money cache.
     *
     * @param {string} UUID - UUID of offline player
     * @returns {number | 0} - Returns the amount cached or 0
     */
    static getOfflineMoney(UUID) {
        const scoreboard = world.scoreboard.getObjective(ScoreboardEnum.OFFLINE_PLAYER_CACHE);
        if (!scoreboard) return 0;

        if(!scoreboard.hasParticipant(UUID)) return 0;

        return scoreboard.getScore(UUID) ?? 0;
    }

    /**
     * Gets the money formatted
     *
     * @param {number} amount - The amount to format
     * @returns {string} - The formatted amount as string
     */
    static getMoneyFormat(amount) {
        const currencySymbol = Settings.getCurrencySymbol();
        return Settings.getCurrencyPlacementFront() ? `${currencySymbol}${amount}` : `${amount} ${currencySymbol}`;
    }

    /**
     * Resets offline player from scoreboard
     *
     * @param {string} UUID - UUID of offline player
     */
    static resetOfflineMoney(UUID){
        const scoreboard = world.scoreboard.getObjective(ScoreboardEnum.OFFLINE_PLAYER_CACHE);
        scoreboard.removeParticipant(UUID);
    }
}





