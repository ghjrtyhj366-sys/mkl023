import { DisplaySlotId, world } from "@minecraft/server";
import { ScoreboardEnum } from "../enums/ScoreboardEnum";
import { MoneyUtils } from "./MoneyUtils";

/**
 * Utility class for managing scoreboards in Minecraft.
 */
export class ScoreboardUtils {
    /**
     * Initializes the offline player cache scoreboard.
     * Creates the scoreboard objective if it doesn't already exist.
     */
    static initOfflineCache() {
        if (world.scoreboard.getObjective(ScoreboardEnum.OFFLINE_PLAYER_CACHE) === undefined) {
            world.scoreboard.addObjective(ScoreboardEnum.OFFLINE_PLAYER_CACHE);
        }

        if (world.scoreboard.getObjective(ScoreboardEnum.MONEY_UPDATE) === undefined) {
            world.scoreboard.addObjective(ScoreboardEnum.MONEY_UPDATE);
        }
    }

    /**
     * Initializes the money display scoreboard.
     * Creates the scoreboard objective if it doesn't already exist.
     */
    static initMoneyDisplay() {

        let scoreboard = world.scoreboard.getObjective(ScoreboardEnum.MONEY_DISPLAY);

        if (scoreboard === undefined) {
            scoreboard = world.scoreboard.addObjective(ScoreboardEnum.MONEY_DISPLAY, ScoreboardEnum.MONEY_DISPLAY_NAME);
        }

        const participants = scoreboard.getParticipants();

        for (const participant of participants) {
            scoreboard.removeParticipant(participant);
        }

        const players = world.getAllPlayers();

        for (const p of players) {
            this.updateMoneyDisplay(p)
        }
        
    }

    /**
     * Updates the money display scoreboard for a given player.
     * @param {Player} player - The player whose money score needs to be updated.
     */
    static updateMoneyDisplay(player) {
        const scoreboard = world.scoreboard.getObjective(ScoreboardEnum.MONEY_DISPLAY);
        if (!scoreboard) return;
        const money = MoneyUtils.getMoney(player);

        scoreboard.setScore(player, money);
    }

    /**
     * Removes a player from the money display scoreboard.
     * @param {Player} player - The player to be removed from the scoreboard.
     */
    static removeFromMoneyDisplay(player) {
        const scoreboard = world.scoreboard.getObjective(ScoreboardEnum.MONEY_DISPLAY);
        if (!scoreboard) return;
        scoreboard.removeParticipant(player);
    }

    /**
     * Transfers scores from one scoreboard objective to another.
     * @param {string} fromObjective - The name of the source scoreboard objective.
     * @param {string} toObjective - The name of the target scoreboard objective.
     * @returns {boolean} - True if the transfer was successful, otherwise false.
     */
    static transferScores(fromObjective, toObjective) {
        const fromScoreboard = world.scoreboard.getObjective(fromObjective);
        const toScoreboard = world.scoreboard.getObjective(toObjective);
        if (!fromScoreboard || !toScoreboard) return false;

        const scores = fromScoreboard.getScores();

        for (const scoreInfo of scores) {
            toScoreboard.setScore(scoreInfo.participant, scoreInfo.score);
            fromScoreboard.removeParticipant(scoreInfo.participant);
        }

        return true;
    }

    /**
     * Sets a new display name for a scoreboard objective.
     * @param {string} objective - The name of the scoreboard objective to update.
     * @param {string} displayName - The new display name for the scoreboard objective.
     * @returns {boolean} - True if the operation was successful, otherwise false.
     */
    static setNewDisplayName(objective, displayName) {
        world.scoreboard.getObjective(ScoreboardEnum.MONEY_DISPLAY);
        world.scoreboard.removeObjective(objective);

        let scoreboard = world.scoreboard.addObjective(ScoreboardEnum.MONEY_DISPLAY, displayName);

        const participants = scoreboard.getParticipants();

        for (const participant of participants) {
            scoreboard.removeParticipant(participant);
        }

        const players = world.getAllPlayers();

        for (const p of players) {
            this.updateMoneyDisplay(p)
        }
    }
}
