import { world } from "@minecraft/server";
export class BlockUtils{

    static getPlacedBlockLocation(block, blockFace){
        let x = block.location.x;
        let y = block.location.y;
        let z = block.location.z; 
        switch (blockFace) {
            case "Down":
                y--
                break;
            case "East":
                x++
                break;
            case "North":
                z--
                break;
            case "South":
                z++
                break;
            case "Up":
                y++
                break;
            case "West":
                x--
                break;
        } 
        return {x:x, y:y, z:z}      
    }
    

    /**
     * Checks if a given volume centered around the given location is all air blocks above the ground level.
     * @param {Vector3} center - The center location with x, y, and z coordinates. Assumes center is on the ground level.
     * @param {Vector3} volumeVector - The dimensions of the volume with x, y, and z representing width, height, and depth respectively.
     * @param {Dimension} dimension - The Minecraft dimension object to interact with the game.
     * @returns {boolean} - Returns true if the volume above ground level is all air blocks, false otherwise.
     */
    static isVolumeAir(center, volumeVector, dimension) {
        const { x: centerX, y: centerY, z: centerZ } = center;
        const { x: width, y: height, z: depth } = volumeVector;

        const halfWidth = Math.floor(width / 2);
        const halfDepth = Math.floor(depth / 2);

        // Adjust startY to be at ground level
        const startY = centerY;

        for (let dx = -halfWidth; dx <= halfWidth; dx++) {
            for (let dy = 0; dy < height; dy++) { // Only check upwards
                for (let dz = -halfDepth; dz <= halfDepth; dz++) {
                    const block = dimension.getBlock({x:centerX + dx, y:startY + dy, z:centerZ + dz});
                    if (!block.permutation.matches("minecraft:air")) {
                        return false; 
                    }
                }
            }
        }
        return true;
    }
}