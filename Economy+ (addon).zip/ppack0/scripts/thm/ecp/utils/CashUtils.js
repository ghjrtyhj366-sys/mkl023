import { world, EntityComponentTypes } from "@minecraft/server";

import { CASH_ITEMS } from "../data/cashItems";


export class CashUtils {

    /**
     * Get a list of all cash items in the player's inventory with their totals.
     * @param {Player} player - The player whose inventory is being checked.
     * @returns {Array} - A list of objects containing the cash item type and its total amount.
     */
    static getCashInInventory(player) {
        // Get the inventory component of the player
        let { container, inventorySize: length } = player.getComponent(EntityComponentTypes.Inventory);

        // Initialize an object to keep track of the counts of each cash item type
        let cashItemCounts = {};
        for (let cashItem of CASH_ITEMS) {
            cashItemCounts[cashItem.typeId] = 0;
        }

        // Iterate through the player's inventory
        for (let i = 0; i < length; i++) {
            let item = container.getItem(i);
            if (!item) continue; // Skip if the slot is empty
            
            let itemId = item.typeId;
    
            if (this.isCashItem(itemId)) {
                
                cashItemCounts[itemId] += item.amount; // Add the amount of the cash item
            }
        }

        // Convert the cashItemCounts object to a list of objects with item type and total
        let cashItemsWithTotals = [];
        for (let cashItem of CASH_ITEMS) {
            cashItemsWithTotals.push({
                type: cashItem.typeId,
                total: cashItemCounts[cashItem.typeId]
            });
        }

        return cashItemsWithTotals;
    }

    /**
     * Check if an item is a cash item.
     * @param {string} item - The item typeId to check.
     * @returns {boolean} - True if the item is a cash item, otherwise false.
     */
    static isCashItem(item) {        
        return CASH_ITEMS.some(cashItem => cashItem.typeId === item);
    }

    /**
     * Get the total amount of a specific cash item type in the player's inventory.
     * @param {Player} player - The player whose inventory is being checked.
     * @param {string} typeId - The typeId of the cash item to check.
     * @returns {number|null} - The total amount of the cash item, or null if the typeId is not a cash item.
     */
    static getTotalCashItemAmount(player, typeId) {
        // Check if the typeId is a valid cash item
        if (!this.isCashItem(typeId)) {
            return null; // If the typeId is not a cash item, return null
        }

        // Get the list of cash items with their totals
        let cashItemsWithTotals = this.getCashInInventory(player);

        // Find the total for the specific typeId
        let cashItem = cashItemsWithTotals.find(item => item.type === typeId);
        return cashItem ? cashItem.total : 0;
    }

    /**
     * Get the value of a specific cash item type.
     * @param {string} typeId - The typeId of the cash item to check.
     * @returns {number|null} - The value of the cash item, or null if the typeId is not a cash item.
     */
    static getCashItemValue(typeId) {
        // Find the cash item with the given typeId
        let cashItem = CASH_ITEMS.find(item => item.typeId === typeId);
        return cashItem ? cashItem.value : null;
    }

    /**
     * Remove a specified amount of a specific cash item type from the player's inventory.
     * @param {Player} player - The player whose inventory is being modified.
     * @param {string} typeId - The typeId of the cash item to remove.
     * @param {number} amount - The amount of the cash item to remove.
     * @returns {boolean} - True if the removal was successful, otherwise false.
     */
    static removeCashItemFromInventory(player, typeId, amount) {
        // Check if the typeId is a valid cash item
        if (!this.isCashItem(typeId)) {
            return false; // If the typeId is not a cash item, return false
        }

        // Get the inventory component of the player
        let { container, inventorySize: length } = player.getComponent(EntityComponentTypes.Inventory);

        // Track the remaining amount to be removed
        let remainingAmount = amount;

        // Iterate through the player's inventory
        for (let i = 0; i < length && remainingAmount > 0; i++) {
            let item = container.getItem(i);
            if (!item) continue; // Skip if the slot is empty

            let itemId = item.typeId;
            if (itemId === typeId) {
                if (item.amount > remainingAmount) {
                    item.amount -= remainingAmount;
                    remainingAmount = 0;
                    container.setItem(i, item);
                } else {
                    remainingAmount -= item.amount;
                    container.setItem(i, null);
                }
            }
        }

        // Return true if the removal was completely successful, otherwise false
        return remainingAmount === 0;
    }

    /**
     * Calculate the cash items required for a given amount.
     * @param {number} amount - The amount to be converted into cash items.
     * @returns {[{typeId: string, quantity: number}]} - An array of objects containing typeId and quantity.
     */
    static getCashItemsForAmount(amount) {
        let result = [];
        for (let i = CASH_ITEMS.length - 1; i >= 0 && amount > 0; i--) {
            let cashItem = CASH_ITEMS[i];
            let quantity = Math.floor(amount / cashItem.value);
            if (quantity > 64) {
                quantity = 64; // Cap the quantity at 64
            }
            if (quantity > 0) {
                result.push({ typeId: cashItem.typeId, quantity: quantity });
                amount -= quantity * cashItem.value;
            }
        }
        return result;
    }
}
