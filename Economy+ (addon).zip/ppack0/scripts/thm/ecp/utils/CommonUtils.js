

export class CommonUtils {

    /**
     * Converts a JSON string into a JavaScript object.
     * @param {string} string - The JSON string to be converted.
     * @returns {Object|null} The resulting JavaScript object or null if parsing fails.
     */
    static stringToObject(string) {
        try {
            return JSON.parse(string);
        } catch (error) {
            console.error('Error parsing string to object:', error);
            return null;
        }
    }

    /**
     * Converts a JavaScript object into a JSON string.
     * @param {Object} object - The object to be converted.
     * @returns {string|null} The resulting JSON string or null if stringification fails.
     */
    static objectToString(object) {
        try {
            return JSON.stringify(object);
        } catch (error) {
            console.error('Error stringifying object:', error);
            return null;
        }
    }

    /**
     * Calculates the percentage of the first number compared to the second number,
     * clamped to a specified number of decimal places.
     * 
     * @param {number} firstNumber - The numerator for the percentage calculation.
     * @param {number} secondNumber - The denominator for the percentage calculation.
     * @param {number} [decimalPlaces=2] - The number of decimal places to clamp the result to.
     * @returns {number} The percentage value, clamped to the specified decimal places.
     *                    Returns 0 if either firstNumber or secondNumber is 0.
     */
    static getPercentage(firstNumber, secondNumber, decimalPlaces = 2) {
        if (firstNumber === 0 || secondNumber === 0) return 0;
        const percentage = (firstNumber / secondNumber) * 100;
        return Number(percentage.toFixed(decimalPlaces));
    }

    
}