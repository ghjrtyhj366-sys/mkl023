import {world, Direction } from "@minecraft/server";

export class EntityUtils{
    /**
     * Checks if an entity of the given type exists within a specified volume centered around a given location.
     * @param {Vector3} center - The center location with x, y, and z coordinates.
     * @param {Vector3} volumeVector - The dimensions of the volume with x, y, and z representing width, height, and depth respectively.
     * @param {string} entityType - The type of the entity to check for.
     * @param {Dimension} dimension - The Minecraft dimension object to interact with the game.
     * @returns {boolean} - Returns true if an entity of the given type exists within the volume, false otherwise.
     */
    static isEntityTypeWithinVolume(center, volumeVector, entityType, dimension) {
        const { x: centerX, y: centerY, z: centerZ } = center;
        const { x: width, y: height, z: depth } = volumeVector;

        const halfWidth = Math.floor(width / 2);
        const halfHeight = Math.floor(height / 2);
        const halfDepth = Math.floor(depth / 2);

        for (let dx = -halfWidth; dx <= halfWidth; dx++) {
            for (let dy = 0; dy <= halfHeight; dy++) { 
                for (let dz = -halfDepth; dz <= halfDepth; dz++) {
                    const blockLocation = {
                        x: centerX + dx,
                        y: centerY + dy,
                        z: centerZ + dz
                    };

                    const entities = dimension.getEntitiesAtBlockLocation(blockLocation);
                    for (const entity of entities) {
                        if (entity.typeId === entityType) {
                            return true; 
                        }
                    }
                }
            }
        }
        return false;
    }

    /**
     * Determines the cardinal direction (north, east, south, west) based on entity rotation.
     * @param {Entity} entity - The entity object from which to retrieve rotation.
     * @returns {Direction} - Returns the cardinal direction ('north', 'east', 'south', 'west').
     */
    static getFacingDirection(entity) {
        const rotation = entity.getRotation();
        const { x: pitch, y: yaw } = rotation;

        let normalizedYaw = ((yaw % 360) + 360) % 360;

        if (normalizedYaw >= 45 && normalizedYaw < 135) {
            return Direction.West; 
        } else if (normalizedYaw >= 135 && normalizedYaw < 225) {
            return Direction.North; 
        } else if (normalizedYaw >= 225 && normalizedYaw < 315) {
            return Direction.East; 
        } else {
            return Direction.South;
        }
    }
}