export class DateTimeUtils{

  /**
   * Function to convert a date and time string to a Unix timestamp
   * @param {int} year 
   * @param {int} month 
   * @param {int} day 
   * @param {int} hr 
   * @param {int} min 
   * @param {int} sec
   * @returns {number} Returns the Unix Timestamp
   */
  static dateTimeToUnixTimestamp(year, month, day, hr, min, sec) {
    const date = new Date(year, month - 1, day, hr, min, sec);
    return Math.floor(date.getTime()/1000);
  }

  /**
   * Function to convert a Unix timestamp to a date and time string 
   * @param {number} unixTimestamp 
   * @returns {string} Returns the date and time
   */
  static unixTimestampToDateTime(unixTimestamp) {
    const milliseconds = unixTimestamp * 1000;
    const dateTime = new Date(milliseconds);
    
    return `${dateTime}`;
  }

  /**
     * Get the current Unix timestamp.
     * @returns {number} The current Unix timestamp in seconds.
     */
  static getCurrentUnixTimestamp() {
    return Math.floor(Date.now() / 1000);
  }

  /**
   * Convert a time frame to its equivalent in Unix timestamp (seconds)
   * @param {object} timeFrame - Object containing the time frame components
   * @param {int} timeFrame.years - Number of years
   * @param {int} timeFrame.months - Number of months
   * @param {int} timeFrame.days - Number of days
   * @param {int} timeFrame.hours - Number of hours
   * @param {int} timeFrame.minutes - Number of minutes
   * @param {int} timeFrame.seconds - Number of seconds
   * @returns {number} Returns the time frame in seconds
   */
  static timeToSeconds({ years = 0, months = 0, days = 0, hours = 0, minutes = 0, seconds = 0 } = {}) {
    const secondsInMinute = 60;
    const secondsInHour = 3600; // 60 minutes * 60 seconds
    const secondsInDay = 86400; // 24 hours * 3600 seconds
    const secondsInMonth = 2592000; // Approximate (30 days * 86400 seconds)
    const secondsInYear = 31536000; // Approximate (365 days * 86400 seconds)

    const totalSeconds = (years * secondsInYear) +
                        (months * secondsInMonth) +
                        (days * secondsInDay) +
                        (hours * secondsInHour) +
                        (minutes * secondsInMinute) +
                        seconds;
                        
    return totalSeconds;
  }

  /**
   * Check if the first Unix timestamp has passed the second Unix timestamp
   * @param {number} firstUnixTimestamp 
   * @param {number} secondUnixTimestamp 
   * @returns {boolean} Returns true if the first timestamp has passed the second, otherwise false
   */
  static hasTimePassed(firstUnixTimestamp, secondUnixTimestamp) {
    return firstUnixTimestamp < secondUnixTimestamp;
  }

  /**
   * Calculates and formats the time remaining until a specified future Unix timestamp.
   * @param {number} futureUnixTimestamp - The Unix timestamp for the future date.
   * @returns {translation} A translation object representing the time remaining.
   */
  static getTimeRemaining(futureUnixTimestamp) {
    const currentUnixTimestamp = this.getCurrentUnixTimestamp();
    const timeRemainingInSeconds = futureUnixTimestamp - currentUnixTimestamp;

    let translation = { rawtext: [ ] };

    if (timeRemainingInSeconds <= 0) {
      return "The time has already passed.";
    }

    const secondsInMinute = 60;
    const secondsInHour = 3600;
    const secondsInDay = 86400;

    const days = Math.floor(timeRemainingInSeconds / secondsInDay);
    const hours = Math.floor((timeRemainingInSeconds % secondsInDay) / secondsInHour);
    const minutes = Math.floor((timeRemainingInSeconds % secondsInHour) / secondsInMinute);
    const seconds = timeRemainingInSeconds % secondsInMinute;

    if (days > 0) {
      translation.rawtext.push({ translate: `${days !== 1 ? 'thm_ecp.date_time.days' : 'thm_ecp.date_time.day'}`, with:[`${days}`]});
      translation.rawtext.push({text:' '});
    }

    // Display hours if there are any, or if days > 0 to ensure hours are shown with days
    if (hours > 0 || days > 0) {
      translation.rawtext.push({ translate: `${hours !== 1 ? 'thm_ecp.date_time.hours' : 'thm_ecp.date_time.hour'}`, with:[`${hours}`]});
      translation.rawtext.push({text:' '});
    }

    // Display minutes if there are any, or if hours or days > 0 to ensure minutes are shown with hours/days
    if (minutes > 0 || hours > 0 || days > 0) {
      translation.rawtext.push({ translate: `${minutes !== 1 ? 'thm_ecp.date_time.minutes' : 'thm_ecp.date_time.minute'}`, with:[`${minutes}`]});
      translation.rawtext.push({text:' '});
    }

    // Always show seconds
      translation.rawtext.push({ translate: `${seconds !== 1 ? 'thm_ecp.date_time.seconds' : 'thm_ecp.date_time.second'}`, with:[`${seconds}`]});
      translation.rawtext.push({text:' '});

    return translation;
  }

}