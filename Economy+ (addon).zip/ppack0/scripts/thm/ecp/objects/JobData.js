export class JobData{
    constructor(jobID, nameTranslation, description, items){
        this.jobID = jobID;
        this.name = nameTranslation;
        this.description = description
        this.items = items
    }

    isItem(itemID) {
        return this.items.includes(itemID);
    }
}

export class JobItemsData{
    constructor(typeId, trigger, pay, xp){
        this.typeId = typeId;
        this.trigger = trigger
        this.pay = pay;
        this.xp = xp;
    }
}