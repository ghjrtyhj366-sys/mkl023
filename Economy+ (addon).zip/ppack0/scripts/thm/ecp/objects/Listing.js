

export class Listing {
    /**
     * Creates a Listing object
     * @param {number} time Unix time auction started
     * @param {number} price Price for bid increment
     * @param {number} slot Slot the item is saved in storage
     * @param {string} bidName Name of latest bidder
     * @param {number} bidID Player ID of the latest bidder
     * @param {number} bidValue Value of bid
     * @param {number} totalBids Total amount of bids
     * 
     */
    constructor(time, price, slot, bidName, bidID, bidValue, totalBids){
        this.time = time;
        this.slot = slot;
        this.price = price;
        this.bid = {
            name: bidName,
            ID: bidID,
            value: bidValue,
            total: totalBids
        }        
    }
}