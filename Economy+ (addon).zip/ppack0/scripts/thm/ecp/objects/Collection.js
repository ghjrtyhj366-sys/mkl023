

export class Collection {
    /**
     * Creates a Collection object
     * @param {number} ownerID Owning player ID
     * @param {string} itemName Item name
     * @param {number} quantity Quantity of items
     * @param {number} storageId Id of the storage container
     * @param {number} slot Slot the item is saved in storage
     * 
     */
    constructor(ownerID, itemName, quantity, storageId, slot){
        this.ownerID = ownerID;
        this.item = {
            name: itemName,
            quantity: quantity
        };
        this.storage = {
            id: storageId,
            slot: slot
        };        
    }
}

