import { world } from "@minecraft/server";
import { ModalFormData } from "@minecraft/server-ui";

import { showBankForm } from "../mainBank";
import { MessageForms } from "../MessageForms";

import { MoneyUtils } from "../../utils/MoneyUtils";
import { MessageUtils } from "../../utils/MessageUtils";
import { FriendsUtils } from "../../utils/FriendsUtils";

export async function showTransferMoneyForm(player, otherPlayerId, isAtm = false){
    let form = new ModalFormData();
    

    let otherPlayerName;
    let friend;
    
    const isFriend = FriendsUtils.isFriend(player, otherPlayerId);

    let onlinePlayer = world.getEntity(`${otherPlayerId}`);
    if(!onlinePlayer && !isFriend) {
        await errorForm(player, friend, { translate: "thm_ecp.form.error.offline_player" });
        return;
    };
  
    if(onlinePlayer){
        otherPlayerName = onlinePlayer.nameTag;
    }

    if(!onlinePlayer && isFriend){   
        friend = FriendsUtils.getFriend(player, otherPlayerId);
        otherPlayerName = friend.name
    }
 
    form.title({ translate: "thm_ecp.form.transfer_money.title", with:[otherPlayerName] });
    form.textField({ translate: "thm_ecp.form.transfer_money.amount", with:[`${MoneyUtils.getMoneyFormat(MoneyUtils.getMoney(player))}`] },{ translate: "thm_ecp.form.transfer_money.amount.placeholder" });

    const result = await form.show(player);
    if(result.canceled) return;

    const value = parseInt(result.formValues[0], 10);

    if(isNaN(value) || value < 1){
        await errorForm(player, otherPlayerId, { translate: "thm_ecp.form.error.whole_number" }, isAtm);
        return;
    }

    const balance = MoneyUtils.getMoney(player);

    if(balance < value){
        await errorForm(player, otherPlayerId, { translate: "thm_ecp.form.error.insufficient_funds", with:[MoneyUtils.getMoneyFormat(balance)] }, isAtm);
        return;
    }

    onlinePlayer = world.getEntity(`${otherPlayerId}`);

    if(!onlinePlayer && !isFriend) {
        await errorForm(player, otherPlayerId, { translate: "thm_ecp.form.error.offline_player" }, isAtm);
        return;
    };

    if(onlinePlayer){
        MoneyUtils.addMoney(onlinePlayer, value);
        MessageUtils.sendIncreaseMsg(onlinePlayer, value, MoneyUtils.getMoney(onlinePlayer), player.nameTag);
    } else {
        MoneyUtils.sendOfflineMoney(friend.UUID, value);
    }

    const newBal = MoneyUtils.removeMoney(player, value);
    MessageUtils.sendDecreaseMsg(player, value, newBal, otherPlayerName);
}

async function errorForm(player, otherPlayerId, error, isAtm){
    const result = await MessageForms.sendError(
        player, 
        error,
        { translate: "thm_ecp.form.button.exit" },
        { translate: "thm_ecp.form.button.go_back" }
    )

    if(result.selection === 1){
        showBankForm(player, otherPlayerId, isAtm);
    }
}