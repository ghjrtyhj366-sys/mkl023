import { world } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";

import { showSendMoneyForm } from "./sendMoney";
import { showTransferMoneyForm } from "./transferMoney";
import { PlayerUtils } from "../../utils/PlayerUtils";

export async function showOnlinePlayersForm(player, isAtm = false){

    const allPlayers = world.getAllPlayers();
    const onlinePlayers = allPlayers.filter(p => p !== player);
    
    let form = new ActionFormData();
    

    form.title({ translate: "thm_ecp.form.online_players.title" });

    let formBody = {
        rawtext: [
        { translate: `thm_ecp.form.online_players.welcome`, with: [`${onlinePlayers.length}`]},
        { text: '\n\n' },
        { translate: `thm_ecp.form.online_players.how_to`, with: ["\n"] }
        ]
    }
    form.body(formBody);
    form.button({ translate: `thm_ecp.form.button.back`});
    onlinePlayers.forEach(onlinePlayer => {
        form.button(onlinePlayer.name);
    });

    const result = await form.show(player);

    if(result.selection === 0){
        showSendMoneyForm(player, isAtm);
    } else if (result.selection > 0 && result.selection <= onlinePlayers.length ){
        showTransferMoneyForm(player, PlayerUtils.getUUID(onlinePlayers[result.selection - 1]), isAtm);
    }

}