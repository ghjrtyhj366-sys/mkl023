import { ActionFormData } from "@minecraft/server-ui";

import { showBankForm } from "../mainBank";
import { showOnlinePlayersForm } from "./onlinePlayers";
import { showManageFriendsForm } from "../friends/manageFriendsForm";

export async function showSendMoneyForm(player, isATM = false){
    let form = new ActionFormData();

    form.title({ translate: "thm_ecp.form.send_money.title" });
    
    let formBody = {
        rawtext: [
        { translate: `thm_ecp.form.send_money.welcome`},
        { text: '\n\n' },
        { translate: `thm_ecp.form.send_money.how_to.1`},
        { text: '\n\n' },
        { translate: `thm_ecp.form.send_money.how_to.2`},
        { text: '\n' },
        { translate: `thm_ecp.form.send_money.how_to.3`},
        { text: '\n' },
        { translate: `thm_ecp.form.send_money.how_to.4`},
        ]
    }

    form.body(formBody);


    form.button({ translate: `thm_ecp.form.button.online_players`});
    form.button({ translate: `thm_ecp.form.button.friends`});
    form.button({ translate: `thm_ecp.form.button.back`});

    const result = await form.show(player);

    if(result.selection === 0){
        showOnlinePlayersForm(player, isATM);
    } else if (result.selection === 1){
        showManageFriendsForm(player);
    } else if (result.selection === 2){
        showBankForm(player, isATM);
    }
}