import { MessageFormData } from "@minecraft/server-ui";

export class MessageForms {
    static async sendError(player, error, noString, yesString){
        let form = new MessageFormData();
        form.title({ translate: "thm_ecp.form.error.title" });
        form.body(error);
        form.button1(noString);
        form.button2(yesString);

        const result = await form.show(player);

        return result;
    }

    static async sendConfirmation(player, msg){
        let form = new MessageFormData();
        form.title({ translate: "thm_ecp.form.confirm.title" });
        form.body(msg);
        form.button1({ translate: "thm_ecp.form.button.no" });
        form.button2({ translate: "thm_ecp.form.button.yes" });

        const result = await form.show(player);

        return result;
    }
}