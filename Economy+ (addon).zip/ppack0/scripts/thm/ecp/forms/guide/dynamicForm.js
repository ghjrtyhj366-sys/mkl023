import { ActionFormData } from "@minecraft/server-ui";

export async function showDynamicForm(player, data, backFunction){
    let form = new ActionFormData();
    form.title(data.button);
    form.body(data.formBody);
    form.button({ translate: "thm_ecp.form.button.back" });

    const result = await form.show(player);
    const selection = result.selection;
    if(result.canceled) return;

    if(selection === 0) backFunction(player);
}