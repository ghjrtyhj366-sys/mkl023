import { ActionFormData } from "@minecraft/server-ui";
import { HOW_TOS_DATA } from "../../data/howTosData";
import { showMainGuideForm } from "./mainGuideForm";
import { showDynamicForm } from "./dynamicForm";

export async function showHowTosForm(player){
    let form = new ActionFormData();

    form.title({translate: "thm_ecp.form.howtos.title"});
    form.body({translate: "thm_ecp.form.howtos.welcome"});

    const howToData = HOW_TOS_DATA;

    howToData.forEach(data => {
        form.button(data.button);
    });

    form.button({ translate: "thm_ecp.form.button.back" });

    const result = await form.show(player);
    const selection = result.selection;
    if(result.canceled) return;
    if(selection === 0 || selection <= howToData.length - 1){
        showDynamicForm(player, howToData[selection], showHowTosForm);
    } else if(selection === howToData.length){
        showMainGuideForm(player);
    }
}

async function howToForm(player, data){
    let form = new ActionFormData();
    form.title(data.button);
    form.body(data.formBody);
    form.button({ translate: "thm_ecp.form.button.back" });

    const result = await form.show(player);
    const selection = result.selection;
    if(result.canceled) return;

    if(selection === 0) showHowTosForm(player);
}