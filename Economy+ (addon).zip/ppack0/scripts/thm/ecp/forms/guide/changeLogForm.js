import { ActionFormData } from "@minecraft/server-ui";

import { changeLogData } from "../../data/changeLogData";
import { showMainGuideForm } from "./mainGuideForm";


export async function showChangeLogForm(player){
    let form = new ActionFormData();
    form.title({ translate: "thm_ecp.form.changeLog.title" });

    let text = {
        rawtext: [
        { text: '------------------------------' }, 
        ]
      }
    
      changeLogData.slice().reverse().forEach(log => {
    text.rawtext.push(     
        { text: '\n\n' },
        { text: `§dDate§r: ${log.date}` },
        { text: '\n' },
        { text: `§bVersion§r: ${log.version}` },
        { text: '\n' },
        { text: `§aChanges§r:` },
        { text: '\n' },
        { text: `${log.changeLog}` },
        { text: '\n\n' },
        { text: '------------------------------' }, 
    )
    });

    form.body(text);

    form.button({ translate: "thm_ecp.form.button.back" });

    const result = await form.show(player);

    if(result.selection === 0){
        showMainGuideForm(player);
    }
}    