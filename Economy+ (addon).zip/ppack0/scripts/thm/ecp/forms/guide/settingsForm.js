import { ActionFormData } from "@minecraft/server-ui";
import { Settings } from "../../managers/Settings";
import { showSettingsEditForm } from "./settingsEditForm";
import { showMainGuideForm } from "./mainGuideForm";
import { MessageUtils } from "../../utils/MessageUtils";


export async function showSettingsForm(player) {
    let form = new ActionFormData();

    form.title({translate: "thm_ecp.form.settings.title"});

    const settings = Settings.getSettings();
    
    let formBody = {
        rawtext: [
        { translate: `thm_ecp.form.settings.body.1`},
        { text: '\n\n' },
        { translate: `thm_ecp.form.settings.body.2`},
        { text: '\n\n' },
        { translate: `thm_ecp.form.settings.body.3`},
        { text: '\n\n' },
        { translate: `thm_ecp.form.settings.body.4`},
        { text: '\n\n' },
        ]
    }

    Object.keys(settings).forEach((key, index) => {
        const value = settings[key];
        const text = formBody.rawtext;

        text.push({ translate: `thm_ecp.form.settings.${index}`},)
        text.push({ text: '\n' },)
        text.push({ translate: `thm_ecp.form.settings.${index}.info`},)
        text.push({ text: '\n' },)
        text.push({ text: `Value: ${value}` },)
        text.push({ text: '\n\n' },)
    });

    form.body(formBody);

    form.button({ translate: `thm_ecp.settings.button.set`});
    form.button({ translate: "thm_ecp.form.button.back" });

    const result = await form.show(player);
    const selection = result.selection;
    if(result.canceled) return;

    if(selection === 0) {
        if(player.hasTag("admin") || player.hasTag("Admin")) {
            showSettingsEditForm(player);
        } else {
            MessageUtils.sendErrorMsg(player, { translate: `thm_ecp.settings.noPerm`})
        }
    }

    if(selection === 1) showMainGuideForm(player);
}