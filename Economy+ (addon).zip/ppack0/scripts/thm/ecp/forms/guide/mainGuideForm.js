import { ActionFormData } from "@minecraft/server-ui";
import { showChangeLogForm } from "./changeLogForm";
import { showHowTosForm } from "./howtosMainForm";
import { RECIPIES_DATA } from "../../data/recipiesData";
import { showDynamicForm } from "./dynamicForm";
import { showSettingsForm } from "./settingsForm";
import { roadmapData } from "../../data/roadmapData";

export async function showMainGuideForm(player){

    let form = new ActionFormData();

    form.title({translate: "thm_ecp.form.guide.title"});

    let formBody = {
        rawtext: [
        { translate: `thm_ecp.form.guide.welcome.1`},
        { text: '\n' },
        { translate: `thm_ecp.form.guide.welcome.2`},
        { text: '\n\n' },
        { translate: `thm_ecp.form.guide.contents`},
        { text: '\n' },
        { translate: `thm_ecp.form.guide.how_tos`},
        { text: '\n' },
        { translate: `thm_ecp.form.guide.recipies`},
        { text: '\n' },
        { translate: `thm_ecp.form.guide.changelog`},
        { text: '\n' },
        { translate: `thm_ecp.form.guide.roadmap`},
        { text: '\n\n' },
        { translate: `thm_ecp.form.guide.social`},
        { text: '\n' },
        { translate: `thm_ecp_form.guide.discord`}
        ]
    }

    form.body(formBody);

    form.button({ translate: `thm_ecp.guide.button.how_tos`});
    form.button({ translate: `thm_ecp.guide.button.recipies`});
    form.button({ translate: `thm_ecp.guide.button.changelog`});
    form.button({ translate: `thm_ecp.guide.button.roadmap`});
    form.button({ translate: `thm_ecp.guide.button.settings`});


    const result = await form.show(player);
    const selection = result.selection;
    if(result.canceled) return;

    switch (selection) {
        case 0:
            showHowTosForm(player);
            break;
        case 1:
            const recipies = RECIPIES_DATA;
            showDynamicForm(player, recipies[0], showMainGuideForm)
            break;
        case 2:
            showChangeLogForm(player);
            break;
        case 3:
            let roadmapForm = new ActionFormData();
            roadmapForm.title({translate: "thm_ecp.guide.button.roadmap"});
            roadmapForm.body(roadmapData);
            roadmapForm.button({ translate: "thm_ecp.form.button.back" });
            const roadmapFormResult = await roadmapForm.show(player);
            const roadmapFormSelection = roadmapFormResult.selection;
            if(roadmapFormResult.canceled) return;
            if(roadmapFormSelection === 0) showMainGuideForm(player);
            break;
        case 4:
            showSettingsForm(player);
            break;
    }

}