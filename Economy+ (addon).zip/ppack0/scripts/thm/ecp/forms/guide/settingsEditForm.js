import { ModalFormData } from "@minecraft/server-ui";
import { Settings } from "../../managers/Settings";
import { MessageUtils } from "../../utils/MessageUtils";


export async function showSettingsEditForm(player) {
    
    let form = new ModalFormData();

    form.title({translate: "thm_ecp.form.settings.edit.title"});

    const settings = Settings.getSettings();

    Object.keys(settings).forEach((key, index) => {
        const value = settings[key];

        if(typeof value === 'boolean'){
            form.toggle({translate: `thm_ecp.form.settings.${index}`}, value);
        } 
        else if (typeof value === 'string') {
            form.textField({translate: `thm_ecp.form.settings.${index}`}, "", value);
        } 
        else if (typeof value === 'number') {
            const format = Settings.getSettingsNumbers()[key];
            form.slider({translate: `thm_ecp.form.settings.${index}`}, format.min, format.max, format.step, value);
        }
        
    });

    const result = await form.show(player);
    if(result.canceled) return;

    let newSettings = {};
    Object.keys(settings).forEach((key, index) => {

        newSettings[key] = result.formValues[index]
    });
    Settings.update(newSettings);
    MessageUtils.sendSuccessMsg(player,{translate: `thm_ecp.settings.changed`});
}