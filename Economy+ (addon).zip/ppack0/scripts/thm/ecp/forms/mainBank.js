import { ActionFormData } from "@minecraft/server-ui";

import { MoneyUtils } from "../utils/MoneyUtils";

import { showSendMoneyForm } from "./digital/sendMoney";
import { showManageFriendsForm } from "./friends/manageFriendsForm";
import { showDepositForm } from "./cash/deposit";
import { showWithdrawForm } from "./cash/withdraw";

export async function showBankForm(player, isAtm = false){
    let form = new ActionFormData();

    const balance = MoneyUtils.getMoney(player);
    const formattedBalance = MoneyUtils.getMoneyFormat(balance);


    form.title({ translate: "thm_ecp.form.banking.title" });

    let formBody = {
        rawtext: [
        { translate: `thm_ecp.form.banking.welcome`, with: [player.name] },
        { text: '\n\n' },
        { text: `--------------------------` },
        { text: '\n\n' },
        { translate: `thm_ecp.form.banking.balance`, with: [formattedBalance] },
        { text: '\n\n' },
        { text: `--------------------------` },
        ]
    }

    form.body(formBody);


    form.button({ translate: `thm_ecp.form.button.send_money`});
    form.button({ translate: `thm_ecp.form.button.manage_friends`});

    if(isAtm){
        form.button({ translate: `thm_ecp.form.button.deposit`});
        form.button({ translate: `thm_ecp.form.button.withdraw`});
    }

    const result = await form.show(player);

    if(result.selection === 0){
        showSendMoneyForm(player, isAtm);
    } else if (result.selection === 1){
        showManageFriendsForm(player, isAtm);
    } else if (result.selection === 2){
        showDepositForm(player);
    } else if (result.selection === 3){
        showWithdrawForm(player);
    }
}
