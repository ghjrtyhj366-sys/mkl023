import { ActionFormData } from "@minecraft/server-ui";
import { AuctionManager } from "../../managers/AuctionManager";
import { ItemUtils } from "../../utils/ItemUtils";
import { MoneyUtils } from "../../utils/MoneyUtils";
import { showMainAuctionForm } from "./mainAuction";
import { showListingInfoForm } from "./listingInfoForm";


export async function showListingsForm(player, auctionEntity){
    let form = new ActionFormData();
    form.title({translate: "thm_ecp.form.auction_listings.title"});
    
    let formBody = {
        rawtext: [
        { translate: `thm_ecp.form.listings.welcome`}
        ]
    }

    form.body(formBody);

    const listings = AuctionManager.getListings(auctionEntity);

    for (const listing of listings) {
        const item = AuctionManager.getListingItem(auctionEntity, listing.slot);

        if(!item) continue;

        let buttonText = {
            rawtext: [
            {text: `${ItemUtils.getItemName(item)} x ${item.amount} | `},
            {text: `\n`},
            { translate: `thm_ecp.form.button.bid_increment`},
            {text: ` : ${MoneyUtils.getMoneyFormat(listing.price)}`}
            ]
        }
        
        form.button(buttonText)
    }
    
    form.button({ translate: `thm_ecp.form.button.back`});

    const result = await form.show(player);
    const selection = result.selection;
    if(result.canceled) return;
    if(!auctionEntity) return;

    if(selection >=0 && selection < listings.length){
        showListingInfoForm(player, auctionEntity, listings[selection]);

    } else if(selection === listings.length){
        showMainAuctionForm(player, auctionEntity);
    }

}