import { ModalFormData } from "@minecraft/server-ui";
import { AuctionManager } from "../../managers/AuctionManager";
import { ItemUtils } from "../../utils/ItemUtils";
import { MoneyUtils } from "../../utils/MoneyUtils";
import { MessageForms } from "../MessageForms";
import { Listing } from "../../objects/Listing";
import { PlayerUtils } from "../../utils/PlayerUtils";
import { MessageUtils } from "../../utils/MessageUtils";

export async function showBidForm(player, auctionEntity, listing){
    let form = new ModalFormData();
    const item = AuctionManager.getListingItem(auctionEntity, listing.slot)

    form.title({translate: "thm_ecp.form.bid.title", with:[ItemUtils.getItemName(item)]});

    form.textField(
        { translate: `thm_ecp.form.bid.bid_increment`, with:[MoneyUtils.getMoneyFormat(listing.price), MoneyUtils.getMoneyFormat(listing.bid.value)]},
        { translate: `thm_ecp.form.bid.bid_increment_placeholder`, with:[MoneyUtils.getMoneyFormat(listing.price)]}
    )


    const result = await form.show(player);
    if(result.canceled) return;

    const value = parseInt(result.formValues[0], 10);

    if(isNaN(value) || value < 1){
        await errorForm(player, { translate: "thm_ecp.form.error.whole_number" }, listing);
        return;
    }

    const balance = MoneyUtils.getMoney(player);

    if(balance < value){
        await errorForm(player, { translate: "thm_ecp.form.error.insufficient_funds", with:[MoneyUtils.getMoneyFormat(balance)] }, listing, auctionEntity);
        return;
    }
    const totalBidValue = listing.bid.value + value;
    const updatedListing = new Listing(
        listing.time,
        listing.price,
        listing.slot,
        player.nameTag,
        PlayerUtils.getUUID(player),
        totalBidValue,
        listing.bid.total + 1
    );
   
    const newBal = MoneyUtils.removeMoney(player, totalBidValue);
    MessageUtils.sendDecreaseMsg(player, totalBidValue, newBal);
    if(listing.bid.total > 0) AuctionManager.returnBid(listing, {translate: "thm_ecp.auction.out_bid", with:[`${ItemUtils.getItemName(item)}`, `${AuctionManager.getOwner(auctionEntity).name}`]});

    AuctionManager.saveListing(auctionEntity, listing.slot, updatedListing);

    
    MessageUtils.sendSuccessMsg(player, {translate: "thm_ecp.auction.new_bid"});

}

async function errorForm(player, error, listing, auctionEntity){
    const result = await MessageForms.sendError(
        player, 
        error,
        { translate: "thm_ecp.form.button.exit" },
        { translate: "thm_ecp.form.button.go_back" }
    )

    if(result.selection === 1){
        showBidForm(player, auctionEntity, listing);
    }
}