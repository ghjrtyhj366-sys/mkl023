import { ActionFormData } from "@minecraft/server-ui";
import { AuctionManager } from "../../managers/AuctionManager";
import { MessageForms } from "../MessageForms";
import { showListingsForm } from "./listingsForm";
import { ItemUtils } from "../../utils/ItemUtils";
import { MessageUtils } from "../../utils/MessageUtils";
import { EntityComponentTypes, EquipmentSlot } from "@minecraft/server";
import { showAddListingForm } from "./addListing";
import { AuctionUtils } from "../../utils/AuctionUtils";

export async function showMainAuctionForm(player, auctionEntity){
    AuctionManager.checkForEnded(auctionEntity);
    
    let form = new ActionFormData();
    form.title({translate: "thm_ecp.form.auction.title"});

    let formBody = {
        rawtext: [
        { translate: `thm_ecp.form.auction.welcome`},
        { text: '\n\n' },
        { translate: `thm_ecp.form.auction.howto.listings`},
        { text: '\n' },
        { translate: `thm_ecp.form.auction.howto.add`},
        { text: '\n' },
        { translate: `thm_ecp.form.auction.howto.remove`},
        { text: '\n' },
        { translate: `thm_ecp.form.auction.howto.collect.item`},
        { text: '\n' },
        { translate: `thm_ecp.form.auction.howto.remove_auction`}
        ]
    }

    form.body(formBody);
    const totalListings = AuctionManager.getListings(auctionEntity);

    const isOwner = AuctionManager.isOwner(auctionEntity, player);
    const totalCollections = AuctionManager.getPlayersCollections(auctionEntity, player);

    form.button({ translate: `thm_ecp.form.button.listings`, with:[`${totalListings.length}`]});

    let collectButton = {
        rawtext: [
        { translate: `thm_ecp.form.button.collect_item`, with:[`${totalCollections.length}`]},
        { text: '\n' },
        { translate: `thm_ecp.form.button.collect_item.collections`, with:[`${AuctionManager.getPlayersCollections(auctionEntity, player).length}`]},
        ]
    }

    form.button(collectButton);

    if(isOwner){
        form.button({ translate: `thm_ecp.form.button.add_listing`});
        form.button({ translate: `thm_ecp.form.button.remove_auction`});
    }
    
    form.button({ translate: `thm_ecp.form.button.exit`});

    const result = await form.show(player);
    const selection = result.selection;
    if(result.canceled) return;
    if(!auctionEntity) return;

    if(selection === 0){
        if(totalListings === 0){
            const goBack = await errorForm(player, { translate: "thm_ecp.form.auction.error.no_listings" });
            if(goBack) showMainAuctionForm(player, auctionEntity);
            return
        }
        showListingsForm(player, auctionEntity);
    } else if(selection === 1){
        //collect
        if(totalCollections.length === 0){
            const goBack = await errorForm(player, { translate: "thm_ecp.form.auction.error.no_collections" });
            if(goBack) showMainAuctionForm(player, auctionEntity);
            return
        }

        for (const collection of totalCollections) {
            
            const item = AuctionManager.getCollectionItem(auctionEntity, collection.storage.id, collection.storage.slot);
            ItemUtils.spawnItems(item, collection.item.quantity, player.location, player.dimension);
            MessageUtils.sendSuccessMsg(player, {translate:"thm_ecp.form.auction.collected", with:[`${collection.item.quantity}`, `${ItemUtils.getItemName(item)}`]});
            AuctionManager.removeCollection(auctionEntity, collection);
        }
    } else if(selection === 2 && isOwner){
        //add listing
        const listings = AuctionManager.getListings(auctionEntity);
        if(listings.length === 27){
            const goBack = await errorForm(player, { translate: "thm_ecp.form.auction.error.no_space" });
            if(goBack) showMainAuctionForm(player, auctionEntity);
            return
        }

        const collections = AuctionManager.getCollections(auctionEntity);
        if(collections.length === 81){
            const goBack = await errorForm(player, { translate: "thm_ecp.form.auction.error.no_space_collections" });
            if(goBack) showMainAuctionForm(player, auctionEntity);
            return
        }

        const item = player?.getComponent(EntityComponentTypes.Equippable)?.getEquipment(EquipmentSlot.Mainhand);
        if(!item){
            const goBack = await errorForm(player, { translate: "thm_ecp.form.auction.error.no_item" });
            if(goBack) showMainAuctionForm(player, auctionEntity);
            return
        }
        
        showAddListingForm(player, auctionEntity);


    } else if(selection === 3 && isOwner){
        //remove auction
        const collections = AuctionManager.getCollections(auctionEntity);

        if(collections.length > 0){
            const goBack = await errorForm(player, { translate: "thm_ecp.form.auction.error.remove_auction.collections" });
            if(goBack) showMainAuctionForm(player, auctionEntity);
            return
        }

        const confirmRemove = await confirmForm(player, {translate:"thm_ecp.form.auction.remove_auction"});
        if(!confirmRemove) return;

        const listings = AuctionManager.getListings(auctionEntity);

        for (const listing of listings) {
            const item = AuctionManager.getListingItem(auctionEntity, listing.slot);

            ItemUtils.spawnItems(item, item.amount, player.location, player.dimension);
            if(listing.bid.total > 0){
                AuctionManager.returnBid(
                    listing, 
                    {translate: "thm_ecp.auction.returned_bid_removed", with:[`${ItemUtils.getItemName(item)}`, `${AuctionManager.getOwner(auctionEntity).name}`]})
            }
        }

        AuctionUtils.removeAuction(auctionEntity)

    }
}

async function errorForm(player, error){
    const result = await MessageForms.sendError(
        player, 
        error,
        { translate: "thm_ecp.form.button.exit" },
        { translate: "thm_ecp.form.button.go_back" }
    )
    return result.selection === 1;
}

async function confirmForm(player, message){
    const result = await MessageForms.sendConfirmation(
        player, 
        message
    )
    return result.selection === 1;
}