import { EntityComponentTypes, EquipmentSlot } from "@minecraft/server";
import { ModalFormData } from "@minecraft/server-ui";
import { MessageForms } from "../MessageForms";
import { AuctionManager } from "../../managers/AuctionManager";
import { Listing } from "../../objects/Listing";
import { DateTimeUtils } from "../../utils/DateTimeUtils";
import { ItemUtils } from "../../utils/ItemUtils";
import { MessageUtils } from "../../utils/MessageUtils";
import { MoneyUtils } from "../../utils/MoneyUtils";
import { Settings } from "../../managers/Settings";

export async function showAddListingForm(player, auctionEntity){
    const item = player?.getComponent(EntityComponentTypes.Equippable)?.getEquipment(EquipmentSlot.Mainhand);

    let form = new ModalFormData();

    form.title({translate: "thm_ecp.form.add_listing.title", with:[`${item.typeId}`, `${item.amount}`]});

    form.textField({translate:"thm_ecp.form.add_listing.increment"}, {translate:"thm_ecp.form.add_listing.increment.placeholder"});

    const result = await form.show(player);
    if(result.canceled) return;

    const value = parseInt(result.formValues[0], 10);

    if(isNaN(value) || value < 1){
        await errorForm(player, { translate: "thm_ecp.form.error.whole_number" }, auctionEntity);
        return;
    }
    
    const slotIndex = AuctionManager.getFreeListingSlot(auctionEntity);

    const listing = new Listing(
        DateTimeUtils.getCurrentUnixTimestamp() + DateTimeUtils.timeToSeconds({hours:Settings.getAuctionTime()}),
        value,
        slotIndex,
        null,
        null,
        0,
        0
    );

    AuctionManager.saveListing(auctionEntity, slotIndex, listing);
    AuctionManager.setListingItem(auctionEntity, slotIndex, item);
    ItemUtils.removeMainhandItem(player);
    MessageUtils.sendSuccessMsg(player, {translate:"thm_ecp.auction.new_listing", with:[`${item.typeId}`, MoneyUtils.getMoneyFormat(value)]});

}

async function errorForm(player, error, auctionEntity){
    const result = await MessageForms.sendError(
        player, 
        error,
        { translate: "thm_ecp.form.button.exit" },
        { translate: "thm_ecp.form.button.go_back" }
    )

    if(result.selection === 1){
        showAddListingForm(player, auctionEntity);
    }
}