import { ActionFormData } from "@minecraft/server-ui";
import { AuctionManager } from "../../managers/AuctionManager";
import { ItemComponentTypes, world } from "@minecraft/server";
import { CommonUtils } from "../../utils/CommonUtils";
import { ENCHANTMENT_STRINGS } from "../../data/enchantmentStrings";
import { MoneyUtils } from "../../utils/MoneyUtils";
import { DateTimeUtils } from "../../utils/DateTimeUtils";
import { showListingsForm } from "./listingsForm";
import { MessageForms } from "../MessageForms";
import { showBidForm } from "./bidForm";
import { ItemUtils } from "../../utils/ItemUtils";
import { MessageUtils } from "../../utils/MessageUtils";
import { PlayerUtils } from "../../utils/PlayerUtils";

export async function showListingInfoForm(player, auctionEntity, listing){
    let form = new ActionFormData();
    form.title({translate: "thm_ecp.form.listing_info.title"});

    const item = AuctionManager.getListingItem(auctionEntity, listing.slot)

    const timeLeft = DateTimeUtils.getTimeRemaining(listing.time).rawtext;
    
    let formBody = {
        rawtext: [
        { translate: `thm_ecp.form.listing_info.welcome`},
        {text: '\n\n'},
        { translate: `thm_ecp.form.listing_info`},
        {text: `\n`},
        {text: `----------`},
        {text: `\n`},
        { translate: `thm_ecp.form.listing_info.item_name`, with:[ItemUtils.getItemName(item)]},
        {text: `\n`},
        { translate: `thm_ecp.form.listing_info.quantity`, with:[`${item.amount}`]},
        {text: `\n`},
        { translate: `thm_ecp.form.listing_info.item_type`, with:[`${item.typeId}`]},
        {text: `\n`},
        ]
    }

    const components = item.getComponents();
    
    if(components.length > 0){
        formBody.rawtext.push({ text: '§bItem Components§r:' },);
        formBody.rawtext.push({ text: '\n' },);
        for (const component of components) {
            if(component.typeId === "minecraft:durability"){
                formBody.rawtext.push({ text: ` §cDurability§r: ${Math.floor((component.maxDurability - component.damage)/ component.maxDurability * 100)}%%` },);
                formBody.rawtext.push({ text: '\n' },);
            }

            if(component.typeId === "minecraft:enchantable"){

                const enchants = component.getEnchantments();
                if(enchants.length === 0) continue;

                formBody.rawtext.push({ text: ` §dEnchants§r:` },);
                formBody.rawtext.push({ text: '\n' },);

                for (const enchant of enchants) {
                    formBody.rawtext.push({ text: `  - ` },);
                    formBody.rawtext.push({ translate: `${ENCHANTMENT_STRINGS[enchant.type.id]}`})
                    formBody.rawtext.push({ text: ` ` },);
                    formBody.rawtext.push({ translate: `${enchant.level <=10 && enchant.level > 0 ? `enchantment.level.${enchant.level}` : enchant.level}`})
                    formBody.rawtext.push({ text: '\n' },);
                }
            }

            if(component.typeId === "minecraft:potion"){

                formBody.rawtext.push({ text: ` Potion: ${component.potionEffectType.id} ${component.potionLiquidType.id}` },);
                formBody.rawtext.push({ text: '\n' },);
            }
        }
    }

    formBody.rawtext.push(
        {text: `\n\n`},
        { translate: `thm_ecp.form.listing_info.bid_info`},
        {text: `\n`},
        {text: `----------`},
        {text: `\n`},
        { translate: `thm_ecp.form.listing_info.bid_increment`, with:[MoneyUtils.getMoneyFormat(listing.price)]},
        {text: `\n`},
        { translate: `thm_ecp.form.listing_info.current_bid`, with:[`${listing.bid.value != 0 ? listing.bid.name : 'N/A'}`, MoneyUtils.getMoneyFormat(listing.bid.value)]},
        {text: `\n`},
        { translate: `thm_ecp.form.listing_info.total_bids`, with:[`${listing.bid.total}`]},
        {text: `\n`},
        { translate: `thm_ecp.form.listing_info.time_left`},
        {text: ` `},
        ...timeLeft,
        {text: `\n`},
    )

    form.body(formBody);
    const isOwner = AuctionManager.isOwner(auctionEntity, player); 

    if(!isOwner){
        form.button({ translate: `thm_ecp.form.button.bid`, with:[MoneyUtils.getMoneyFormat(listing.bid.value + listing.price)]});
    } else {
        form.button({ translate: `thm_ecp.form.button.remove_listing`});
    }
    form.button({ translate: `thm_ecp.form.button.back`});

    const result = await form.show(player);
    const selection = result.selection;
    if(result.canceled) return;
    if(!auctionEntity) return;

    if(selection === 0 && !isOwner){
        if(listing.bid.ID == PlayerUtils.getUUID(player)){
            const goBack2 = await errorForm(player, { translate: "thm_ecp.form.auction.error.last_bidder" });
            if(goBack2) showListingInfoForm(player, auctionEntity, listing);
            return
        }
        if(MoneyUtils.getMoney(player) < listing.bid.value + listing.price){
            const goBack = await errorForm(player, { translate: "thm_ecp.form.auction.error.not_enough_fo_bid" });
            if(goBack) showListingInfoForm(player, auctionEntity, listing);
            return
        }
        showBidForm(player, auctionEntity, listing);

    } else if(selection === 0 && isOwner){
        const confirmed = await confirmForm(player, {translate:"thm_ecp.form.auction.remove_listing", with:[`${listing.bid.total}`, MoneyUtils.getMoneyFormat(listing.bid.value)]});
        if(!confirmed){
            showListingInfoForm(player, auctionEntity, listing);
        } else {

            if(listing.bid.total > 0){
                AuctionManager.returnBid(
                    auctionEntity, 
                    listing, 
                    {translate: "thm_ecp.auction.out_bid", with:[`${ItemUtils.getItemName(item)}`, `${AuctionManager.getOwner(auctionEntity).name}`]});
            }
            
            ItemUtils.spawnItems(item, item.amount, player.location, player.dimension);
            AuctionManager.removeListing(auctionEntity, listing.slot);
            MessageUtils.sendSuccessMsg(player, {translate: "thm_ecp.auction.removed_listing"});
        }

    } else if(selection === 1){
        showListingsForm(player, auctionEntity);
    }
}

async function confirmForm(player, message){
    const result = await MessageForms.sendConfirmation(
        player, 
        message
    )
    return result.selection === 1;
}

async function errorForm(player, error){
    const result = await MessageForms.sendError(
        player, 
        error,
        { translate: "thm_ecp.form.button.exit" },
        { translate: "thm_ecp.form.button.go_back" }
    )
    return result.selection === 1;
}