import { ActionFormData } from "@minecraft/server-ui";
import { world } from "@minecraft/server";

import { FriendsUtils } from "../../utils/FriendsUtils";
import { MessageUtils } from "../../utils/MessageUtils";

import { MessageForms } from "../MessageForms";
import { showManageFriendsForm } from "./manageFriendsForm";
import { PlayerUtils } from "../../utils/PlayerUtils";

export async function showAddFriendForm(player, isAtm = false){

    let form = new ActionFormData();

    form.title({ translate: "thm_ecp.form.add_friend.title" });
    
    const allPlayers = world.getAllPlayers();
    const onlinePlayers = allPlayers.filter(p => p !== player);

    const friends = FriendsUtils.getFriendsList(player);

    // Extract UUIDs of friends
    const friendUUIDs = friends.map(friend => friend.UUID);

    // Filter out friends from online players
    const nonFriends = onlinePlayers.filter(p => !friendUUIDs.includes(PlayerUtils.getUUID(p)));

    form.body({ translate: "thm_ecp.form.add_friend.body", with:["\n"] });
    form.button({ translate: "thm_ecp.form.button.back" });

    nonFriends.forEach(nonFriend => {
        form.button(nonFriend.name);
    });

    const result = await form.show(player);
    const selection = result.selection;

    if(selection === 0){
        showManageFriendsForm(player, isAtm);
    } else if(selection > 0){
        const newFriend = nonFriends[selection - 1];
        
        const confirmed = await confirmForm(player, newFriend.name, isAtm);
        
        if(!confirmed) return;

        FriendsUtils.saveFriend(player, newFriend.nameTag, PlayerUtils.getUUID(newFriend));
        
        MessageUtils.sendSuccessMsg(player, { translate: "thm_ecp.form.add_friend.added", with:[`§b${newFriend.name}§r`] })
    }
    
}

async function confirmForm(player, newFriendName, isAtm){
    const result = await MessageForms.sendConfirmation(
        player, 
        { translate: "thm_ecp.form.newFriendName.confirm", with:[newFriendName] }
    )

    if(result.selection === 0){
        showAddFriendForm(player, isAtm);
        return false;
    } else if(result.selection === 1){
        return true;
    }
}