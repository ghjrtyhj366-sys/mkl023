import { ActionFormData } from "@minecraft/server-ui";

import { showBankForm } from "../mainBank";
import { showAddFriendForm } from "./addFriendForm";
import { showFriendForm } from "./friendForm";

import { FriendsUtils } from "../../utils/FriendsUtils";

export async function showManageFriendsForm(player, isAtm = false){
    const friendsList = FriendsUtils.getFriendsList(player);
    let form = new ActionFormData();

    form.title({ translate: "thm_ecp.form.manage_friends.title" });
    let formBody = {
        rawtext: [
        { translate: `thm_ecp.form.manage_friends.welcome.1`},
        { text: '\n\n' },
        { translate: `thm_ecp.form.manage_friends.welcome.2`},
        ]
    }


    form.body(formBody);

    form.button({ translate: "thm_ecp.form.button.add_friend" });
    form.button({ translate: "thm_ecp.form.button.back" });

    if(friendsList.length > 0){
        friendsList.forEach(friend => {
            form.button(friend.name);
        });
    }

    const result = await form.show(player);

    if(result.selection === 0){
        showAddFriendForm(player, isAtm);
    } else if(result.selection === 1){
        showBankForm(player, isAtm);
    } else if(result.selection > 1){
        showFriendForm(player, friendsList[result.selection - 2], isAtm);
    }
}