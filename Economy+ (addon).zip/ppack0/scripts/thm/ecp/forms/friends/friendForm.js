import { ActionFormData } from "@minecraft/server-ui";

import { showTransferMoneyForm } from "../digital/transferMoney";
import { showManageFriendsForm } from "./manageFriendsForm";
import { MessageForms } from "../MessageForms";

import { FriendsUtils } from "../../utils/FriendsUtils";
import { MessageUtils } from "../../utils/MessageUtils";

export async function showFriendForm(player, friend, isAtm = false){
    let form = new ActionFormData();

    form.title(friend.name);
    form.body({ translate: "thm_ecp.form.friend_form.body" })

    form.button({ translate: "thm_ecp.form.button.send_money" });
    form.button({ translate: "thm_ecp.form.button.remove_friend" });
    form.button({ translate: "thm_ecp.form.button.back" });


    const result = await form.show(player);

    if(result.selection === 0){
        showTransferMoneyForm(player, friend.UUID, isAtm);
    } else if (result.selection === 1){
        const confirmResult = await MessageForms.sendConfirmation(player,{ translate: "thm_ecp.form.friend_form.remove_friend", with: [friend.name] });

        if(confirmResult.selection === 0){
            showFriendForm(player, friend, isAtm);
        } else if(confirmResult.selection === 1){
            FriendsUtils.removeFriend(player, friend.UUID);
            MessageUtils.sendSuccessMsg(player,{ translate: "thm_ecp.form.friend_form.remove_friend.success", with: [friend.name] } );
        }

    } else if(result.selection === 2){
        showManageFriendsForm(player, isAtm);
    }
}