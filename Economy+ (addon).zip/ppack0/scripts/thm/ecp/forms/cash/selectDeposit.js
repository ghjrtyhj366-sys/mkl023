import { ModalFormData } from "@minecraft/server-ui";

import { MessageForms } from "../MessageForms";
import { showBankForm } from "../mainBank";

import { CashUtils } from "../../utils/CashUtils";
import { MoneyUtils } from "../../utils/MoneyUtils";
import { MessageUtils } from "../../utils/MessageUtils";

export async function showSelectDepositForm(player){
    let form = new ModalFormData();

    form.title({ translate: "thm_ecp.form.deposit.title" });

    const cashInInventory = CashUtils.getCashInInventory(player);

    const cashOnHand = [];
    
    cashInInventory.forEach(cash => {
        if(cash.total === 0) return;
        cashOnHand.push(cash);
        form.slider({ translate: `thm_ecp.form.deposit.item`, with: [MoneyUtils.getMoneyFormat(CashUtils.getCashItemValue(cash.type))]}, 0, cash.total, 1, 0)
    });

    if(cashOnHand.length === 0){
        errorForm(player, {translate: "thm_ecp.form.deposit.no_cash"});
        return;
    }

    const result = await form.show(player);

    if(result.canceled) return;

    let total = 0;
    result.formValues.forEach((value, index) =>  {
        if(value === 0) return;
        total += CashUtils.getCashItemValue(cashOnHand[index].type) * value;
    });

    const playerConfirmed = await confirmForm(player, total);
    if(!playerConfirmed) return;

    result.formValues.forEach((value, index) =>  {
        if(value === 0) return;
        CashUtils.removeCashItemFromInventory(player, cashOnHand[index].type, value);
    });
    
    if(total === 0) {
        MessageUtils.sendPlainMsg(player, {translate: "thm_ecp.form.deposit.zero_total"})
        return;
    };
    
    MoneyUtils.addMoney(player, total);
    const newBal = MoneyUtils.getMoney(player);
    MessageUtils.sendDepositMsg(player, total, newBal);
}

async function confirmForm(player, total){
    const result = await MessageForms.sendConfirmation(
        player, 
        { translate: "thm_ecp.form.deposit.confirm", with:[MoneyUtils.getMoneyFormat(total)] }
    )

    if(result.selection === 0){
        showBankForm(player, true);
        return false;
    } else if(result.selection === 1){
        return true;
    }
}

async function errorForm(player, error){
    const result = await MessageForms.sendError(
        player, 
        error,
        { translate: "thm_ecp.form.button.exit" },
        { translate: "thm_ecp.form.button.go_back" }
    )

    if(result.selection === 1){
        showBankForm(player, true)
    }
}