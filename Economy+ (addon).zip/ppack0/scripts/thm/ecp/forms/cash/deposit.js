import { ActionFormData } from "@minecraft/server-ui";

import { MessageForms } from "../MessageForms";
import { showBankForm } from "../mainBank";
import { showSelectDepositForm } from "./selectDeposit";

import { CashUtils } from "../../utils/CashUtils";
import { MoneyUtils } from "../../utils/MoneyUtils";
import { MessageUtils } from "../../utils/MessageUtils";

export async function showDepositForm(player){
    
    const cashInInventory = CashUtils.getCashInInventory(player);

    let total = 0;
    cashInInventory.forEach(cash => {
        if(cash.total === 0) return;
        total += CashUtils.getCashItemValue(cash.type) * cash.total;
    });

    if(total === 0){
        errorForm(player, {translate: "thm_ecp.form.deposit.no_cash"});
        return;
    }

    let form = new ActionFormData();
    form.title({ translate: "thm_ecp.form.deposit.title" });

    form.button({translate: "thm_ecp.form.deposit.all", with:[MoneyUtils.getMoneyFormat(total)]});
    form.button({translate: "thm_ecp.form.deposit.select"});
    form.button({translate: "thm_ecp.form.button.back"});

    const result = await form.show(player);
    const selection = result.selection;
    if(result.canceled) return;

    
    if(selection === 0){

        const playerConfirmed = await confirmForm(player, total);
        if(!playerConfirmed) return;

        cashInInventory.forEach(cash => {
            if(cash.total === 0) return;
            CashUtils.removeCashItemFromInventory(player, cash.type, cash.total);
        });

        MoneyUtils.addMoney(player, total);
        const newBal = MoneyUtils.getMoney(player);
        MessageUtils.sendDepositMsg(player, total, newBal);

    } else if(selection === 1){
        showSelectDepositForm(player);
    } else if(selection === 2){
        showBankForm(player, true);
    }
    
}

async function confirmForm(player, total){
    const result = await MessageForms.sendConfirmation(
        player, 
        { translate: "thm_ecp.form.deposit.confirm", with:[MoneyUtils.getMoneyFormat(total)] }
    )

    if(result.selection === 0){
        showBankForm(player, true);
        return false;
    } else if(result.selection === 1){
        return true;
    }
}

async function errorForm(player, error){
    const result = await MessageForms.sendError(
        player, 
        error,
        { translate: "thm_ecp.form.button.exit" },
        { translate: "thm_ecp.form.button.go_back" }
    )

    if(result.selection === 1){
        showBankForm(player, true)
    }
}