import { world, ItemStack } from "@minecraft/server";

import { ModalFormData } from "@minecraft/server-ui";
import { MessageForms } from "../MessageForms";
import { showBankForm } from "../mainBank";

import { MoneyUtils } from "../../utils/MoneyUtils";
import { MessageUtils } from "../../utils/MessageUtils";
import { CashUtils } from "../../utils/CashUtils";

export async function showWithdrawForm(player){
    let form = new ModalFormData();

    form.title({ translate: "thm_ecp.form.withdraw.title" });
    form.textField({ translate: "thm_ecp.form.withdraw.amount", with:[`${MoneyUtils.getMoneyFormat(MoneyUtils.getMoney(player))}`] },{ translate: "thm_ecp.form.withdraw.amount.placeholder" });

    const result = await form.show(player);

    if(result.canceled) return;

    let value = parseInt(result.formValues[0], 10);

    if(isNaN(value) || value < 1){
        await errorForm(player, { translate: "thm_ecp.form.error.whole_number" });
        return;
    }

    const balance = MoneyUtils.getMoney(player);
    
    if(balance < value){
        await errorForm(player, { translate: "thm_ecp.form.error.insufficient_funds", with:[MoneyUtils.getMoneyFormat(balance)] });
        return;
    }

    const confirmed = await confirmForm(player, value);
    if(!confirmed) return;

    const cashItemIds = CashUtils.getCashItemsForAmount(value);

    cashItemIds.forEach(cashItem => {
        const item = new ItemStack(cashItem.typeId, cashItem.quantity);
        world.getDimension(player.dimension.id).spawnItem(item, player.location);
    });

    MoneyUtils.removeMoney(player, value);
    const newBal = MoneyUtils.getMoney(player);
    MessageUtils.sendWithdrawMsg(player, value, newBal);
}

async function errorForm(player, error){
    const result = await MessageForms.sendError(
        player, 
        error,
        { translate: "thm_ecp.form.button.go_back" },
        { translate: "thm_ecp.form.button.try_again" }
    )

    if(result.selection === 0){
        showBankForm(player, true);
    } else if(result.selection === 1){
        showWithdrawForm(player);
    }
}

async function confirmForm(player, total){
    const result = await MessageForms.sendConfirmation(
        player, 
        { translate: "thm_ecp.form.withdraw.confirm", with:[MoneyUtils.getMoneyFormat(total)] }
    )

    if(result.selection === 0){
        showBankForm(player, true);
        return false;
    } else if(result.selection === 1){
        return true;
    }
}