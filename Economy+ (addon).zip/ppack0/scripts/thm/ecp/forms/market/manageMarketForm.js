import { ActionFormData, ModalFormData } from "@minecraft/server-ui";
import { MarketUtils } from "../../utils/MarketUtils";
import { MoneyUtils } from "../../utils/MoneyUtils";
import { showMarketManageItemForm } from "./manageItemForm";
import { showMainMarketForm } from "./mainMarket";
import { MessageForms } from "../MessageForms";
import { MarketManager } from "../../managers/MarketManager";
import { ItemUtils } from "../../utils/ItemUtils";
import { MessageUtils } from "../../utils/MessageUtils";
import { MARKET_COLOURS } from "../../data/marketColours";
import { ActorPropertiesEnum } from "../../enums/ActorPropertiesEnum";

export async function showManageMerketForm(player, marketEntity){
    const marketName = MarketManager.getName(marketEntity);
    let form = new ActionFormData();
    form.title(marketName);

    const marketItem1 = MarketManager.getItem(marketEntity, 0);
    const marketItem2 = MarketManager.getItem(marketEntity, 1);
    const marketItem3 = MarketManager.getItem(marketEntity, 2);


    let formBody = {
        rawtext: [
        { translate: `thm_ecp.form.manage_market.title`},
        { text: '\n\n' },
        { translate: `thm_ecp.form.manage_market.welcome`},
        { text: '\n\n' }
        
        ]
    }

    if(marketItem1.item !== null && marketItem1.item !== undefined){

        formBody.rawtext.push(
            { translate: `thm_ecp.form.market.item1`},
            { text: '\n' },
            { translate: `thm_ecp.form.market.item`, with: [ItemUtils.getItemName(marketItem1.item)] },
            { text: '\n' },
            { translate: `thm_ecp.form.market.price`, with: [MoneyUtils.getMoneyFormat(marketItem1.price)] },
            { text: '\n' },
            { translate: `thm_ecp.form.market.stock`, with: [`${marketItem1.stock}`] },
            { text: '\n' },
            { translate: `thm_ecp.form.market.sales`, with: [MoneyUtils.getMoneyFormat(marketItem1.sales)] },
            { text: '\n\n' }
        )
    }

    if(marketItem2.item !== null && marketItem2.item !== undefined){

        formBody.rawtext.push(
            { translate: `thm_ecp.form.market.item2`},
            { text: '\n' },
            { translate: `thm_ecp.form.market.item`, with: [ItemUtils.getItemName(marketItem2.item)] },
            { text: '\n' },
            { translate: `thm_ecp.form.market.price`, with: [MoneyUtils.getMoneyFormat(marketItem2.price)] },
            { text: '\n' },
            { translate: `thm_ecp.form.market.stock`, with: [`${marketItem2.stock}`] },
            { text: '\n' },
            { translate: `thm_ecp.form.market.sales`, with: [MoneyUtils.getMoneyFormat(marketItem2.sales)] },
            { text: '\n\n' }
        )
    }

    if(marketItem3.item !== null && marketItem3.item !== undefined){
        
        formBody.rawtext.push(
            { translate: `thm_ecp.form.market.item3`},
            { text: '\n' },
            { translate: `thm_ecp.form.market.item`, with: [ItemUtils.getItemName(marketItem3.item)] },
            { text: '\n' },
            { translate: `thm_ecp.form.market.price`, with: [MoneyUtils.getMoneyFormat(marketItem3.price)] },
            { text: '\n' },
            { translate: `thm_ecp.form.market.stock`, with: [`${marketItem3.stock}`] },
            { text: '\n' },
            { translate: `thm_ecp.form.market.sales`, with: [MoneyUtils.getMoneyFormat(marketItem3.sales)] },
            { text: '\n\n' }
        )
    }

    form.body(formBody);

    form.button({ translate: `thm_ecp.form.button.edit_item_1`});
    form.button({ translate: `thm_ecp.form.button.edit_item_2`});
    form.button({ translate: `thm_ecp.form.button.edit_item_3`});
    form.button({ translate: `thm_ecp.form.button.withdraw_market`, with:[`\n`,MoneyUtils.getMoneyFormat(MarketManager.getTotalSales(marketEntity))]});
    form.button({ translate: `thm_ecp.form.button.remove_market`});
    form.button({ translate: `thm_ecp.form.button.market_colour`});
    form.button({ translate: `thm_ecp.form.button.back`});

    const result = await form.show(player);
    const selection = result.selection;
    if(result.canceled) return;
    
    if(selection >= 0 && selection <= 2){
        showMarketManageItemForm(player, marketEntity, selection);
    } else if(selection === 4){
        const confrimedRemove = await confirmForm(player, { translate: "thm_ecp.form.manage_market.remove_confirm" });
        if(!confrimedRemove) return;
        MarketUtils.removeMarket(player, marketEntity);

    } else if(selection === 3){
        if(MarketManager.getTotalSales(marketEntity) === 0){
            MessageUtils.sendErrorMsg(player, {translate:"thm_ecp.form.manage_market.withdraw_sales.empty"});
            return;
        }
        const confrimedWitdraw = await confirmForm(player, { translate: "thm_ecp.form.manage_market.withdraw_sales", with: [MoneyUtils.getMoneyFormat(MarketManager.getTotalSales(marketEntity))] });
        if(!confrimedWitdraw) return;

        MarketManager.withdrawAllSales(marketEntity, player);
    } else if(selection === 5){
        let colourForm = new ModalFormData();
        colourForm.title({ translate: "thm_ecp.form.manage_market.market_colour" });
        const colours = MARKET_COLOURS;

        colourForm.dropdown({translate:"thm_ecp.form.manage_market.colour1"}, colours, marketEntity.getProperty(ActorPropertiesEnum.COLOUR_1));
        colourForm.dropdown({translate:"thm_ecp.form.manage_market.colour2"}, colours, marketEntity.getProperty(ActorPropertiesEnum.COLOUR_2));

        const colourForm_result = await colourForm.show(player);
        if(colourForm_result.canceled) return;

        const colour1 = parseInt(colourForm_result.formValues[0], 10)
        const colour2 = parseInt(colourForm_result.formValues[1], 10)

        marketEntity.setProperty(ActorPropertiesEnum.COLOUR_1, colour1);
        marketEntity.setProperty(ActorPropertiesEnum.COLOUR_2, colour2);

        MessageUtils.sendSuccessMsg(player, { translate: "thm_ecp.form.manage_market.colours_changed", with:[`${colours[colour1]}`, `${colours[colour2]}`]});

    } else if(selection === 6){
        showMainMarketForm(player, marketEntity);
    }
}


async function confirmForm(player, text){
    const result = await MessageForms.sendConfirmation(
        player, 
        text
    )
    return result.selection === 1;
}