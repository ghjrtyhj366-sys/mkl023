import { ActionFormData } from "@minecraft/server-ui";
import { MoneyUtils } from "../../utils/MoneyUtils";
import { ItemUtils } from "../../utils/ItemUtils";
import { showMarketItemForm } from "./marketItemForm";
import { showManageMerketForm } from "./manageMarketForm";
import { MarketManager } from "../../managers/MarketManager";
import { MessageUtils } from "../../utils/MessageUtils";

export async function showMainMarketForm(player, marketEntity){
    const marketName = MarketManager.getName(marketEntity);

    let form = new ActionFormData();
    form.title(marketName);

    let formBody = {
        rawtext: [
        { translate: `thm_ecp.form.market.welcome`, with: [`${MarketManager.getOwner(marketEntity).name}`]}
        ]
    }

    let itemButtons = [];
    const marketItems = MarketManager.getItems(marketEntity);
    
    marketItems.forEach((marketItem, index) => {
        if(marketItem.item === null || marketItem.item === undefined) return;

        const itemName = ItemUtils.getItemName(marketItem.item)

        form.button(`§4` + itemName + ` §r| §5Price: §r${MoneyUtils.getMoneyFormat(marketItem.price)} \n§1Quantity: §r${marketItem.stock}`);
        itemButtons.push(`item${index}`);
    });

    if(itemButtons.length === 0){
        formBody.rawtext.push({ text: '\n\n' },{ translate: `thm_ecp.form.market.no_items`});
    }

    const isOwner = MarketManager.isOwner(marketEntity, player);

    if(isOwner){
        form.button({ translate: `thm_ecp.form.market.manage_market`});
        itemButtons.push("manage_market");
        formBody.rawtext.push({ text: '\n\n' });
        formBody.rawtext.push({ translate: `thm_ecp.form.market.owner` });
    }

    form.body(formBody);

    form.button({ translate: `thm_ecp.form.button.exit`});

    const result = await form.show(player);
    const selection = result.selection;
    if(result.canceled) return;
    if(!marketEntity) return;

    if(itemButtons.length === 0 && !isOwner) return;

    const formToShow = itemButtons[selection];

    switch (formToShow) {
        case "item0":
            const item0 = MarketManager.getItem(marketEntity, 0);
            if(item0.stock === 0){
                MessageUtils.sendErrorMsg(player, {translate:"thm_ecp.form.market.out_of_stock"});
                return
            }
            showMarketItemForm(player, marketEntity, 0);
            break;
           
        case "item1":
            const item1 = MarketManager.getItem(marketEntity, 1);
            if(item1.stock === 0){
                MessageUtils.sendErrorMsg(player, {translate:"thm_ecp.form.market.out_of_stock"});
                return
            }
            showMarketItemForm(player, marketEntity, 1);
            break;
        case "item2":
            const item2 = MarketManager.getItem(marketEntity, 2);
            if(item2.stock === 0){
                MessageUtils.sendErrorMsg(player, {translate:"thm_ecp.form.market.out_of_stock"});
                return
            }

            
            showMarketItemForm(player, marketEntity, 2);
            break;
        case "manage_market":
            showManageMerketForm(player, marketEntity)
            break;
    }

}