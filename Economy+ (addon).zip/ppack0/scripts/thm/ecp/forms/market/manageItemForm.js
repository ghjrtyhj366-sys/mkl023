import { ActionFormData, ModalFormData } from "@minecraft/server-ui";
import { MoneyUtils } from "../../utils/MoneyUtils";
import { showManageMerketForm } from "./manageMarketForm";
import { MessageForms } from "../MessageForms";
import { MarketManager } from "../../managers/MarketManager";
import { EntityComponentTypes, EquipmentSlot } from "@minecraft/server";
import { ItemUtils } from "../../utils/ItemUtils";
import { MessageUtils } from "../../utils/MessageUtils";
import { MARKET_ITEMS } from "../../data/marketItems";
import { ActorPropertiesEnum } from "../../enums/ActorPropertiesEnum";

export async function showMarketManageItemForm(player, marketEntity, slot){
    if(!marketEntity) return;

    const marketName = MarketManager.getName(marketEntity);

    let form = new ActionFormData();
    form.title(marketName);

    const marketItem = MarketManager.getItem(marketEntity, slot);

    let formBody = {
        rawtext: [
        { translate: `thm_ecp.form.manage_item.title`},
        { text: '\n\n' },
        { translate: `thm_ecp.form.manage_market.welcome`},
        { text: '\n\n' },
        ]
    }   

    let itemButtons = [];
    if(marketItem.item != null || marketItem.item != undefined){
        formBody.rawtext.push(
            { translate: `thm_ecp.form.market.item1`},
            { text: '\n' },
            { translate: `thm_ecp.form.market.item`, with: [ItemUtils.getItemName(marketItem.item)] },
            { text: '\n' },
            { translate: `thm_ecp.form.market.price`, with: [MoneyUtils.getMoneyFormat(marketItem.price)] },
            { text: '\n' },
            { translate: `thm_ecp.form.market.stock`, with: [marketItem.stock] }
        )

        form.button({ translate: `thm_ecp.form.button.replace_item`});
        itemButtons.push("add_item");
        form.button({ translate: `thm_ecp.form.button.remove_item`});
        itemButtons.push("remove_item");
        form.button({ translate: `thm_ecp.form.button.update_stock`});
        itemButtons.push("update_stock");
        form.button({ translate: `thm_ecp.form.button.update_price`});
        itemButtons.push("update_price");
        form.button({ translate: `thm_ecp.form.button.update_basket`});
        itemButtons.push("update_basket");
    } else {
        formBody.rawtext.push({ translate: `thm_ecp.form.market_item.no_items`});
        form.button({ translate: `thm_ecp.form.button.add_item`});
        itemButtons.push("add_item");
    }
    form.button({ translate: `thm_ecp.form.button.withdraw_sales`, with:[MoneyUtils.getMoneyFormat(marketItem.sales)]});
    itemButtons.push("withdraw");
    form.button({ translate: `thm_ecp.form.button.back`});
    itemButtons.push("back");

    const result = await form.show(player);
    const selection = result.selection;

    const formToShow = itemButtons[selection];
    switch (formToShow) {
        case "remove_item":
            const itemToRemove = MarketManager.getItem(marketEntity, slot);
            
            const confirmRemove = await confirmForm(player, { translate: "thm_ecp.form.manage_market.remove_item_confirm", with:[ItemUtils.getItemName(itemToRemove.item)] })
            if(!confirmRemove) return;
            const currentStock_remove = MarketManager.getStock(marketEntity, slot);
            if(itemToRemove.item != null || itemToRemove.item != undefined){
                MarketManager.returnItems(marketEntity, slot, currentStock_remove, player);
                MarketManager.withdrawSales(marketEntity, slot, player);
                MarketManager.removeItem(marketEntity, slot);
                marketEntity.setProperty(ActorPropertiesEnum.getItemFromSlot(slot), 0);
                MessageUtils.sendSuccessMsg(player, { translate: "thm_ecp.form.manage_market.removed_items", with:[ItemUtils.getItemName(itemToRemove.item)] });
            }
            
            break;
        case "update_stock":
            const stockForm_item = MarketManager.getItem(marketEntity, slot);
            if(stockForm_item.item === null || stockForm_item.item === undefined) return;

            const stockForm_stock = MarketManager.getStock(marketEntity, slot);
            const totalItemsInInventory = ItemUtils.getAllSameItems(player, stockForm_item.item);

            let stockForm = new ModalFormData();
            stockForm.title({ translate: "thm_ecp.form.manage_item.update_stock" });
            
            stockForm.slider({ translate: "thm_ecp.form.manage_item.choose_stock" }, 1, stockForm_stock + totalItemsInInventory, 1, stockForm_stock);

            const stockForm_result = await stockForm.show(player);
            if(stockForm_result.canceled) return;
            if(stockForm_result.formValues.length === 0) return;
            
            const stockForm_value = stockForm_result.formValues[0];
            if(stockForm_value > stockForm_stock){
                MessageUtils.sendPlainMsg(player, { translate: `thm_ecp.form.market_item.stock_add`, with:[`${stockForm_value - stockForm_stock}`, ItemUtils.getItemName(stockForm_item.item), `${stockForm_value}`]})
                MarketManager.setStock(marketEntity, slot, stockForm_value);
                ItemUtils.removeItemStacks(player, stockForm_item.item, stockForm_value - stockForm_stock);
                
            } else if( stockForm_value < stockForm_stock){
                MarketManager.returnItems(marketEntity, slot, stockForm_stock - stockForm_value, player);
                MessageUtils.sendPlainMsg(player, { translate: `thm_ecp.form.market_item.stock_return`, with:[`${stockForm_stock - stockForm_value}`, ItemUtils.getItemName(stockForm_item.item)]})
            } else {
                MessageUtils.sendPlainMsg(player, { translate: "thm_ecp.form.manage_item.no_update" })
            }
            break;
        case "update_price":
            const price_form_current = MarketManager.getPrice(marketEntity, slot);

            let price_form = new ModalFormData();

            price_form.title({ translate: "thm_ecp.form.manage_item.update_price" });
            price_form.textField({ translate: "thm_ecp.form.manage_item.edit_price" },{ translate: "thm_ecp.form.manage_item.input_price" }, `${price_form_current}` );
            

            const price_form_result = await price_form.show(player);
            if(price_form_result.canceled) return;

            const value = parseInt(price_form_result.formValues[0], 10);

            if(isNaN(value || value < 1)){
                const goBack = await errorForm(player, { translate: "thm_ecp.form.error.whole_number" });
                if(goBack) showMarketManageItemForm(player, marketEntity, slot);
                return false;
            }

            if(value == price_form_current){
                MessageUtils.sendPlainMsg(player, { translate: "thm_ecp.form.manage_item.no_update_price" })
            } else {
                MarketManager.setPrice(marketEntity, slot, value);
                MessageUtils.sendSuccessMsg(player, { translate: "thm_ecp.form.manage_item.set_price", with: [MoneyUtils.getMoneyFormat(value)] })
            }
            break;
        case "update_basket":
            let basketForm = new ModalFormData();
            basketForm.title({ translate: "thm_ecp.form.manage_item.update_basket" });
            const items = MARKET_ITEMS;
            basketForm.dropdown({translate:"thm_ecp.form.market.item_select"}, items);
            const basketForm_result = await basketForm.show(player);
            if(basketForm_result.canceled) return;
            const index = parseInt(basketForm_result.formValues[0], 10)
            marketEntity.setProperty(ActorPropertiesEnum.getItemFromSlot(slot), index + 1);
            MessageUtils.sendSuccessMsg(player, { translate: "thm_ecp.form.manage_item.basket_changed", with:[`${items[index]}`]});

            break
        case "add_item":
            
            const mainHandItem = await getChosenItem(player, marketEntity, slot); 
            
            if(mainHandItem == null || mainHandItem == undefined) return;

            //temp until we get potions component
            if(mainHandItem.typeId === "minecraft:potion"){
                const goBack = await errorForm(player, { translate: "thm_ecp.form.error.potion" });
                    if(goBack) showManageMerketForm(player, marketEntity, slot);
                    return;
            }    

            const totalItems = ItemUtils.getAllSameItems(player, mainHandItem);
            
            if(totalItems === 0) return;
            let nametag = ItemUtils.getItemName(mainHandItem);
            const input = await getValueInput(player, `${nametag}`, totalItems);
            if(!input) return;
            
            if(!checkErrors(player, marketEntity, slot, input)) return;
            const currentItem = MarketManager.getItem(marketEntity, slot);
            const currentStock = MarketManager.getStock(marketEntity, slot);
            
            if(ItemUtils.isValidItemStack(currentItem)){
                MarketManager.returnItems(marketEntity, slot, currentStock, player);
                MarketManager.withdrawSales(marketEntity, slot, player);
                MarketManager.removeItem(marketEntity, slot);
            }
            const totalToAdd = input[0];
            const price = parseInt(input[1], 10);
            marketEntity.setProperty(ActorPropertiesEnum[`ITEM_${slot}`], parseInt(input[2], 10) + 1);
            MarketManager.setItem(marketEntity, mainHandItem, slot, totalToAdd, price);
            ItemUtils.removeItemStacks(player, mainHandItem, totalToAdd);
            MessageUtils.sendSuccessMsg(player,{ translate: "thm_ecp.form.manage_market.success", with:[`${totalToAdd}`, `${nametag}`, MoneyUtils.getMoneyFormat(price)] } )

            break;
        case "back":
            showManageMerketForm(player, marketEntity);
            break;
        case "withdraw":
            if(MarketManager.getSales(marketEntity, slot) === 0){
                MessageUtils.sendErrorMsg(player, {translate:"thm_ecp.form.manage_market.withdraw_sales.empty"});
                return;
            }
            const confrimedWitdraw = await confirmForm(player, { translate: "thm_ecp.form.manage_market.withdraw_sales", with: [MoneyUtils.getMoneyFormat(MarketManager.getSales(marketEntity, slot))] });
            if(!confrimedWitdraw) return;

            MarketManager.withdrawSales(marketEntity, slot, player);
            break;
    }
    
}

async function checkErrors(player, marketEntity, slot, input){
    if(input == null) return false;
    const totalToAdd = input[0];

            if(totalToAdd === 0){
                MessageUtils.sendPlainMsg(player, { translate: "thm_ecp.form.manage_market.no_value" })
                return false;
            }

            const value = parseInt(input[1], 10);

            if(isNaN(value) || value < 1){
                const goBack = await errorForm(player, { translate: "thm_ecp.form.error.whole_number" });
                if(goBack) showMarketManageItemForm(player, marketEntity, slot);
                return false;
            }

            return true;
}

async function confirmForm(player, confirmMsg){
    const result = await MessageForms.sendConfirmation(
        player, 
        confirmMsg
    )
    return result.selection === 1;
}

async function errorForm(player, error){
    const result = await MessageForms.sendError(
        player, 
        error,
        { translate: "thm_ecp.form.button.exit" },
        { translate: "thm_ecp.form.button.go_back" }
    )
    return result.selection === 1;
}

async function getChosenItem(player, marketEntity, slot){
    const mainHandItem = player?.getComponent(EntityComponentTypes.Equippable)?.getEquipment(EquipmentSlot.Mainhand); 
    if(mainHandItem == null || mainHandItem == undefined){
        const goback = await errorForm(player, { translate: "thm_ecp.form.manage_item.error" });

        if(goback) showMarketManageItemForm(player, marketEntity, slot);
        return;
    }

    return mainHandItem;
}

async function getValueInput(player, itemName, total){
    let form = new ModalFormData();
    form.title({ translate: "thm_ecp.form.manage_item.select_value" });

    form.slider(itemName, 0, total, 1, 0);
    form.textField({translate: "thm_ecp.form.market.price_title"},{ translate: "thm_ecp.form.manage_item.input_price" }, "0" );

    const items = MARKET_ITEMS;
    form.dropdown({translate:"thm_ecp.form.market.item_select"}, items);

    const result = await form.show(player);
    if(result.canceled) return null;

    return result.formValues;
}
