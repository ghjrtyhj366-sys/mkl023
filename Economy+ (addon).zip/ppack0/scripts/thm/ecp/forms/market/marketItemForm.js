import { ActionFormData } from "@minecraft/server-ui";
import { MoneyUtils } from "../../utils/MoneyUtils";
import { ItemUtils } from "../../utils/ItemUtils";
import { showMainMarketForm } from "./mainMarket";
import { MarketUtils } from "../../utils/MarketUtils";
import { showMarketBuyCustomForm } from "./marketBuyCustom";
import { MarketManager } from "../../managers/MarketManager";
import { ENCHANTMENT_STRINGS } from "../../data/enchantmentStrings";

export async function showMarketItemForm(player, marketEntity, itemSlot){
    if(!marketEntity) return;

    const marketName = MarketManager.getName(marketEntity);

    const marketItem = MarketManager.getItem(marketEntity, itemSlot);
    

    const itemName = ItemUtils.getItemName(marketItem.item);

    let form = new ActionFormData();
    form.title(marketName);

    let formBody = {
        rawtext: [
        { translate: `thm_ecp.form.market_item.welcome`},
        { text: '\n\n' },
        { translate: `thm_ecp.form.market.item`, with: [itemName] },
        { text: '\n' },
        { translate: `thm_ecp.form.market.price`, with: [MoneyUtils.getMoneyFormat(marketItem.price)] },
        { text: '\n' },
        { translate: `thm_ecp.form.market.stock`, with: [`${marketItem.stock}`] },
        { text: '\n' },
        ]
    }

    const components = marketItem.item.getComponents();
    if(components.length > 0){
        formBody.rawtext.push({ text: '§bItem Components§r:' },);
        formBody.rawtext.push({ text: '\n' },);
        for (const component of components) {
            if(component.typeId === "minecraft:durability"){
                formBody.rawtext.push({ text: ` §cDurability§r: ${Math.floor((component.maxDurability - component.damage)/ component.maxDurability * 100)}%%` },);
                formBody.rawtext.push({ text: '\n' },);
            }

            if(component.typeId === "minecraft:enchantable"){

                const enchants = component.getEnchantments();
                if(enchants.length === 0) continue;

                formBody.rawtext.push({ text: ` §dEnchants§r:` },);
                formBody.rawtext.push({ text: '\n' },);

                for (const enchant of enchants) {
                    formBody.rawtext.push({ text: `  - ` },);
                    formBody.rawtext.push({ translate: `${ENCHANTMENT_STRINGS[enchant.type.id]}`})
                    formBody.rawtext.push({ text: ` ` },);
                    formBody.rawtext.push({ translate: `${enchant.level <=10 && enchant.level > 0 ? `enchantment.level.${enchant.level}` : enchant.level}`})
                    formBody.rawtext.push({ text: '\n' },);
                }
            }

            if(component.typeId === "minecraft:potion"){

                formBody.rawtext.push({ text: ` Potion: ${component.potionEffectType.id} ${component.potionLiquidType.id}` },);
                formBody.rawtext.push({ text: '\n' },);
            }
        }
    }

    form.body(formBody);

    let itemButtons = [];

    form.button({ translate: `thm_ecp.form.button.buy_amount`, with: ["1", `\n`, MoneyUtils.getMoneyFormat(marketItem.price)]});
    itemButtons.push("buy_amount");
    const halfAmount = Math.floor(marketItem.stock / 2);
    if(marketItem.stock > 2){
        
        form.button({ translate: `thm_ecp.form.button.buy_half`, with: [`${halfAmount}`, `\n`, MoneyUtils.getMoneyFormat(halfAmount * marketItem.price)]});
        itemButtons.push("buy_half");
    }

    if(marketItem.stock >= 2){
        form.button({ translate: `thm_ecp.form.button.buy_all`, with: [`${marketItem.stock}`, `\n`, MoneyUtils.getMoneyFormat(marketItem.stock * marketItem.price)]});
        itemButtons.push("buy_all");
    }

    if(marketItem.stock > 1){
        form.button({ translate: `thm_ecp.form.button.buy_custom`});
        itemButtons.push("buy_custom");
    }

    form.button({ translate: `thm_ecp.form.button.back`});
    itemButtons.push("back");

    const result = await form.show(player);
    const selection = result.selection;
    if(result.canceled) return;
    
    const formToShow = itemButtons[selection];
    switch (formToShow) {
        case "buy_amount":
            MarketUtils.buyItem(player, marketEntity, itemSlot, 1);
            break;
        case "buy_half":
            MarketUtils.buyItem(player, marketEntity, itemSlot, halfAmount);
            break;
        case "buy_all":
            MarketUtils.buyItem(player, marketEntity, itemSlot, marketItem.stock);
            break;
        case "buy_custom":
            showMarketBuyCustomForm(player, marketEntity, itemSlot);
            break;
        case "back":
            showMainMarketForm(player, marketEntity);
            break;
    }

}
