import { ModalFormData } from "@minecraft/server-ui";
import { MarketUtils } from "../../utils/MarketUtils";
import { ItemUtils } from "../../utils/ItemUtils";
import { MarketManager } from "../../managers/MarketManager";

export async function showMarketBuyCustomForm(player, marketEntity, slot){
    if(!marketEntity) return;

    const marketNamme = MarketManager.getName(marketEntity);

    let form = new ModalFormData();
    form.title(marketNamme);

    const marketItem = MarketManager.getItem(marketEntity, slot);

    const itemName = ItemUtils.getItemName(marketItem.item);

    form.slider(itemName, 1, marketItem.stock, 1, 1);

    const result = await form.show(player);
    if(result.canceled) return;

    const amount = result.formValues[0];
    MarketUtils.buyItem(player, marketEntity, slot, amount);
}