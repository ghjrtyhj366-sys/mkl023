import { world as w, system as s } from "@minecraft/server";

class XX {
    constructor(A, B, C, D = "M") {
        D = `${D[0].toUpperCase()}${D.slice(1).toLowerCase()}`;
        this.q = A.includes(":") ? A : `minecraft:${A}`;
        this.e = C.startsWith("animation.") ? C : `animation.${C}`;
        this.w = B.includes(":") ? B : `minecraft:${B}`;
        this.r = D;
    }
}

const _yYyY = [
    new XX("seal:umbrella_of_mountain_serenity2", "seal:umbrella_of_mountain_serenity", "animation.umbrella", "mainhand"),
    new XX("seal:umbrella_midnight_higanbana2", "seal:umbrella_midnight_higanbana", "animation.umbrella", "mainhand"),
    new XX("seal:umbrella_red_bloom_harmony2", "seal:umbrella_red_bloom_harmony", "animation.umbrella", "mainhand"),
    new XX("seal:umbrella_pink_radiance2", "seal:umbrella_pink_radiance", "animation.umbrella", "mainhand"),
    new XX("seal:umbrella_blossoms_under_the_moon2", "seal:umbrella_blossoms_under_the_moon", "animation.umbrella", "mainhand"),
];

function __ZzZz(pPp) {
    let eqQq = pPp.getComponent("minecraft:equippable");
    let uhOh = false;
    _yYyY.forEach(IiIi => {
        if (eqQq?.getEquipment(IiIi.r)?.typeId === IiIi.w) {
            pPp.playAnimation(IiIi.e, { loop: true });
            uhOh = true;
        }
    });
}

function __AaAa(EeEe) {
    const PPP = EeEe.source, III = EeEe.itemStack, fFfF = _yYyY.find(XxXx => XxXx.q === III.typeId || XxXx.w === III.typeId);
    if (!fFfF) return;
    PPP.runCommandAsync(`replaceitem entity @s slot.weapon.mainhand 0 ${III.typeId === fFfF.w ? fFfF.q : fFfF.w}`);
}

w.afterEvents.itemUse.subscribe(__AaAa);
s.runInterval(() => w.getPlayers().forEach(__ZzZz));