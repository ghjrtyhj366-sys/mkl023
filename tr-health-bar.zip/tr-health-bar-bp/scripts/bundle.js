/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
import * as __WEBPACK_EXTERNAL_MODULE__minecraft_server_fb7572af__ from "@minecraft/server";
/******/ var __webpack_modules__ = ({

/***/ "./src/index.ts":
/*!**********************!*\
  !*** ./src/index.ts ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var _minecraft_server__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @minecraft/server */ \"@minecraft/server\");\n/* harmony import */ var _utils_tick__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./utils/tick */ \"./src/utils/tick.ts\");\n\n\nfunction* hpBarByTrStudio(tick) {\n    const players = _minecraft_server__WEBPACK_IMPORTED_MODULE_0__.world.getAllPlayers();\n    for (const player of players) {\n        const health = player.getComponent(\"health\");\n        const percent = Math.floor((health.currentValue / health.effectiveMax) * 100);\n        player.onScreenDisplay.setTitle(`hp:${percent}`);\n        player.onScreenDisplay.updateSubtitle(`§e${health.currentValue}`);\n    }\n}\n_utils_tick__WEBPACK_IMPORTED_MODULE_1__.Tick.on(hpBarByTrStudio, 1);\n_minecraft_server__WEBPACK_IMPORTED_MODULE_0__.world.afterEvents.playerSpawn.subscribe(event => {\n    const player = event.player;\n    if (player) {\n        player.runCommand(\"hud @s hide health\");\n        player.runCommand(\"hud @s hide armor\");\n    }\n});\n\n\n//# sourceURL=webpack://tr-studio-bp/./src/index.ts?");

/***/ }),

/***/ "./src/utils/tick.ts":
/*!***************************!*\
  !*** ./src/utils/tick.ts ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   Tick: () => (/* binding */ Tick)\n/* harmony export */ });\n/* harmony import */ var _minecraft_server__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @minecraft/server */ \"@minecraft/server\");\n\nclass TaskManager {\n    waitingTasks = [];\n    activeTasks = new Set();\n    ticking = false;\n    TASKS_PER_TICK = 5;\n    MAX_GEN_TICKS = 200;\n    addTask(task) {\n        this.waitingTasks.push(task);\n        if (!this.ticking)\n            this.scheduleTick();\n        return this.waitingTasks.length - 1;\n    }\n    scheduleTick() {\n        this.ticking = true;\n        _minecraft_server__WEBPACK_IMPORTED_MODULE_0__.system.run(this.tick.bind(this));\n    }\n    isGeneratorFunction(fn) {\n        return fn.constructor && fn.constructor.name === \"GeneratorFunction\";\n    }\n    tick() {\n        const currentTick = _minecraft_server__WEBPACK_IMPORTED_MODULE_0__.system.currentTick;\n        let count = 0;\n        for (let i = this.waitingTasks.length - 1; i >= 0 && count < this.TASKS_PER_TICK; i--) {\n            const task = this.waitingTasks[i];\n            if (task.lastRun === -Infinity) {\n                task.lastRun = currentTick;\n                continue;\n            }\n            if (currentTick < task.lastRun + task.delay)\n                continue;\n            if (this.isGeneratorFunction(task.callback)) {\n                try {\n                    const gen = task.callback(currentTick);\n                    if (gen && typeof gen.next === \"function\") {\n                        task.generator = gen;\n                        task._genTicks = 0;\n                        this.activeTasks.add(task);\n                    }\n                }\n                catch (e) {\n                    console.error(\"Error starting generator task:\", e);\n                }\n            }\n            else {\n                try {\n                    task.callback(currentTick);\n                }\n                catch (e) {\n                    console.error(\"Error in task callback:\", e);\n                }\n                if (task.once) {\n                    this.waitingTasks.splice(i, 1);\n                    continue;\n                }\n            }\n            task.lastRun = currentTick;\n            if (task.once || task.generator)\n                this.waitingTasks.splice(i, 1);\n            count++;\n        }\n        for (const task of this.activeTasks) {\n            if (!task.generator)\n                continue;\n            task._genTicks ??= 0;\n            task._genTicks++;\n            try {\n                const { done } = task.generator.next(currentTick);\n                if (done || task._genTicks >= this.MAX_GEN_TICKS) {\n                    task.generator = undefined;\n                    task._genTicks = 0;\n                    task.lastRun = currentTick;\n                    this.activeTasks.delete(task);\n                    if (!task.once) {\n                        this.waitingTasks.push(task);\n                    }\n                }\n            }\n            catch (e) {\n                console.error(\"Error in generator execution:\", e);\n                task.generator = undefined;\n                task._genTicks = 0;\n                task.lastRun = currentTick;\n                this.activeTasks.delete(task);\n                // ถ้าไม่ใช่ once ก็สามารถนำกลับไปต่อได้ ขึ้นอยู่กับการออกแบบ\n                if (!task.once) {\n                    this.waitingTasks.push(task);\n                }\n            }\n        }\n        if (this.waitingTasks.length > 0 || this.activeTasks.size > 0) {\n            this.scheduleTick();\n        }\n        else {\n            this.ticking = false;\n        }\n    }\n}\nconst taskManager = new TaskManager();\nclass Tick {\n    static on(callback, delay = 0, once = false) {\n        return taskManager.addTask({ delay, callback, lastRun: -Infinity, once });\n    }\n    static once(callback, delay = 0) {\n        this.on(callback, delay, true);\n    }\n}\n\n\n//# sourceURL=webpack://tr-studio-bp/./src/utils/tick.ts?");

/***/ }),

/***/ "@minecraft/server":
/*!************************************!*\
  !*** external "@minecraft/server" ***!
  \************************************/
/***/ ((module) => {

module.exports = __WEBPACK_EXTERNAL_MODULE__minecraft_server_fb7572af__;

/***/ })

/******/ });
/************************************************************************/
/******/ // The module cache
/******/ var __webpack_module_cache__ = {};
/******/ 
/******/ // The require function
/******/ function __webpack_require__(moduleId) {
/******/ 	// Check if module is in cache
/******/ 	var cachedModule = __webpack_module_cache__[moduleId];
/******/ 	if (cachedModule !== undefined) {
/******/ 		return cachedModule.exports;
/******/ 	}
/******/ 	// Create a new module (and put it into the cache)
/******/ 	var module = __webpack_module_cache__[moduleId] = {
/******/ 		// no module.id needed
/******/ 		// no module.loaded needed
/******/ 		exports: {}
/******/ 	};
/******/ 
/******/ 	// Execute the module function
/******/ 	__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 
/******/ 	// Return the exports of the module
/******/ 	return module.exports;
/******/ }
/******/ 
/************************************************************************/
/******/ /* webpack/runtime/define property getters */
/******/ (() => {
/******/ 	// define getter functions for harmony exports
/******/ 	__webpack_require__.d = (exports, definition) => {
/******/ 		for(var key in definition) {
/******/ 			if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 				Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 			}
/******/ 		}
/******/ 	};
/******/ })();
/******/ 
/******/ /* webpack/runtime/hasOwnProperty shorthand */
/******/ (() => {
/******/ 	__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ })();
/******/ 
/******/ /* webpack/runtime/make namespace object */
/******/ (() => {
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = (exports) => {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/ })();
/******/ 
/************************************************************************/
/******/ 
/******/ // startup
/******/ // Load entry module and return exports
/******/ // This entry module can't be inlined because the eval devtool is used.
/******/ var __webpack_exports__ = __webpack_require__("./src/index.ts");
/******/ 
